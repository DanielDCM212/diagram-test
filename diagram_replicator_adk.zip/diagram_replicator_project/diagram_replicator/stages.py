"""Deterministic (non-LLM) pipeline stages implemented as custom ADK agents."""
from __future__ import annotations

import base64
import json
import mimetypes
import os
import re
import shutil
import time
import uuid
from typing import AsyncGenerator, Optional

from google.adk.agents import BaseAgent, LlmAgent
from google.adk.agents.invocation_context import InvocationContext
from google.adk.events import Event, EventActions
from google.genai import types
from PIL import Image

from drawio_kit.schema import DiagramSpec, Node
from drawio_kit.vision_ops import (crop_with_grid, detect_boxes, detect_lines, image_info, make_tiles, ocr_lines,
                                   ocr_words, text_coverage)

from .config import CONFIG, resolve_ocr_backend
from .merge import bbox, build_edges, build_nodes, iou, merge_tile_extractions
from .pipeline_ops import load_spec, save_spec, score_and_export, _quality
from .workspace import Workspace, ws_from_state

IMG_EXT = (".png", ".jpg", ".jpeg", ".webp", ".bmp", ".gif", ".tif", ".tiff")


def _event(agent: BaseAgent, ctx: InvocationContext, text: Optional[str] = None, delta: Optional[dict] = None,
           escalate: bool = False) -> Event:
    return Event(
        author=agent.name, invocation_id=ctx.invocation_id, branch=ctx.branch,
        content=types.Content(role="model", parts=[types.Part.from_text(text=text)]) if text else None,
        actions=EventActions(state_delta=delta or {}, escalate=escalate or None))


def _as_dict(v):
    if v is None:
        return None
    if isinstance(v, dict):
        return v
    if hasattr(v, "model_dump"):
        return v.model_dump()
    if isinstance(v, str):
        s = re.sub(r"^```(?:json)?|```$", "", v.strip(), flags=re.M).strip()
        try:
            return json.loads(s)
        except json.JSONDecodeError:
            return None
    return None


def _step(span: float, target_lines: int = 24) -> int:
    for s in (10, 20, 25, 50, 100, 200, 250, 500):
        if span / s <= target_lines:
            return s
    return 1000


# =========================================================================== ingest
class IngestStage(BaseAgent):
    """Locate the input image, create the workspace, and measure everything measurable."""

    async def _run_async_impl(self, ctx: InvocationContext) -> AsyncGenerator[Event, None]:
        state = ctx.session.state
        src_bytes, src_name = None, "input"
        # 1) explicit path in state (run.py / API callers)
        if state.get("input_image_path") and os.path.exists(state["input_image_path"]):
            src_name = state["input_image_path"]
            src_bytes = open(src_name, "rb").read()
        # 2) inline image in the user message
        if src_bytes is None and ctx.user_content:
            for part in ctx.user_content.parts or []:
                if part.inline_data and (part.inline_data.mime_type or "").startswith("image/"):
                    src_bytes = part.inline_data.data
                    src_name = part.inline_data.display_name or "inline_image"
                    break
        # 3) a filesystem path mentioned in the text
        if src_bytes is None and ctx.user_content:
            txt = " ".join(p.text or "" for p in ctx.user_content.parts or [])
            for tok in re.findall(r"[\w./\\:~-]+\.(?:png|jpe?g|webp|bmp|gif|tiff?)", txt, flags=re.I):
                p = os.path.expanduser(tok)
                if os.path.exists(p):
                    src_bytes, src_name = open(p, "rb").read(), p
                    break
        # 4) a previously uploaded artifact
        if src_bytes is None and ctx.artifact_service:
            keys = await ctx.artifact_service.list_artifact_keys(
                app_name=ctx.session.app_name, user_id=ctx.session.user_id, session_id=ctx.session.id)
            for k in keys:
                if k.lower().endswith(IMG_EXT):
                    part = await ctx.artifact_service.load_artifact(
                        app_name=ctx.session.app_name, user_id=ctx.session.user_id, session_id=ctx.session.id,
                        filename=k)
                    if part and part.inline_data:
                        src_bytes, src_name = part.inline_data.data, k
                        break
        if src_bytes is None:
            yield _event(self, ctx, "No diagram image found. Attach an image or pass its path.",
                         {"fatal": "no_image"}, escalate=True)
            return

        ws = Workspace(os.path.join(CONFIG.workdir, f"{ctx.session.id}_{uuid.uuid4().hex[:6]}"))
        import io
        im = Image.open(io.BytesIO(src_bytes))
        im = im.convert("RGBA")
        flat = Image.new("RGB", im.size, "white")
        flat.paste(im, mask=im.split()[3])
        flat.save(ws.source)
        W, H = flat.size

        meta = image_info(ws.source)
        backend = resolve_ocr_backend()
        if backend == "tesseract":
            up = 2.0 if max(W, H) < 1600 else 1.3
            words = ocr_words(ws.source, upscale=up)
            lines = ocr_lines(ws.source, words=words)
        else:  # "gemini" → filled by the ocr stage right after ingest; "none" → no OCR grounding
            words, lines = [], []
        boxes = detect_boxes(ws.source, min_w=14, min_h=10, upscale=1.0 if max(W, H) > 1200 else 2.0)
        segs = detect_lines(ws.source, min_len=20)
        ws.write_json("cv.json", {"ocr_words": words, "ocr_lines": lines, "boxes": boxes, "lines": segs})

        # tiling
        cols = max(1, round(W / CONFIG.max_tile_src_px + 0.25))
        rows = max(1, round(H / CONFIG.max_tile_src_px + 0.25))
        density = max(len(lines), 0.6 * len(boxes))   # boxes proxy text density before Gemini OCR
        while density / (rows * cols) > 70 and rows * cols < 24:
            if W / cols >= H / rows:
                cols += 1
            else:
                rows += 1
        tw = W / cols
        zoom = max(1.0, min(3.0, CONFIG.tile_target_px / (tw * (1 + 2 * CONFIG.tile_overlap))))
        tiles = make_tiles(ws.source, ws.p("tiles"), rows, cols, CONFIG.tile_overlap, zoom=zoom,
                           grid_step=_step(tw, 18))
        ov_zoom = min(1.0, 2400 / W) if W > 2400 else min(3.0, 1400 / W) if W < 1400 else 1.0
        ov_step = _step(W, 26)
        crop_with_grid(ws.source, [0, 0, W, H], ws.p("overview_grid.png"), zoom=ov_zoom, step=ov_step)
        meta.update({"source_name": os.path.basename(str(src_name)), "ocr_lines": len(lines),
                     "detected_boxes": len(boxes), "detected_lines": len(segs), "tiles": f"{rows}x{cols}"})
        yield _event(self, ctx,
                     f"Ingested {meta['source_name']} ({W}x{H}); OCR={backend}; {len(lines)} text lines, {len(boxes)} boxes, "
                     f"{len(segs)} line segments measured; {rows}x{cols} tiles.",
                     {"ws_dir": ws.root, "image_meta": meta, "tiles": tiles, "overview_step": ov_step,
                      "ocr_backend": backend,
                      "refine_iteration": 0, "quality_history": [], "fatal": None})


# =========================================================================== tiled extraction
class TiledExtractionStage(BaseAgent):
    """Runs the tile extractor on every tile, with gap-filling passes until the OCR text inside
    the tile is covered (exhaustiveness guard)."""
    extractor: LlmAgent

    def __init__(self, name: str, extractor: LlmAgent):
        super().__init__(name=name, extractor=extractor, sub_agents=[extractor])

    async def _run_async_impl(self, ctx: InvocationContext) -> AsyncGenerator[Event, None]:
        state = ctx.session.state
        if state.get("fatal"):
            return
        ws = ws_from_state(state)
        cv = ws.read_json("cv.json", {})
        results = []
        for tile in state.get("tiles", []):
            x0, y0, x1, y1 = tile["box"]
            tile_words = [w for w in cv.get("ocr_words", [])
                          if x0 <= w["x"] and w["x"] + w["w"] <= x1 and y0 <= w["y"] and w["y"] + w["h"] <= y1]
            elements: list[dict] = []
            missing: list[str] = []
            for pass_no in range(CONFIG.extraction_passes):
                prior = "\n".join(f"{e['local_id']} {e['kind']} ({e['x']:.0f},{e['y']:.0f},{e['w']:.0f},{e['h']:.0f}) "
                                  f"{json.dumps(e.get('label',''))}" for e in elements)
                yield _event(self, ctx, None, {"current_tile": tile, "current_tile_missing_text": missing,
                                               "current_tile_prior": prior, "tile_extraction": None})
                out = None
                for attempt in range(CONFIG.llm_retries + 1):
                    try:
                        async for ev in self.extractor.run_async(ctx):
                            yield ev
                        out = _as_dict(ctx.session.state.get("tile_extraction"))
                        if out is not None:
                            break
                    except Exception as ex:  # model/JSON failure → retry
                        yield _event(self, ctx, f"tile {tile['id']} pass {pass_no} attempt {attempt} failed: {ex}")
                new = (out or {}).get("elements", [])
                for e in new:
                    e["local_id"] = f"p{pass_no}_{e.get('local_id', len(elements))}"
                    if e.get("parent_local_id"):
                        e["parent_local_id"] = f"p{pass_no}_{e['parent_local_id']}"
                elements += new
                cov = text_coverage([e.get("label", "") for e in elements], tile_words)
                missing = sorted({f"{m['token']} @({m['x']:.0f},{m['y']:.0f})" for m in cov["missing"]})
                if cov["coverage"] >= CONFIG.tile_text_coverage_target or not missing:
                    break
            rec = {"tile_id": tile["id"], "elements": elements, "text_coverage": cov["coverage"]}
            ws.write_json(os.path.join("extractions", f"{tile['id']}.json"), rec)
            results.append(rec)
            yield _event(self, ctx, f"Tile {tile['id']}: {len(elements)} elements, text coverage {cov['coverage']:.0%}.")
        ws.write_json("extractions.json", results)
        yield _event(self, ctx, None, {"tile_extraction": None, "current_tile": None,
                                       "extracted_elements": sum(len(r["elements"]) for r in results)})


# =========================================================================== merge
class MergeStage(BaseAgent):
    """Dedupe across tiles, snap to measured boxes, infer hierarchy, add planned rasters."""

    async def _run_async_impl(self, ctx: InvocationContext) -> AsyncGenerator[Event, None]:
        state = ctx.session.state
        if state.get("fatal"):
            return
        ws = ws_from_state(state)
        W, H = state["image_meta"]["width"], state["image_meta"]["height"]
        cv = ws.read_json("cv.json", {})
        merged = merge_tile_extractions(state.get("tiles", []), ws.read_json("extractions.json", []),
                                        cv.get("boxes", []), W, H)
        plan = _as_dict(state.get("layout_plan")) or {}
        # planner-identified rasters that no tile reported → add them (never lose clip-art)
        have = [bbox(e) for e in merged if e["kind"] == "raster"]
        for i, r in enumerate(plan.get("raster_regions", [])):
            b = [r["x0"], r["y0"], r["x1"], r["y1"]]
            if (b[2] - b[0]) > 2 and (b[3] - b[1]) > 2 and max((iou(b, h) for h in have), default=0) < 0.3:
                merged.append({"local_id": f"plan_r{i}", "kind": "raster", "label": r.get("label", ""),
                               "x": b[0], "y": b[1], "w": b[2] - b[0], "h": b[3] - b[1], "tile": "plan",
                               "confidence": 0.7})
        nodes = build_nodes(merged, ws.source)
        ws.write_json("nodes.json", [n.model_dump() for n in nodes])
        yield _event(self, ctx, f"Merged {len(merged)} unique elements ({len(nodes)} nodes, "
                                f"{sum(n.kind == 'container' for n in nodes)} containers).",
                     {"node_count": len(nodes)})


# =========================================================================== assemble / rescore
class AssembleStage(BaseAgent):
    """mode='initial': nodes + connectors → spec. mode='rescore': re-render current spec."""
    mode: str = "initial"

    async def _run_async_impl(self, ctx: InvocationContext) -> AsyncGenerator[Event, None]:
        state = ctx.session.state
        if state.get("fatal"):
            return
        ws = ws_from_state(state)
        meta = state["image_meta"]
        if self.mode == "initial":
            plan = _as_dict(state.get("layout_plan")) or {}
            nodes = [Node.model_validate(n) for n in ws.read_json("nodes.json", [])]
            conn = _as_dict(state.get("connector_extraction")) or {"edges": []}
            edges = build_edges(conn, nodes)
            scale = float(plan.get("recommended_scale") or 1.0)
            if meta["width"] < 900 and scale <= 1.0:
                scale = round(1200 / meta["width"], 1)
            bg = plan.get("canvas_background") or "#FFFFFF"
            if plan.get("is_photo"):
                bg = "#FFFFFF"  # photographed paper → clean white page
            spec = DiagramSpec(name=plan.get("title") or meta.get("source_name", "diagram"),
                               source_image=ws.source, width=meta["width"], height=meta["height"],
                               background=bg, scale=scale, nodes=nodes, edges=edges,
                               notes=plan.get("diagram_type", ""))
            save_spec(ws, spec, tag="initial")
        else:
            spec = load_spec(ws)
        rep = score_and_export(ws, spec)
        m = rep["metrics"]
        yield _event(self, ctx,
                     f"[{self.mode}] {m['nodes']} nodes / {m['edges']} edges · score {m['score']:.3f} · "
                     f"text coverage {m['text_coverage']:.0%} · renderer {m['renderer']} · "
                     f"{m['validation_errors']} errors",
                     {"metrics": m})


# =========================================================================== quality gate
class QualityGate(BaseAgent):
    """Stops the refinement loop on PASS+thresholds, plateau, or fatal state."""

    async def _run_async_impl(self, ctx: InvocationContext) -> AsyncGenerator[Event, None]:
        state = ctx.session.state
        if state.get("fatal"):
            yield _event(self, ctx, None, escalate=True)
            return
        m = state.get("metrics") or {}
        crit = _as_dict(state.get("critique")) or {}
        hist = list(state.get("quality_history") or []) + [round(_quality(m), 4)]
        it = int(state.get("refine_iteration", 0)) + 1
        passed = (crit.get("verdict") == "PASS" and m.get("score", 0) >= CONFIG.pass_score
                  and m.get("text_coverage", 0) >= CONFIG.pass_text_coverage and m.get("validation_errors", 1) == 0)
        plateau = (len(hist) > CONFIG.plateau_patience and
                   max(hist[-CONFIG.plateau_patience:]) - max(hist[:-CONFIG.plateau_patience]) < CONFIG.min_improvement)
        stop = passed or plateau
        reason = "passed" if passed else "plateau" if plateau else "continue"
        yield _event(self, ctx, f"Refinement iteration {it}: quality {hist[-1]:.3f} → {reason}.",
                     {"quality_history": hist, "refine_iteration": it, "stop_reason": reason}, escalate=stop)


# =========================================================================== export
class ExportStage(BaseAgent):
    """Publish the BEST version (not merely the last) as files and ADK artifacts."""

    async def _run_async_impl(self, ctx: InvocationContext) -> AsyncGenerator[Event, None]:
        state = ctx.session.state
        if state.get("fatal"):
            return
        ws = ws_from_state(state)
        stem = re.sub(r"[^A-Za-z0-9_-]+", "_", os.path.splitext(state["image_meta"].get("source_name", "diagram"))[0])
        outs = {
            f"{stem}.drawio": ws.p("best.drawio") if os.path.exists(ws.p("best.drawio")) else ws.p("replica.drawio"),
            f"{stem}.spec.json": ws.p("best_spec.json") if os.path.exists(ws.p("best_spec.json")) else ws.p("spec.json"),
            f"{stem}.render.png": ws.p("best_render.png") if os.path.exists(ws.p("best_render.png")) else ws.p("render.png"),
            f"{stem}.report.json": ws.p("report.json"),
        }
        saved = {}
        for name, path in outs.items():
            if not os.path.exists(path):
                continue
            dst = ws.p("out", name)
            shutil.copy(path, dst)
            saved[name] = dst
            if ctx.artifact_service:
                mime = {"drawio": "application/vnd.jgraph.mxfile", "json": "application/json",
                        "png": "image/png"}[name.rsplit(".", 1)[-1]]
                await ctx.artifact_service.save_artifact(
                    app_name=ctx.session.app_name, user_id=ctx.session.user_id, session_id=ctx.session.id,
                    filename=name, artifact=types.Part.from_bytes(data=open(dst, "rb").read(), mime_type=mime))
        best = ws.read_json("best.json", {}) or {}
        m = best.get("metrics", state.get("metrics", {}))
        text = (f"Replica ready: {saved.get(stem + '.drawio')}\n"
                f"nodes {m.get('nodes')} · edges {m.get('edges')} · similarity {m.get('score', 0):.3f} · "
                f"text coverage {m.get('text_coverage', 0):.0%} · stop reason: {state.get('stop_reason', 'n/a')}")
        yield _event(self, ctx, text, {"outputs": saved, "final_metrics": m})
