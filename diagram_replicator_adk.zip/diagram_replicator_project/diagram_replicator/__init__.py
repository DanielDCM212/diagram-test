"""ADK agent that replicates a diagram image as an editable draw.io file."""
from . import agent  # noqa: F401  (adk web / adk run discover `agent.root_agent`)
