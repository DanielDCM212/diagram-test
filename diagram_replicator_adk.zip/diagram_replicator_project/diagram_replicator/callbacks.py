"""before_model_callbacks that attach the right images to each LLM request.

Images are not kept in the conversation history (that would explode the context);
each role receives exactly the pictures it needs, rebuilt from workspace files on
every model call (tool-loop turns included)."""
from __future__ import annotations

import io
import os

from google.genai import types
from PIL import Image

from .config import CONFIG
from .pipeline_ops import side_by_side
from .workspace import ws_from_state

MAX_SIDE = 3072


def _part(path: str, max_side: int = MAX_SIDE) -> types.Part:
    im = Image.open(path).convert("RGB")
    if max(im.size) > max_side:
        s = max_side / max(im.size)
        im = im.resize((int(im.width * s), int(im.height * s)), Image.LANCZOS)
    buf = io.BytesIO()
    im.save(buf, format="PNG", optimize=True)
    return types.Part.from_bytes(data=buf.getvalue(), mime_type="image/png")


def _inject(llm_request, captioned: list[tuple[str, str]]):
    parts = []
    for caption, path in captioned[: CONFIG.max_images_per_request]:
        if path and os.path.exists(path):
            parts.append(types.Part.from_text(text=caption))
            parts.append(_part(path))
    if not parts:
        return
    llm_request.contents = [types.Content(role="user", parts=parts)] + list(llm_request.contents or [])
    # Gemini needs the conversation to end on a user turn before generation.
    if llm_request.contents[-1].role != "user":
        llm_request.contents.append(types.Content(role="user", parts=[types.Part.from_text(text="Continue.")]))


def planner_images(callback_context, llm_request):
    ws = ws_from_state(callback_context.state)
    _inject(llm_request, [("SOURCE IMAGE WITH SOURCE-PIXEL GRID:", ws.p("overview_grid.png")),
                          ("SOURCE IMAGE (clean):", ws.source)])
    return None


def tile_images(callback_context, llm_request):
    st = callback_context.state
    ws = ws_from_state(st)
    tile = st.get("current_tile") or {}
    _inject(llm_request, [(f"TILE {tile.get('id')} (grid labels are SOURCE pixels):", tile.get("path")),
                          ("WHOLE IMAGE FOR CONTEXT (grid):", ws.p("overview_grid.png"))])
    return None


def connector_images(callback_context, llm_request):
    st = callback_context.state
    ws = ws_from_state(st)
    imgs = [("WHOLE IMAGE WITH GRID:", ws.p("overview_grid.png"))]
    for t in st.get("tiles", []):
        imgs.append((f"ZOOMED TILE {t['id']} covering source {t['box']}:", t["path"]))
    _inject(llm_request, imgs)
    return None


def critic_images(callback_context, llm_request):
    st = callback_context.state
    ws = ws_from_state(st)
    rep = ws.read_json("report.json", {})
    imgs = [("SOURCE (grid):", ws.p("overview_grid.png"))]
    from drawio_kit.vision_ops import crop_with_grid
    from PIL import Image as _I
    W, H = _I.open(ws.source).size
    rg = crop_with_grid(ws.p("render.png"), [0, 0, W, H], ws.p("crops", "render_grid.png"),
                        zoom=min(1.0, 1600 / W) if W > 1600 else 1600 / W, step=st.get("overview_step", 50))
    imgs.append(("REPLICA RENDER (grid):", rg["path"]))
    imgs.append(("DIFF HEAT-MAP (red = missing in replica, green = extra):", ws.p("diff.png")))
    for i, box in enumerate(rep.get("worst_regions", [])[:4]):
        imgs.append((f"WORST REGION {i} source {box} – source on top, replica below:",
                     side_by_side(ws, box, f"worst{i}")))
    _inject(llm_request, imgs)
    return None


def fixer_images(callback_context, llm_request):
    st = callback_context.state
    ws = ws_from_state(st)
    crit = st.get("critique") or {}
    issues = crit.get("issues", []) if isinstance(crit, dict) else []
    order = {"high": 0, "medium": 1, "low": 2}
    imgs = []
    for i, it in enumerate(sorted(issues, key=lambda x: order.get(x.get("severity"), 3))[:10]):
        pad = 30
        box = [max(0, it["x0"] - pad), max(0, it["y0"] - pad), it["x1"] + pad, it["y1"] + pad]
        try:
            imgs.append((f"ISSUE {i} ({it.get('category')}) region {box} – source on top, replica below:",
                         side_by_side(ws, box, f"issue{i}")))
        except Exception:
            continue
    _inject(llm_request, imgs)
    return None
