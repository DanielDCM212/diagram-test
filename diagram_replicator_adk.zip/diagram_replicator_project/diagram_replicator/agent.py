"""Root agent: image → exhaustive, measured, self-verified draw.io replica.

Pipeline (mirrors the manual method used for the reference replicas in specs/):

  ingest (CV: [Tesseract OCR], rectangles, line segments, palette, tiles, gridded overview)
    → ocr                   (Gemini OCR on clean tiles when Tesseract is absent)
    → layout_planner        (LLM, whole image → regions, legend, templates, rasters)
    → tiled_extraction      (LLM per zoomed tile, with OCR gap-filling passes)
    → merge                 (dedupe across tiles, snap to measured boxes, hierarchy)
    → connector_extractor   (LLM, whole image + tiles + node ids → edges)
    → assemble              (spec → draw.io → real draw.io render → scores + audit)
    → refinement_loop ×N    [critic (LLM) → fixer (LLM + tools) → rescore → quality_gate]
    → export                (best version as files + ADK artifacts)
"""
from __future__ import annotations

import os
import sys

# make the sibling drawio_kit package importable when run via `adk web` / `adk run`
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

from google.adk.agents import LlmAgent, LoopAgent, SequentialAgent  # noqa: E402
from google.genai import types  # noqa: E402

from . import callbacks, prompts  # noqa: E402
from .config import CONFIG, make_model  # noqa: E402
from .schemas import ConnectorExtraction, Critique, LayoutPlan, TileExtraction  # noqa: E402
from .stages import (AssembleStage, ExportStage, IngestStage, MergeStage, QualityGate,  # noqa: E402
                     TiledExtractionStage)
from .tools import FIXER_TOOLS  # noqa: E402
from .ocr import GeminiOcrStage, OcrResult, ocr_images, ocr_instruction  # noqa: E402


def _skip_if_fatal(callback_context):
    """Short-circuit LLM stages when ingest failed (no image)."""
    if callback_context.state.get("fatal"):
        return types.Content(role="model", parts=[types.Part.from_text(text="skipped: no input image")])
    return None


def _gen_cfg():
    return types.GenerateContentConfig(temperature=CONFIG.temperature, max_output_tokens=CONFIG.max_output_tokens)


def build_root_agent(model_override=None) -> SequentialAgent:
    """model_override: a model string or BaseLlm used for every LLM role (tests, other providers)."""
    def M(name):
        return make_model(model_override if model_override is not None else name)

    ocr_reader = LlmAgent(
        name="ocr_reader", model=M(CONFIG.model_ocr), instruction=ocr_instruction,
        include_contents="none", output_schema=OcrResult, output_key="ocr_result",
        before_model_callback=ocr_images, generate_content_config=_gen_cfg(), before_agent_callback=_skip_if_fatal,
        description="Gemini OCR of one clean tile (used when Tesseract is unavailable).")

    planner = LlmAgent(
        name="layout_planner", model=M(CONFIG.model_planner), instruction=prompts.planner_instruction,
        include_contents="none", output_schema=LayoutPlan, output_key="layout_plan",
        before_model_callback=callbacks.planner_images, generate_content_config=_gen_cfg(), before_agent_callback=_skip_if_fatal,
        description="Whole-image layout analysis: regions, legend, palette, templates, rasters.")

    tile_extractor = LlmAgent(
        name="tile_extractor", model=M(CONFIG.model_extractor), instruction=prompts.tile_instruction,
        include_contents="none", output_schema=TileExtraction, output_key="tile_extraction",
        before_model_callback=callbacks.tile_images, generate_content_config=_gen_cfg(), before_agent_callback=_skip_if_fatal,
        description="Exhaustive element extraction for one zoomed tile.")

    connector_extractor = LlmAgent(
        name="connector_extractor", model=M(CONFIG.model_connectors), instruction=prompts.connector_instruction,
        include_contents="none", output_schema=ConnectorExtraction, output_key="connector_extraction",
        before_model_callback=callbacks.connector_images, generate_content_config=_gen_cfg(), before_agent_callback=_skip_if_fatal,
        description="Extracts every connector with exact endpoints, bends and markers.")

    critic = LlmAgent(
        name="critic", model=M(CONFIG.model_critic), instruction=prompts.critic_instruction,
        include_contents="none", output_schema=Critique, output_key="critique",
        before_model_callback=callbacks.critic_images, generate_content_config=_gen_cfg(), before_agent_callback=_skip_if_fatal,
        description="Compares source vs real draw.io render and lists precise defects.")

    fixer = LlmAgent(
        name="fixer", model=M(CONFIG.model_fixer), instruction=prompts.fixer_instruction,
        include_contents="none", tools=FIXER_TOOLS, output_key="fixer_log",
        before_model_callback=callbacks.fixer_images, generate_content_config=_gen_cfg(), before_agent_callback=_skip_if_fatal,
        description="Applies measured, validated patches to the spec for every critique issue.")

    refinement = LoopAgent(
        name="refinement_loop", max_iterations=CONFIG.max_refine_iterations,
        sub_agents=[critic, fixer, AssembleStage(name="rescore", mode="rescore"), QualityGate(name="quality_gate")])

    return SequentialAgent(
        name="diagram_replicator",
        description="Replicates a diagram image as an editable, high-fidelity draw.io file.",
        sub_agents=[
            IngestStage(name="ingest"),
            GeminiOcrStage(name="ocr", reader=ocr_reader),
            planner,
            TiledExtractionStage(name="tiled_extraction", extractor=tile_extractor),
            MergeStage(name="merge"),
            connector_extractor,
            AssembleStage(name="assemble", mode="initial"),
            refinement,
            ExportStage(name="export"),
        ])


root_agent = build_root_agent()
