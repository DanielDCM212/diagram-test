"""Shared deterministic operations used by pipeline stages AND by the fixer's tools."""
from __future__ import annotations

import json
import os
import shutil
import time

from drawio_kit import compile_spec, render_spec, validate_spec
from drawio_kit.schema import DiagramSpec
from drawio_kit.vision_ops import crop_with_grid, similarity

from .merge import audit
from .workspace import Workspace


def load_spec(ws: Workspace) -> DiagramSpec:
    return DiagramSpec.model_validate(ws.read_json("spec.json"))


def save_spec(ws: Workspace, spec: DiagramSpec, tag: str = "") -> str:
    path = ws.write_json("spec.json", spec.model_dump())
    hist = ws.p("history", f"spec_{int(time.time() * 1000)}{('_' + tag) if tag else ''}.json")
    shutil.copy(path, hist)
    return path


def score_and_export(ws: Workspace, spec: DiagramSpec) -> dict:
    """validate → compile → render (real draw.io if available) → similarity → audit → worst regions."""
    validation = validate_spec(spec)
    xml = compile_spec(spec, ws.source)
    with open(ws.p("replica.drawio"), "w") as f:
        f.write(xml)
    rinfo = render_spec(spec, xml, ws.p("render.png"), ws.source)
    sim = similarity(ws.source, ws.p("render.png"), ws.p("diff.png"))
    cv = ws.read_json("cv.json", {})
    aud = audit(spec, cv.get("ocr_words", []), cv.get("boxes", []), cv.get("lines", []))
    worst = worst_regions(ws, spec)
    metrics = {
        "score": sim.get("score", 0), "ssim": sim.get("ssim"), "edge_f1": sim.get("edge_f1"),
        "edge_recall": sim.get("edge_recall"), "edge_precision": sim.get("edge_precision"),
        "text_coverage": aud["text"]["coverage"], "missing_text_tokens": aud["text"]["missing_count"],
        "unmatched_cv_boxes": aud["unmatched_box_count"], "unmatched_cv_lines": aud["unmatched_line_count"],
        "nodes": len(spec.nodes), "edges": len(spec.edges), "renderer": rinfo["renderer"],
        "validation_errors": len(validation["errors"]), "validation_warnings": len(validation["warnings"]),
    }
    report = {"metrics": metrics, "validation": validation, "audit": aud, "worst_regions": worst}
    ws.write_json("report.json", report)
    _track_best(ws, spec, metrics)
    return report


def _quality(m: dict) -> float:
    return 0.7 * (m.get("score") or 0) + 0.3 * (m.get("text_coverage") or 0) - 0.02 * m.get("validation_errors", 0)


def _track_best(ws: Workspace, spec: DiagramSpec, metrics: dict):
    best = ws.read_json("best.json")
    q = _quality(metrics)
    if best is None or q >= best["quality"]:
        ws.write_json("best_spec.json", spec.model_dump())
        shutil.copy(ws.p("replica.drawio"), ws.p("best.drawio"))
        shutil.copy(ws.p("render.png"), ws.p("best_render.png"))
        ws.write_json("best.json", {"quality": q, "metrics": metrics})


def worst_regions(ws: Workspace, spec: DiagramSpec, n: int = 4) -> list[list[float]]:
    """Grid cells of the diff image with the most 'missing in replica' (red) pixels."""
    import numpy as np
    from PIL import Image
    p = ws.p("diff.png")
    if not os.path.exists(p):
        return []
    a = np.asarray(Image.open(p).convert("RGB")).astype(int)
    red = (a[:, :, 0] > 200) & (a[:, :, 1] < 80)
    H, W = red.shape
    gx, gy = 4, 3
    cells = []
    for i in range(gy):
        for j in range(gx):
            x0, x1 = j * W // gx, (j + 1) * W // gx
            y0, y1 = i * H // gy, (i + 1) * H // gy
            cells.append((int(red[y0:y1, x0:x1].sum()), [x0, y0, x1, y1]))
    cells.sort(key=lambda c: -c[0])
    return [c[1] for c in cells[:n] if c[0] > 0]


def side_by_side(ws: Workspace, box, name: str, render: str = "render.png") -> str:
    """Source crop (top) and replica crop (bottom), both gridded in source pixels."""
    from PIL import Image
    x0, y0, x1, y1 = [int(v) for v in box]
    zoom = max(1.0, min(3.0, 900 / max(1, x1 - x0)))
    a = crop_with_grid(ws.source, box, ws.p("crops", f"{name}_src.png"), zoom=zoom, step=_step(x1 - x0))
    b = crop_with_grid(ws.p(render), box, ws.p("crops", f"{name}_rep.png"), zoom=zoom, step=_step(x1 - x0))
    A, B = Image.open(a["path"]), Image.open(b["path"])
    C = Image.new("RGB", (A.width, A.height + B.height + 6), (255, 0, 0))
    C.paste(A, (0, 0)); C.paste(B, (0, A.height + 6))
    out = ws.p("crops", f"{name}_pair.png")
    C.save(out)
    return out


def _step(span):
    for s in (10, 20, 25, 50, 100, 200):
        if span / s <= 16:
            return s
    return 250


def spec_digest(spec: DiagramSpec, region=None, limit: int = 400) -> str:
    """Compact, LLM-readable listing of the spec (optionally restricted to a region)."""
    def inside(n):
        if not region:
            return True
        x0, y0, x1, y1 = region
        return not (n.x > x1 or n.x + n.w < x0 or n.y > y1 or n.y + n.h < y0)
    lines = [f"canvas {spec.width}x{spec.height} scale={spec.scale} bg={spec.background}"]
    for n in [n for n in spec.nodes if inside(n)][:limit]:
        s = n.style
        lines.append(f"N {n.id} [{n.kind}] ({n.x:.0f},{n.y:.0f},{n.w:.0f},{n.h:.0f}) parent={n.parent} "
                     f"fill={s.fill} stroke={s.stroke}/{s.stroke_width}{' dashed' if s.dashed else ''} "
                     f"font={s.font_size}{' b' if s.bold else ''} {s.text_dir} label={json.dumps(n.label)[:90]}")
    for e in spec.edges[:limit]:
        if region:
            pts = [e.source_point, e.target_point, *e.waypoints]
            if not any(p and region[0] <= p[0] <= region[2] and region[1] <= p[1] <= region[3] for p in pts):
                continue
        lines.append(f"E {e.id} {e.source}->{e.target} sp={e.source_point} tp={e.target_point} "
                     f"wp={e.waypoints} {e.style.color}/{e.style.width}{' dashed' if e.style.dashed else ''} "
                     f"{e.style.start_arrow}->{e.style.end_arrow} label={json.dumps(e.label)}")
    return "\n".join(lines)
