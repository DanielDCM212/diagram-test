"""Deterministic post-processing: merge tile extractions, snap to measurements,
infer hierarchy, attach/orthogonalise connectors, audit completeness, assemble spec."""
from __future__ import annotations

import difflib
import math
import re
from typing import Optional

from drawio_kit.schema import DiagramSpec, Edge, EdgeStyle, Node, Style
from drawio_kit.vision_ops import text_coverage

BOXY = {"rect", "rounded", "container", "pill", "band", "ellipse", "hexagon", "cylinder"}
HEX = re.compile(r"^#[0-9a-fA-F]{6}$|^#[0-9a-fA-F]{3}$")


# ---------------------------------------------------------------- geometry helpers
def area(b):
    return max(0.0, b[2] - b[0]) * max(0.0, b[3] - b[1])


def inter(a, b):
    return area([max(a[0], b[0]), max(a[1], b[1]), min(a[2], b[2]), min(a[3], b[3])])


def iou(a, b):
    i = inter(a, b)
    return i / max(1e-6, area(a) + area(b) - i)


def contains(outer, inner, tol=4):
    return (outer[0] - tol <= inner[0] and outer[1] - tol <= inner[1] and outer[2] + tol >= inner[2]
            and outer[3] + tol >= inner[3])


def bbox(el):
    return [el["x"], el["y"], el["x"] + el["w"], el["y"] + el["h"]]


def norm_text(t):
    return re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", (t or "").replace("html:", ""))).strip().lower()


def text_sim(a, b):
    a, b = norm_text(a), norm_text(b)
    if not a and not b:
        return 1.0
    if not a or not b:
        return 0.0
    return difflib.SequenceMatcher(None, a, b).ratio()


def color(c, default):
    if not c:
        return default
    c = c.strip()
    if c.lower() in ("none", "transparent"):
        return "none"
    if not c.startswith("#"):
        c = "#" + c
    return c.upper() if HEX.match(c) else default


def slug(text, kind):
    s = re.sub(r"[^a-z0-9]+", "_", norm_text(text))[:28].strip("_")
    return s or kind


# ---------------------------------------------------------------- merge tiles
def merge_tile_extractions(tiles: list[dict], extractions: list[dict], cv_boxes: list[dict],
                           image_w: float, image_h: float) -> list[dict]:
    """Return a de-duplicated list of element dicts (ExtractedElement fields + 'tile')."""
    tile_by_id = {t["id"]: t for t in tiles}
    cands = []
    for ex in extractions:
        t = tile_by_id.get(ex.get("tile_id"))
        for el in ex.get("elements", []):
            el = dict(el)
            if el.get("w", 0) <= 0 or el.get("h", 0) <= 0:
                continue
            el["tile"] = ex.get("tile_id")
            # clipped if it touches an inner tile border (not the image border)
            if t:
                x0, y0, x1, y1 = t["box"]
                b = bbox(el)
                touch = ((abs(b[0] - x0) < 4 and x0 > 1) or (abs(b[1] - y0) < 4 and y0 > 1) or
                         (abs(b[2] - x1) < 4 and x1 < image_w - 1) or (abs(b[3] - y1) < 4 and y1 < image_h - 1))
                el["clipped_by_tile"] = bool(el.get("clipped_by_tile")) or touch
            cands.append(el)

    # cluster duplicates (same thing seen in overlapping tiles)
    clusters: list[list[dict]] = []
    for el in sorted(cands, key=lambda e: -e["w"] * e["h"]):
        b = bbox(el)
        placed = False
        for cl in clusters:
            rep = cl[0]
            rb = bbox(rep)
            if el["tile"] == rep["tile"]:
                continue  # same tile → trust the model that they are distinct
            same_kind = (el["kind"] == rep["kind"]) or ({el["kind"], rep["kind"]} <= BOXY)
            ts = text_sim(el.get("label"), rep.get("label"))
            ov = inter(b, rb) / max(1e-6, min(area(b), area(rb)))
            if same_kind and ((iou(b, rb) > 0.55 and ts > 0.5) or (ov > 0.7 and ts > 0.75 and
                                                                   (el["clipped_by_tile"] or rep["clipped_by_tile"]))):
                cl.append(el)
                placed = True
                break
        if not placed:
            clusters.append([el])

    merged = []
    for cl in clusters:
        full = [e for e in cl if not e["clipped_by_tile"]] or cl
        rep = dict(max(full, key=lambda e: (e.get("confidence", 0.5), len(e.get("label", "")))))
        if all(e["clipped_by_tile"] for e in cl) and len(cl) > 1:  # stitch clipped halves
            xs0 = min(e["x"] for e in cl); ys0 = min(e["y"] for e in cl)
            xs1 = max(e["x"] + e["w"] for e in cl); ys1 = max(e["y"] + e["h"] for e in cl)
            rep.update(x=xs0, y=ys0, w=xs1 - xs0, h=ys1 - ys0)
        rep["_sources"] = len(cl)
        merged.append(rep)

    snap_to_cv(merged, cv_boxes)
    return merged


def snap_to_cv(elements: list[dict], cv_boxes: list[dict], min_iou=0.6):
    """Measured rectangles beat estimated ones.

    Edge detection returns BOTH the outer and the inner edge of a border, so a box with a
    4 px border yields two nested rectangles. draw.io geometry is the stroke CENTRE line,
    so when nested outer/inner candidates exist we take their average; otherwise we take the
    candidate closest in size to the model's estimate (never blindly the highest IoU)."""
    for el in elements:
        if el["kind"] not in BOXY and el["kind"] not in ("server_stack", "pipe"):
            continue
        b = bbox(el)
        sw = float(el.get("stroke_width") or 1)
        cands = []
        for cb in cv_boxes:
            c = [cb["x"], cb["y"], cb["x"] + cb["w"], cb["y"] + cb["h"]]
            if iou(b, c) >= min_iou:
                cands.append(c)
        if not cands:
            continue
        outer = max(cands, key=area)
        nested = [c for c in cands if contains(outer, c, tol=1) and c is not outer
                  and max(c[0] - outer[0], c[1] - outer[1], outer[2] - c[2], outer[3] - c[3]) <= 3 * sw + 4]
        if nested:
            inner = min(nested, key=area)
            g = [(o + i) / 2 for o, i in zip(outer, inner)]
        else:
            g = min(cands, key=lambda c: abs((c[2] - c[0]) - el["w"]) + abs((c[3] - c[1]) - el["h"]))
            if max(abs(g[0] - b[0]), abs(g[1] - b[1]), abs(g[2] - b[2]), abs(g[3] - b[3])) > max(8, 0.15 * max(el["w"], el["h"])):
                continue
        el.update(x=g[0], y=g[1], w=g[2] - g[0], h=g[3] - g[1])
        el["_snapped"] = round(iou(b, g), 3)


# ---------------------------------------------------------------- hierarchy + ids
def build_nodes(elements: list[dict], image_path: Optional[str]) -> list[Node]:
    els = [dict(e) for e in elements]
    # promote boxes that contain other boxes into containers
    for a in els:
        if a["kind"] in ("rect", "rounded", "band") and area(bbox(a)) > 0:
            inner = [b for b in els if b is not a and b["kind"] not in ("line",) and
                     contains(bbox(a), bbox(b)) and area(bbox(b)) < 0.8 * area(bbox(a))]
            if len([b for b in inner if b["kind"] != "text"]) >= 1:
                a["_was"] = a["kind"]
                a["kind"] = "container"
    containers = [e for e in els if e["kind"] == "container"]
    # ids
    used, id_of = set(), {}
    for e in els:
        base = slug(e.get("label"), e["kind"])
        nid, k = base, 2
        while nid in used:
            nid, k = f"{base}_{k}", k + 1
        used.add(nid)
        e["_id"] = nid
        id_of[(e.get("tile"), e.get("local_id"))] = nid
    # parents: explicit hint first (same tile), else smallest geometric container
    for e in els:
        parent = None
        hint = e.get("parent_local_id")
        if hint:
            pid = id_of.get((e.get("tile"), hint))
            cand = next((c for c in containers if c["_id"] == pid), None)
            if cand is not None and contains(bbox(cand), bbox(e), tol=10):
                parent = cand
        if parent is None:
            best = None
            for c in containers:
                if c is e or not contains(bbox(c), bbox(e)) or area(bbox(c)) <= area(bbox(e)):
                    continue
                if best is None or area(bbox(c)) < area(bbox(best)):
                    best = c
            parent = best
        e["_parent"] = parent["_id"] if parent else None
    # break any cycles defensively
    by = {e["_id"]: e for e in els}
    for e in els:
        seen, cur = {e["_id"]}, e
        while cur.get("_parent"):
            if cur["_parent"] in seen:
                cur["_parent"] = None
                break
            seen.add(cur["_parent"])
            cur = by[cur["_parent"]]

    nodes = []
    for e in els:
        kind = e["kind"]
        was = e.get("_was", kind)
        rounded = bool(e.get("rounded")) or was in ("rounded", "pill")
        radius = float(e.get("corner_radius") or 0)
        valign = e.get("valign") or ("top" if kind == "container" and was == "container" else "middle")
        st = Style(
            fill=color(e.get("fill"), "#FFFFFF"), stroke=color(e.get("stroke"), "#000000"),
            stroke_width=float(e.get("stroke_width") or 1), dashed=bool(e.get("dashed")),
            rounded=rounded, arc_size=int(round(2 * radius)) if (rounded and radius) else (12 if rounded else None),
            abs_arc=bool(rounded),
            font_size=float(e.get("font_size") or 12), font_color=color(e.get("font_color"), "#000000"),
            bold=bool(e.get("bold")), italic=bool(e.get("italic")), underline=bool(e.get("underline")),
            align=e.get("align") or "center", text_dir=e.get("text_dir") or "horizontal", valign=valign,
        )
        if kind == "text":
            st.fill, st.stroke = "none", "none"
        meta = {"legend": e.get("legend_category", ""), "confidence": e.get("confidence"),
                "sources": e.get("_sources"), "snapped_iou": e.get("_snapped")}
        if kind == "raster":
            meta["knockout"] = "auto"
        nodes.append(Node(
            id=e["_id"], kind=kind, x=float(e["x"]), y=float(e["y"]), w=float(e["w"]), h=float(e["h"]),
            label=e.get("label", "") if kind not in ("raster",) else "", parent=e["_parent"], style=st,
            status_color=color(e.get("status_color"), None) if e.get("status_color") else None,
            crop=[e["x"], e["y"], e["x"] + e["w"], e["y"] + e["h"]] if kind == "raster" else None,
            z=5 if kind in ("raster", "app_icon", "db_icon") else (1 if kind == "text" else 0),
            meta={k: v for k, v in meta.items() if v not in (None, "")}))
    return nodes


# ---------------------------------------------------------------- connectors
def _nearest_perimeter(n: Node, pt):
    x = min(max(pt[0], n.x), n.x + n.w)
    y = min(max(pt[1], n.y), n.y + n.h)
    inside = n.x < pt[0] < n.x + n.w and n.y < pt[1] < n.y + n.h
    if inside:  # push to closest side
        d = {"l": pt[0] - n.x, "r": n.x + n.w - pt[0], "t": pt[1] - n.y, "b": n.y + n.h - pt[1]}
        side = min(d, key=d.get)
        x = n.x if side == "l" else n.x + n.w if side == "r" else pt[0]
        y = n.y if side == "t" else n.y + n.h if side == "b" else pt[1]
    return [x, y], math.hypot(x - pt[0], y - pt[1])


def _auto_attach(nodes, pt, tol=12):
    best, bd = None, tol
    for n in nodes:
        if n.kind in ("text", "line", "raster"):
            continue
        _, d = _nearest_perimeter(n, pt)
        if d <= bd and (best is None or n.w * n.h < best.w * best.h or d < bd):
            best, bd = n, d
    return best


def _orthogonalise(pts, tol=4):
    out = [list(p) for p in pts]
    for i in range(1, len(out)):
        a, b = out[i - 1], out[i]
        if abs(a[0] - b[0]) <= tol:
            b[0] = a[0]
        if abs(a[1] - b[1]) <= tol:
            b[1] = a[1]
    return out


def build_edges(extraction: dict, nodes: list[Node], snap_tol=30) -> list[Edge]:
    by = {n.id: n for n in nodes}
    edges, used = [], set()
    for raw in extraction.get("edges", []):
        sp = [raw["source_point"]["x"], raw["source_point"]["y"]]
        tp = [raw["target_point"]["x"], raw["target_point"]["y"]]
        wps = [[p["x"], p["y"]] for p in raw.get("waypoints", [])]
        src = by.get(raw.get("source_id") or "") or _auto_attach(nodes, sp)
        tgt = by.get(raw.get("target_id") or "") or _auto_attach(nodes, tp)
        if src is not None:
            q, d = _nearest_perimeter(src, sp)
            if d <= snap_tol:
                sp = q
        if tgt is not None:
            q, d = _nearest_perimeter(tgt, tp)
            if d <= snap_tol:
                tp = q
        path = _orthogonalise([sp] + wps + [tp])
        sp, wps, tp = path[0], path[1:-1], path[-1]
        eid = raw.get("id") or f"e{len(edges) + 1}"
        base, k = re.sub(r"[^A-Za-z0-9_\-]", "_", eid), 2
        eid = base
        while eid in used or eid in by:
            eid, k = f"{base}_{k}", k + 1
        used.add(eid)
        edges.append(Edge(
            id=eid, source=src.id if src else None, target=tgt.id if tgt else None, source_point=sp,
            target_point=tp, waypoints=wps, label=raw.get("label", ""),
            style=EdgeStyle(color=color(raw.get("color"), "#000000"), width=float(raw.get("width") or 1),
                            dashed=bool(raw.get("dashed")), start_arrow=raw.get("start_arrow") or "none",
                            end_arrow=raw.get("end_arrow") or "block", arrow_size=6 + float(raw.get("width") or 1)),
            meta={"legend": raw.get("legend_category", ""), "confidence": raw.get("confidence")}))
    return edges


# ---------------------------------------------------------------- audit
def _seg_dist(p, a, b):
    ax, ay = a; bx, by_ = b; px, py = p
    dx, dy = bx - ax, by_ - ay
    L = dx * dx + dy * dy
    t = 0 if L == 0 else max(0, min(1, ((px - ax) * dx + (py - ay) * dy) / L))
    return math.hypot(px - (ax + t * dx), py - (ay + t * dy))


def audit(spec: DiagramSpec, ocr_words: list[dict], cv_boxes: list[dict], cv_lines: list[dict]) -> dict:
    """Completeness audit against the measurements (independent of the LLM)."""
    labels = [n.label for n in spec.nodes] + [e.label for e in spec.edges]
    tc = text_coverage(labels, ocr_words)
    GLYPHS = ("raster", "server_stack", "app_icon", "db_icon", "pipe", "text")
    rasters = [[n.x - 2, n.y - 2, n.x + n.w + 2, n.y + n.h + 2] for n in spec.nodes if n.kind in GLYPHS]
    node_boxes = [[n.x, n.y, n.x + n.w, n.y + n.h] for n in spec.nodes]
    unmatched_boxes = []
    for cb in cv_boxes:
        b = [cb["x"], cb["y"], cb["x"] + cb["w"], cb["y"] + cb["h"]]
        if area(b) < 400 or area(b) > 0.8 * spec.width * spec.height:
            continue
        if any(inter(b, r) / area(b) > 0.5 for r in rasters):
            continue
        if max((iou(b, nb) for nb in node_boxes), default=0) < 0.35:
            unmatched_boxes.append({k: cb[k] for k in ("x", "y", "w", "h", "fill")})
    # polylines of the spec (edges + node borders) to check CV line coverage
    segs = []
    for e in spec.edges:
        pts = [e.source_point, *e.waypoints, e.target_point]
        pts = [p for p in pts if p]
        segs += list(zip(pts, pts[1:]))
    for n in spec.nodes:
        x0, y0, x1, y1 = n.x, n.y, n.x + n.w, n.y + n.h
        segs += [((x0, y0), (x1, y0)), ((x1, y0), (x1, y1)), ((x1, y1), (x0, y1)), ((x0, y1), (x0, y0))]
    unmatched_lines = []
    for ln in cv_lines:
        if ln["length"] < 40:
            continue
        mid = ((ln["x1"] + ln["x2"]) / 2, (ln["y1"] + ln["y2"]) / 2)
        if any(r[0] <= mid[0] <= r[2] and r[1] <= mid[1] <= r[3] for r in rasters):
            continue
        if min((_seg_dist(mid, a, b) for a, b in segs), default=1e9) > 8:
            unmatched_lines.append(ln)
    return {"text": tc, "unmatched_cv_boxes": unmatched_boxes[:60], "unmatched_cv_lines": unmatched_lines[:60],
            "unmatched_box_count": len(unmatched_boxes), "unmatched_line_count": len(unmatched_lines)}
