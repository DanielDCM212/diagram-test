"""Build the four hand-made replicas: .drawio files + previews + scores."""
import json, os, sys
sys.path.insert(0, os.path.dirname(__file__))
from drawio_kit import compile_spec, compile_pages, validate_spec, render_preview, render_spec
from drawio_kit.vision_ops import similarity
from specs import d1_customer_service, d2_dragon1_ea_framework, d3_its_architecture, d4_technology_component_view

UP = "/mnt/user-data/uploads"
JOBS = [(d1_customer_service, f"{UP}/IMG_0266.JPG", "01_manage_customer_service"),
        (d2_dragon1_ea_framework, f"{UP}/IMG_0265.PNG", "02_dragon1_ea_framework"),
        (d3_its_architecture, f"{UP}/IMG_0264.JPG", "03_its_architecture"),
        (d4_technology_component_view, f"{UP}/FullSizeRender.jpeg", "04_technology_component_view")]
out = sys.argv[1] if len(sys.argv) > 1 else "out"
os.makedirs(out, exist_ok=True)
pages, report = [], {}
for mod, img, name in JOBS:
    spec = mod.build(img)
    v = validate_spec(spec)
    xml = compile_spec(spec, img)
    open(f"{out}/{name}.drawio", "w").write(xml)
    json.dump(spec.model_dump(), open(f"{out}/{name}.spec.json", "w"), indent=1)
    r = render_spec(spec, xml, f"{out}/{name}.render.png", img)   # real draw.io when installed
    sim = similarity(img, f"{out}/{name}.render.png", f"{out}/{name}.diff.png")
    sim["renderer"] = r["renderer"]
    report[name] = {"validation": v, "similarity": sim}
    pages.append((spec, img))
    print(name, v["stats"]["nodes"], v["stats"]["edges"], "errors", v["errors"], "warn", len(v["warnings"]), sim)
    for w in v["warnings"]:
        print("   W", w)
open(f"{out}/all_diagrams.drawio", "w").write(compile_pages(pages))
json.dump(report, open(f"{out}/report.json", "w"), indent=1)
