# diagram_replicator: image → editable draw.io (Google ADK)

The package turns a diagram image (a screenshot, a PDF export or a photographed slide) into
an editable `.drawio` file. It does this with the same method used to build the four
reference replicas in `specs/`:

1. **Measure before guessing.** OCR text boxes, edge-detected rectangles and line
   segments, the colour palette, and zoomed crops carrying a grid labelled in
   **source pixels**.
2. **Describe, don't draw.** The LLM writes a validated *DiagramSpec* (JSON, in source
   pixels). It never writes mxGraph XML. `drawio_kit` compiles the spec
   deterministically:
   - parent-relative geometry and composite glyphs (servers, app/DB icons, pipes);
   - raster crops with the background knocked out, for clip-art and logos;
   - connectors that stay attached but leave and land at the exact measured pixels.
3. **Verify with the real renderer.** The .drawio is rendered by draw.io desktop
   (headless) and compared against the source with SSIM, an edge-F1 score, a diff
   heat-map and an OCR text-coverage audit. It is then critiqued and patched until it
   passes or stops improving.

## Pipeline (`diagram_replicator/agent.py`)

| # | Agent | Type | What it does |
|---|---|---|---|
| 1 | `ingest` | custom | Finds the image (inline, path, state or artifact) and creates the workspace. Runs OCR (words + lines), rectangle detection with fill/stroke colours, line detection with a dashed hint and a k-means palette. Makes adaptive tiles and a gridded overview. |
| 2 | `layout_planner` | LLM → `LayoutPlan` | Regions/zones/legend, palette meanings, repeated templates, raster regions, connector styles, expected counts, scale. |
| 3 | `tiled_extraction` | custom loop over `tile_extractor` (LLM → `TileExtraction`) | Extracts every element per zoomed tile. **Gap-fill passes** re-ask for the OCR text a tile still does not cover. Retries on bad output. |
| 4 | `merge` | custom | Removes duplicates across tile overlaps and stitches elements split by tile edges. **Stroke-aware snapping** to measured rectangles (the average of the outer and inner border edge gives the stroke centre line). Promotes boxes to containers and infers parents. Adds any raster the planner saw but tiles missed. Assigns stable ids. |
| 5 | `connector_extractor` | LLM → `ConnectorExtraction` | Extracts every line/arrow, with ids, exact endpoints, bends, markers and legend category. It sees the whole image, all tiles and the node list. |
| 6 | `assemble` | custom | Snaps endpoints to borders, straightens near-orthogonal paths and validates. Compiles and renders with draw.io, then scores and audits. Tracks the best version. |
| 7 | `refinement_loop` | LoopAgent | `critic` (LLM → `Critique`) sees the source, the replica, the diff and worst-region pairs. `fixer` (LLM + tools: `apply_spec_patch`, `measure_region`, `sample_colors`, `get_spec`, `rebuild_and_score`) edits the spec. `rescore` re-renders it. `quality_gate` exits on PASS + thresholds, or on a plateau. |
| 8 | `export` | custom | Writes the **best** version (not the last) as files and ADK artifacts: `.drawio`, `.spec.json`, `.render.png`, `.report.json`. |

Images are attached per role by `before_model_callback`s. They are never kept in the
conversation history. Large payloads live in the workspace, and session state holds only
paths and summaries.

## OCR without Tesseract

OCR is pluggable (`DR_OCR_BACKEND`):

| value | behaviour |
|---|---|
| `auto` (default) | Tesseract if the binary is installed, otherwise Gemini |
| `gemini` | the `ocr` stage (`diagram_replicator/ocr.py`) runs an `ocr_reader` LlmAgent (default `gemini-2.5-flash`) |
| `tesseract` | Tesseract only (fails fast if it's missing) |
| `none` | no OCR grounding (not recommended: it disables gap-fill passes and the text audit) |

With `gemini`, the `ocr_reader` agent works like this:

- It receives **clean, grid-free, upscaled, overlapping tiles** (about 700 source px each).
- It returns one entry per visual line, with Gemini's native `box_2d = [ymin, xmin, ymax, xmax]` normalised to 0–1000.
- The stage converts those boxes back to source pixels and de-duplicates lines seen in two overlapping tiles, keeping the un-clipped reading.
- It derives word boxes and writes the same `cv.json` fields that Tesseract fills.

Everything downstream is unchanged: prompts, gap-fill passes, the text-coverage audit, and `measure_region`, which filters the stored lines instead of re-running OCR.

Trade-offs:

- It costs one extra (cheap) model call per OCR tile.
- Box precision is a few pixels looser than Tesseract on clean screenshots.
- It is usually *more* accurate on photos and small or rotated text.
- The text audit is then model-checks-model. It is still a separate, transcription-only call, but it is less independent than Tesseract.

## Run

```bash
pip install -r requirements.txt           # tesseract optional; draw.io desktop + xvfb recommended
cp .env.example .env                      # set GOOGLE_API_KEY (or Vertex vars)
python run.py img1.png img2.jpg --out results --combine results/all.drawio
adk web .                                 # or interactive: pick "diagram_replicator", attach an image
```

To use other models, set `DR_MODEL_*=litellm:anthropic/claude-...` (the role
instructions are model-agnostic).

## Offline end-to-end test (no API key)

```bash
python -m tests.test_pipeline_offline 1 2 3 4
DR_OCR_BACKEND=gemini python -m tests.test_pipeline_offline 1 4   # exercise the Gemini-OCR path
```

`tests/golden_llm.py` is a stand-in `BaseLlm` that answers every role from the golden
specs. It even makes real tool calls in the fixer loop. The test exercises the full
chain: callbacks, tiling, merge, snapping, tools, loop exit, artifacts and real draw.io
rendering.

With perfect extractions, the pipeline reproduces the hand-made replicas' scores
(real draw.io render vs source):

| image | hand replica | pipeline (golden LLM) |
|---|---|---|
| 1 customer service | 0.958 | 0.953 |
| 2 Dragon1 EA | 0.863 | 0.882 |
| 3 ITS (500 px JPEG) | 0.789 | 0.793 |
| 4 component view (photo) | 0.918 | 0.901 |

Absolute scores are lower on tiny or JPEG sources because SSIM punishes compression noise
and font rendering. Use them to compare versions of the same diagram, not across diagrams.

## Layout

```
drawio_kit/        schema · compiler · validate · preview (Pillow) · render (draw.io CLI) · vision_ops (CV)
diagram_replicator/ agent · stages · merge · pipeline_ops · prompts · callbacks · tools · schemas · config
specs/             the four hand-authored reference replicas (also used as golden tests)
build_replicas.py  regenerates the reference .drawio files + renders + report
tests/             golden stand-in LLM + offline end-to-end test
```
