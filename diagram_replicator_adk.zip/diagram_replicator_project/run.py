"""CLI: replicate one or more diagram images into draw.io files.

    python run.py diagram1.png diagram2.jpg --out results/ [--combine all.drawio]

Uses the real models configured in diagram_replicator/config.py (Gemini by default;
set GOOGLE_API_KEY or Vertex AI env vars). For a no-key smoke test run:
    python -m tests.test_pipeline_offline 1 2 3 4
"""
from __future__ import annotations

import argparse
import asyncio
import mimetypes
import os
import shutil
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from google.adk.runners import InMemoryRunner  # noqa: E402
from google.genai import types  # noqa: E402

from diagram_replicator.agent import root_agent  # noqa: E402
from drawio_kit import compile_pages  # noqa: E402
from drawio_kit.schema import DiagramSpec  # noqa: E402

APP = "diagram_replicator"


async def replicate(runner: InMemoryRunner, image: str, out_dir: str, verbose: bool) -> dict:
    session = await runner.session_service.create_session(app_name=APP, user_id="cli",
                                                          state={"input_image_path": os.path.abspath(image)})
    mime = mimetypes.guess_type(image)[0] or "image/png"
    msg = types.Content(role="user", parts=[
        types.Part.from_text(text="Replicate this diagram as an editable draw.io file, exhaustively."),
        types.Part.from_bytes(data=open(image, "rb").read(), mime_type=mime)])
    async for ev in runner.run_async(user_id="cli", session_id=session.id, new_message=msg):
        if ev.content and ev.content.parts and ev.content.parts[0].text:
            if verbose or ev.author in ("ingest", "merge", "assemble", "rescore", "quality_gate", "export",
                                        "tiled_extraction"):
                print(f"  [{ev.author}] {ev.content.parts[0].text[:300]}")
    s = await runner.session_service.get_session(app_name=APP, user_id="cli", session_id=session.id)
    stem = os.path.splitext(os.path.basename(image))[0]
    result = {"image": image}
    for name, path in (s.state.get("outputs") or {}).items():
        ext = name.split(".", 1)[1]
        dst = os.path.join(out_dir, f"{stem}.{ext}")
        shutil.copy(path, dst)
        result[ext] = dst
    result["metrics"] = s.state.get("final_metrics")
    return result


async def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("images", nargs="+")
    ap.add_argument("--out", default="results")
    ap.add_argument("--combine", default=None, help="also write one multi-page .drawio")
    ap.add_argument("-v", "--verbose", action="store_true")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    runner = InMemoryRunner(agent=root_agent, app_name=APP)
    results = []
    for img in a.images:
        print(f"▶ {img}")
        r = await replicate(runner, img, a.out, a.verbose)
        print(f"  → {r.get('drawio')}  metrics={r.get('metrics')}")
        results.append(r)
    if a.combine:
        pages = []
        for r in results:
            if r.get("spec.json"):
                spec = DiagramSpec.model_validate_json(open(r["spec.json"]).read())
                pages.append((spec, spec.source_image if spec.source_image and os.path.exists(spec.source_image)
                              else r["image"]))
        open(a.combine, "w").write(compile_pages(pages))
        print(f"combined → {a.combine}")


if __name__ == "__main__":
    asyncio.run(main())
