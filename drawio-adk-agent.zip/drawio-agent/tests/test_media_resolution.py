"""Regression test for: 'per part media resolution is not supported for this model'."""
import asyncio, os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from diagram_agent import vision
from diagram_agent.schema import EdgesOnly


class FakeResp:
    text = '{"edges": []}'


class FakeModels:
    def __init__(self, reject):
        self.reject, self.seen = reject, []

    async def generate_content(self, model, contents, config):
        per_part = any(getattr(p, "media_resolution", None) for p in contents if not isinstance(p, str))
        mode = "part" if per_part else "config" if config.media_resolution else "none"
        self.seen.append(mode)
        if mode in self.reject:
            raise RuntimeError("400 INVALID_ARGUMENT. Unable to submit request because per part media "
                               "resolution is not supported for this model.")
        return FakeResp()


class FakeClient:
    def __init__(self, reject):
        self.aio = type("A", (), {})()
        self.aio.models = FakeModels(reject)


def run(reject, model):
    fc = FakeClient(reject)
    vision._client = fc
    img = vision._img(b"\x89PNG fake")
    out = asyncio.run(vision._ask([img, "prompt"], EdgesOnly, model=model))
    assert out.edges == []
    return fc.aio.models.seen


seen = run({"part"}, "model-a")
print("rejects per-part      :", seen); assert seen == ["part", "config"]
seen = run({"part"}, "model-a")
print("second call same model:", seen); assert seen == ["config"]          # remembered, no failed call
seen = run({"part", "config"}, "model-b")
print("rejects both          :", seen); assert seen == ["part", "config", "none"]
seen = run(set(), "model-c")
print("supports per-part     :", seen); assert seen == ["part"]
print("PASS media resolution fallback")
