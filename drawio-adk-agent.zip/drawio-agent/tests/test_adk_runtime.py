"""Drives the real ADK Runner + upload plugin + artifact service, with a scripted fake LLM
(and fixture vision output) so no Google credentials are needed."""
import asyncio, io, json, os, re, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from typing import AsyncGenerator
from PIL import Image
from google.adk.models.base_llm import BaseLlm
from google.adk.models.llm_response import LlmResponse
from google.adk.runners import InMemoryRunner
from google.genai import types
from diagram_agent import agent as agent_mod, vision
from diagram_agent.schema import Diagram, Patch


class ScriptedLlm(BaseLlm):
    model: str = "scripted"
    async def generate_content_async(self, llm_request, stream=False) -> AsyncGenerator[LlmResponse, None]:
        last = llm_request.contents[-1]
        if any(p.function_response for p in last.parts):
            r = last.parts[0].function_response.response
            yield LlmResponse(content=types.Content(role="model", parts=[types.Part(
                text=f"Done: {r['artifacts']['drawio']} with {r['nodes']} shapes and {r['edges']} connectors.")]))
            return
        text = " ".join(p.text or "" for c in llm_request.contents for p in c.parts)
        name = re.search(r'\[Uploaded Artifact: "([^"]+)"\]', text)
        yield LlmResponse(content=types.Content(role="model", parts=[types.Part(function_call=types.FunctionCall(
            name="convert_image_to_drawio", args={"image_artifact": name.group(1)}))]))


async def main():
    fx = json.load(open(os.path.join(os.path.dirname(__file__), "fixtures", "its_architecture.json")))
    d = Diagram.model_validate(fx["diagram"])
    async def fake_extract(png, w, h): return d.model_copy(deep=True)
    async def fake_review(o, r, dd): return Patch(done=True, notes="Looks faithful.")
    vision.extract, vision.review = fake_extract, fake_review

    agent_mod.root_agent.model = ScriptedLlm()
    runner = InMemoryRunner(app=agent_mod.app)
    s = await runner.session_service.create_session(app_name="diagram_agent", user_id="u")
    buf = io.BytesIO(); Image.new("RGB", (1200, 800), "white").save(buf, "JPEG")
    msg = types.Content(role="user", parts=[types.Part(text="convert this"),
        types.Part(inline_data=types.Blob(mime_type="image/jpeg", data=buf.getvalue(), display_name="IMG_0264.JPG"))])
    async for ev in runner.run_async(user_id="u", session_id=s.id, new_message=msg):
        for p in (ev.content.parts if ev.content else []):
            if p.text: print("agent:", p.text)
            if p.function_call: print("tool call:", p.function_call.name, p.function_call.args)
    names = await runner.artifact_service.list_artifact_keys(app_name="diagram_agent", user_id="u", session_id=s.id)
    print("artifacts:", sorted(names))
    assert {"IMG_0264.JPG", "IMG_0264.drawio", "IMG_0264_model.json"} <= set(names)

asyncio.run(main())
print("PASS adk runtime")
