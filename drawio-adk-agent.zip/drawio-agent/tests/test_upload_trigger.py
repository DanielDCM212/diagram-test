"""Regression test for: 'agent says it can't see the image'.
The fake LLM reproduces the failure: it never calls a tool on its own, it just asks for a description."""
import asyncio, io, json, os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from typing import AsyncGenerator
from PIL import Image
from google.adk.models.base_llm import BaseLlm
from google.adk.models.llm_response import LlmResponse
from google.adk.runners import InMemoryRunner
from google.genai import types
from diagram_agent import agent as agent_mod, vision
from diagram_agent.schema import Diagram, Patch


class StubbornLlm(BaseLlm):
    model: str = "stubborn"
    calls: int = 0
    async def generate_content_async(self, llm_request, stream=False) -> AsyncGenerator[LlmResponse, None]:
        self.calls += 1
        last = llm_request.contents[-1]
        if any(p.function_response for p in last.parts):
            r = last.parts[0].function_response.response
            text = f"Done: {r.get('artifacts', {}).get('drawio')}" if r.get("status") == "ok" else f"Error: {r}"
        else:
            text = "I can't see the image. Could you describe it?"
        yield LlmResponse(content=types.Content(role="model", parts=[types.Part(text=text)]))


async def run_once(message_parts):
    fx = json.load(open(os.path.join(os.path.dirname(__file__), "fixtures", "its_architecture.json")))
    d = Diagram.model_validate(fx["diagram"])
    async def fake_extract(png, w, h): return d.model_copy(deep=True)
    async def fake_review(o, r, dd): return Patch(done=True)
    vision.extract, vision.review = fake_extract, fake_review
    agent_mod.root_agent.model = StubbornLlm()
    runner = InMemoryRunner(app=agent_mod.app)
    s = await runner.session_service.create_session(app_name="diagram_agent", user_id="u")
    replies, calls = [], []
    async for ev in runner.run_async(user_id="u", session_id=s.id,
                                     new_message=types.Content(role="user", parts=message_parts)):
        for p in (ev.content.parts if ev.content else []):
            if p.text: replies.append(p.text)
            if p.function_call: calls.append(p.function_call.args)
    return replies, calls


def image_part(display_name):
    buf = io.BytesIO(); Image.new("RGB", (1200, 800), "white").save(buf, "JPEG")
    return types.Part(inline_data=types.Blob(mime_type="image/jpeg", data=buf.getvalue(), display_name=display_name))


replies, calls = asyncio.run(run_once([types.Part(text="convert this"), image_part("IMG_0264.JPG")]))
print("with name   :", calls, replies)
assert calls and replies[-1].startswith("Done"), "tool was not called"

replies, calls = asyncio.run(run_once([image_part(None)]))   # client sent no displayName, no text
print("without name:", calls, replies)
assert calls and replies[-1].startswith("Done")
print("PASS upload trigger")
