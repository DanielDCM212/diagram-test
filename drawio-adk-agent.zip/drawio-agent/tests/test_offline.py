"""Runs without any Gemini access: vision calls are replaced by fixtures (stand-ins for model output)."""
import asyncio
import io
import json
import os
import sys
import xml.etree.ElementTree as ET

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from PIL import Image

from diagram_agent import agent, vision
from diagram_agent.build import build_drawio
from diagram_agent.render import render_png, renderer_available
from diagram_agent.schema import Diagram, Node, Patch

FIX = os.path.join(os.path.dirname(__file__), "fixtures")
OUT = os.path.join(os.path.dirname(__file__), "out")
os.makedirs(OUT, exist_ok=True)


def load(name):
    raw = json.load(open(os.path.join(FIX, name)))
    return Diagram.model_validate(raw["diagram"]), raw["width"], raw["height"]


def test_build_and_parents():
    d, w, h = load("capability_map.json")
    xml = build_drawio(d, w, h)
    root = ET.fromstring(xml)
    cells = {c.get("id"): c for c in root.iter("mxCell")}
    # capability boxes must be nested by geometry alone
    assert cells["req"].get("parent") == "plan", cells["req"].get("parent")
    assert cells["plan"].get("parent") == "mcs"
    assert sum(1 for c in cells.values() if c.get("edge") == "1") == len(d.edges)


def test_cleaning():
    d = Diagram(nodes=[Node(id="a", label="A", kind="box", box_2d=[0, 0, 100, 100]),
                       Node(id="a", label="dup", kind="box", box_2d=[0, 0, 100, 100])],
                edges=[{"source": "a", "target": "missing"}, {"source": "a", "target": "a"}])
    root = ET.fromstring(build_drawio(d, 1000, 1000))
    assert [c.get("id") for c in root.iter("mxCell") if c.get("vertex")] == ["a"]
    assert not [c for c in root.iter("mxCell") if c.get("edge")]


class FakeToolContext:
    """Just enough of ADK's ToolContext for the tools."""
    def __init__(self):
        self.artifacts, self.state = {}, {}

    async def save_artifact(self, filename, artifact, custom_metadata=None):
        self.artifacts.setdefault(filename, []).append(artifact)
        return len(self.artifacts[filename]) - 1

    async def load_artifact(self, filename, version=None):
        v = self.artifacts.get(filename)
        return v[-1] if v else None

    async def list_artifacts(self):
        return list(self.artifacts)


def test_agent_tools_end_to_end():
    from google.genai import types
    d, w, h = load("its_architecture.json")

    async def fake_extract(png, iw, ih):
        return d.model_copy(deep=True)

    async def fake_review(orig, rendered, diagram):
        assert rendered[:4] == b"\x89PNG"
        return Patch(upsert_nodes=[Node(id="added_by_review", label="Added by reviewer", kind="box",
                                        box_2d=[960, 10, 995, 200], fill="#FFE0E0")], done=True,
                     notes="Added a missing box.")

    async def fake_revise(orig, diagram, instructions):
        return Patch(remove_node_ids=["added_by_review"], done=True, notes=f"Applied: {instructions}")

    vision.extract, vision.review, vision.revise = fake_extract, fake_review, fake_revise

    buf = io.BytesIO(); Image.new("RGB", (w, h), "white").save(buf, "JPEG")
    ctx = FakeToolContext()
    asyncio.run(ctx.save_artifact("IMG_0264.JPG", types.Part.from_bytes(data=buf.getvalue(), mime_type="image/jpeg")))

    res = asyncio.run(agent.convert_image_to_drawio("IMG_0264.JPG", ctx))
    assert res["status"] == "ok", res
    assert "IMG_0264.drawio" in ctx.artifacts
    if renderer_available():
        assert res["review_rounds"] == 1 and "IMG_0264_preview.png" in ctx.artifacts
        png = ctx.artifacts["IMG_0264_preview.png"][-1].inline_data.data
        open(os.path.join(OUT, "agent_preview.png"), "wb").write(png)

    res2 = asyncio.run(agent.revise_diagram("remove the reviewer's box", ctx))
    assert res2["status"] == "ok" and len(ctx.artifacts["IMG_0264.drawio"]) == 2
    assert "added_by_review" not in ctx.artifacts["IMG_0264.drawio"][-1].inline_data.data.decode()

    listed = asyncio.run(agent.list_uploaded_images(ctx))
    assert listed["uploads"] == ["IMG_0264.JPG"]
    assert asyncio.run(agent.convert_image_to_drawio("nope.png", ctx))["status"] == "error"


def test_render_fixtures():
    if not renderer_available():
        return
    for name in ("capability_map.json", "its_architecture.json"):
        d, w, h = load(name)
        png = asyncio.run(render_png(build_drawio(d, w, h)))
        assert png and png[:4] == b"\x89PNG"
        open(os.path.join(OUT, name.replace(".json", ".png")), "wb").write(png)


if __name__ == "__main__":
    for fn in [test_build_and_parents, test_cleaning, test_render_fixtures, test_agent_tools_end_to_end]:
        fn(); print("PASS", fn.__name__)
