"""Run the pipeline on a local image without ADK (handy for batch jobs and quality tuning).
usage: python cli.py path/to/image.jpg [out_dir]"""
import asyncio, os, sys
from diagram_agent import pipeline

async def main(path, out_dir):
    os.makedirs(out_dir, exist_ok=True)
    stem = os.path.splitext(os.path.basename(path))[0]
    res = await pipeline.convert(open(path, "rb").read(), name=stem)
    open(os.path.join(out_dir, f"{stem}.drawio"), "w", encoding="utf-8").write(res.drawio_xml)
    open(os.path.join(out_dir, f"{stem}_model.json"), "w").write(res.diagram.model_dump_json(indent=1))
    if res.preview_png:
        open(os.path.join(out_dir, f"{stem}_preview.png"), "wb").write(res.preview_png)
    print(f"{stem}: {len(res.diagram.nodes)} nodes, {len(res.diagram.edges)} edges, "
          f"{res.review_rounds} review rounds", *res.notes, sep="\n  ")

if __name__ == "__main__":
    asyncio.run(main(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else "out"))
