"""Deterministic Diagram -> draw.io XML. No LLM in here: same input, same file."""
import re
import xml.etree.ElementTree as ET

from .schema import Diagram, Node

TARGET_WIDTH = 1600  # px width of the generated page

ICON_SHAPES = {
    "server": "shape=mxgraph.cisco.servers.fileserver;fillColor=#6B6B6B;strokeColor=#FFFFFF;",
    "database": "shape=cylinder3;boundedLbl=1;size=6;fillColor=#1E6FD9;strokeColor=#0D3F8A;",
    "user": "shape=mxgraph.basic.person;fillColor=#8E6BBF;strokeColor=none;",
    "users": "shape=mxgraph.office.users.users;fillColor=#8E6BBF;strokeColor=none;",
    "computer": "shape=mxgraph.cisco.computers_and_peripherals.pc;fillColor=#036897;strokeColor=#FFFFFF;",
    "car": "shape=mxgraph.signs.transportation.car_4;fillColor=#E8A33D;strokeColor=none;",
    "bus": "shape=mxgraph.signs.transportation.bus_2;fillColor=#E8A33D;strokeColor=none;",
    "truck": "shape=mxgraph.signs.transportation.truck_6;fillColor=#E8A33D;strokeColor=none;",
    "cloud": "ellipse;shape=cloud;fillColor=#FFFFFF;strokeColor=#333333;",
    "phone": "shape=mxgraph.android.phone2;fillColor=#FFFFFF;strokeColor=#333333;",
    "ui_window": "rounded=0;fillColor=#1E88C8;strokeColor=#0B4F7A;",
}
SIDES = {"top": (0.5, 0), "bottom": (0.5, 1), "left": (0, 0.5), "right": (1, 0.5)}
HEX = re.compile(r"^#[0-9a-fA-F]{6}$")


def _color(value, default):
    if value == "none":
        return "none"
    return value if value and HEX.match(value) else default


class Box:
    """Node geometry in page pixels."""
    def __init__(self, node: Node, img_w: int, img_h: int, scale: float):
        ymin, xmin, ymax, xmax = (max(0, min(1000, v)) for v in (node.box_2d + [0, 0, 0, 0])[:4])
        if xmax < xmin: xmin, xmax = xmax, xmin
        if ymax < ymin: ymin, ymax = ymax, ymin
        self.x = round(xmin / 1000 * img_w * scale, 1)
        self.y = round(ymin / 1000 * img_h * scale, 1)
        self.w = max(round((xmax - xmin) / 1000 * img_w * scale, 1), 8)
        self.h = max(round((ymax - ymin) / 1000 * img_h * scale, 1), 8)

    @property
    def area(self): return self.w * self.h

    def overlap(self, o):
        ix = max(0, min(self.x + self.w, o.x + o.w) - max(self.x, o.x))
        iy = max(0, min(self.y + self.h, o.y + o.h) - max(self.y, o.y))
        return ix * iy


def infer_parents(diagram: Diagram, boxes: dict) -> dict:
    """Parent = smallest container that covers >= 90% of the node. Deterministic, no LLM."""
    containers = sorted((n for n in diagram.nodes if n.kind == "container"), key=lambda n: boxes[n.id].area)
    parents = {}
    for n in diagram.nodes:
        b = boxes[n.id]
        for c in containers:
            cb = boxes[c.id]
            if c.id != n.id and cb.area > b.area and b.overlap(cb) >= 0.9 * b.area:
                parents[n.id] = c.id
                break
    return parents


def _font_size(node: Node, box: Box) -> int:
    lines = max(1, node.label.count("\n") + 1)
    longest = max((len(l) for l in node.label.split("\n")), default=1) or 1
    across = box.h if node.vertical_text else box.w
    fit_width = across / (longest * 0.62)
    if node.kind == "container":          # title only uses a strip of the container
        return int(max(8, min(13, fit_width)))
    along = box.w if node.vertical_text else box.h
    chars = max(1, len(node.label.replace("\n", "")))
    wrapped = (0.55 * box.w * box.h / (chars * 0.62 * 1.35)) ** 0.5   # text may wrap inside the box
    size = min(along / (lines * 1.9), max(fit_width, wrapped))
    return int(max(8, min(14 if node.kind == "text" else 18, size)))


def harmonise_fonts(nodes, sizes: dict) -> dict:
    """Similar boxes should share a font size: cap every box at the diagram's median box size."""
    box_sizes = sorted(sizes[n.id] for n in nodes if n.kind in ("box", "cylinder", "ellipse"))
    if not box_sizes:
        return sizes
    median = box_sizes[len(box_sizes) // 2]
    return {nid: (min(sz, median) if kind in ("box", "cylinder", "ellipse") else sz)
            for (nid, sz), kind in zip(sizes.items(), (n.kind for n in nodes))}


def infer_side(a: "Box", b: "Box") -> tuple[str, str]:
    """Pick exit/entry sides from relative position: along the axis with the biggest gap."""
    gap_x = max(b.x - (a.x + a.w), a.x - (b.x + b.w))
    gap_y = max(b.y - (a.y + a.h), a.y - (b.y + b.h))
    if gap_x >= gap_y:
        return ("right", "left") if b.x > a.x else ("left", "right")
    return ("bottom", "top") if b.y > a.y else ("top", "bottom")


def node_style(node: Node, box: Box, font_size: int | None = None) -> str:
    k = node.kind
    if k == "icon":
        s = ICON_SHAPES.get((node.icon_hint or "").lower(), "rounded=1;fillColor=#DDDDDD;strokeColor=#666666;")
        return s + "html=1;verticalLabelPosition=bottom;verticalAlign=top;"
    if k == "text":
        s = "text;html=1;strokeColor=none;fillColor=none;whiteSpace=wrap;"
    elif k == "cylinder":
        s = "shape=cylinder3;boundedLbl=1;size=8;whiteSpace=wrap;html=1;"
    elif k == "ellipse":
        s = "ellipse;whiteSpace=wrap;html=1;"
    elif k in ("hbus", "vbus"):
        s = "rounded=1;arcSize=50;whiteSpace=wrap;html=1;"
    elif k == "container":
        s = f"rounded={int(bool(node.rounded))};arcSize=4;whiteSpace=wrap;html=1;container=1;collapsible=0;"
    else:
        s = f"rounded={int(bool(node.rounded))};arcSize=10;whiteSpace=wrap;html=1;"
    if k != "text":
        default_fill = "none" if k == "container" else "#FFFFFF"
        s += f"fillColor={_color(node.fill, default_fill)};strokeColor={_color(node.stroke, '#333333')};"
        s += f"strokeWidth={node.stroke_width or 1};"
    s += f"fontColor={_color(node.font_color, '#000000')};fontSize={font_size or _font_size(node, box)};"
    if node.dashed: s += "dashed=1;dashPattern=6 4;"
    if node.bold: s += "fontStyle=1;"
    if node.vertical_text or k == "vbus": s += "horizontal=0;"
    pos = node.label_position or ("top" if k == "container" else "center")
    if pos == "top": s += "verticalAlign=top;spacingTop=2;"
    elif pos == "bottom": s += "verticalAlign=bottom;spacingBottom=4;"
    elif pos == "left": s += "align=left;spacingLeft=8;"
    return s


def anchors(a: Box, b: Box, sides: tuple[str, str]):
    """Exit/entry points as fractions. Where the two shapes overlap on the cross axis, both ends use the
    middle of that overlap, giving a straight line (e.g. box -> long bus bar)."""
    def frac(v, lo, size): return round(min(0.95, max(0.05, (v - lo) / size)), 3)
    out = []
    horizontal = sides[0] in ("left", "right")
    if horizontal:
        lo, hi = max(a.y, b.y), min(a.y + a.h, b.y + b.h)
        y = (lo + hi) / 2 if hi > lo else a.y + a.h / 2
        for box, side in ((a, sides[0]), (b, sides[1])):
            out.append((1.0 if side == "right" else 0.0, frac(y, box.y, box.h)))
    else:
        lo, hi = max(a.x, b.x), min(a.x + a.w, b.x + b.w)
        x = (lo + hi) / 2 if hi > lo else a.x + a.w / 2
        for box, side in ((a, sides[0]), (b, sides[1])):
            out.append((frac(x, box.x, box.w), 1.0 if side == "bottom" else 0.0))
    return out


def edge_style(e, sides: tuple[str, str] = ("auto", "auto"), points=None) -> str:
    marker = {"none": "none", "arrow": "block", "dot": "oval"}
    s = "edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;"
    s += f"startArrow={marker[e.start or 'none']};startFill=1;endArrow={marker[e.end or 'arrow']};endFill=1;"
    s += f"strokeColor={_color(e.color, '#000000')};strokeWidth=1.2;"
    if e.dashed: s += "dashed=1;"
    for k, (prefix, side) in enumerate((("exit", sides[0]), ("entry", sides[1]))):
        if side in SIDES:
            x, y = points[k] if points else SIDES[side]
            s += f"{prefix}X={x};{prefix}Y={y};{prefix}Dx=0;{prefix}Dy=0;"
    return s


def clean(diagram: Diagram) -> Diagram:
    """Drop duplicate ids, dangling / self / duplicate edges."""
    seen, nodes = set(), []
    for n in diagram.nodes:
        if n.id not in seen and len(n.box_2d) == 4:
            seen.add(n.id); nodes.append(n)
    pairs, edges = set(), []
    for e in diagram.edges:
        key = (e.source, e.target)
        if e.source in seen and e.target in seen and e.source != e.target and key not in pairs:
            pairs.add(key); edges.append(e)
    return diagram.model_copy(update={"nodes": nodes, "edges": edges})


def build_drawio(diagram: Diagram, img_w: int, img_h: int, page_name: str = "Page-1") -> str:
    diagram = clean(diagram)
    scale = TARGET_WIDTH / img_w
    boxes = {n.id: Box(n, img_w, img_h, scale) for n in diagram.nodes}
    parents = infer_parents(diagram, boxes)
    fonts = harmonise_fonts(diagram.nodes, {n.id: _font_size(n, boxes[n.id]) for n in diagram.nodes})

    mxfile = ET.Element("mxfile", host="app.diagrams.net", agent="adk-diagram-agent")
    d = ET.SubElement(mxfile, "diagram", name=page_name, id="page1")
    gm = ET.SubElement(d, "mxGraphModel", grid="1", gridSize="10", guides="1", tooltips="1", connect="1",
                       arrows="1", fold="1", page="1", pageScale="1", pageWidth=str(TARGET_WIDTH),
                       pageHeight=str(int(img_h * scale)), math="0", shadow="0")
    root = ET.SubElement(gm, "root")
    ET.SubElement(root, "mxCell", id="0")
    ET.SubElement(root, "mxCell", id="1", parent="0")

    # parents must be emitted before children, and big shapes first so they sit behind
    order = sorted(diagram.nodes, key=lambda n: -boxes[n.id].area)
    for n in order:
        b, pid = boxes[n.id], parents.get(n.id)
        ox, oy = (boxes[pid].x, boxes[pid].y) if pid else (0, 0)
        cell = ET.SubElement(root, "mxCell", id=n.id, value=n.label.replace("\n", "<br>"),
                             style=node_style(n, b, fonts[n.id]), vertex="1", parent=pid or "1")
        ET.SubElement(cell, "mxGeometry", x=f"{b.x - ox:.1f}", y=f"{b.y - oy:.1f}",
                      width=f"{b.w:.1f}", height=f"{b.h:.1f}", **{"as": "geometry"})

    for i, e in enumerate(diagram.edges):
        auto = infer_side(boxes[e.source], boxes[e.target])
        sides = (e.source_side if e.source_side in SIDES else auto[0],
                 e.target_side if e.target_side in SIDES else auto[1])
        # a line into a container/bus it sits inside has no meaningful side: let draw.io route it
        pts = None
        if parents.get(e.source) == e.target or parents.get(e.target) == e.source:
            sides = ("auto", "auto")
        elif (sides[0] in ("left", "right")) == (sides[1] in ("left", "right")):
            pts = anchors(boxes[e.source], boxes[e.target], sides)
        cell = ET.SubElement(root, "mxCell", id=f"edge_{i}", value=e.label or "", style=edge_style(e, sides, pts),
                             edge="1", parent="1", source=e.source, target=e.target)
        ET.SubElement(cell, "mxGeometry", relative="1", **{"as": "geometry"})
    return ET.tostring(mxfile, encoding="unicode")
