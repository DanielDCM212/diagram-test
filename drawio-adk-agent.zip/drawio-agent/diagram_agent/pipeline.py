"""extract -> build -> render -> review loop. Knows nothing about ADK, so it can be tested and run from a CLI."""
import logging
import os
from dataclasses import dataclass, field

from . import vision
from .build import build_drawio
from .render import normalise_image, render_png
from .schema import Diagram

MAX_REVIEW_ROUNDS = int(os.getenv("MAX_REVIEW_ROUNDS", "2"))
log = logging.getLogger(__name__)


@dataclass
class Result:
    drawio_xml: str
    preview_png: bytes | None
    diagram: Diagram
    width: int
    height: int
    review_rounds: int = 0
    notes: list[str] = field(default_factory=list)


async def _build_and_render(d: Diagram, w: int, h: int, name: str):
    xml = build_drawio(d, w, h, name)
    return xml, await render_png(xml)


async def convert(image_bytes: bytes, name: str = "Diagram") -> Result:
    png, w, h = normalise_image(image_bytes)
    diagram = await vision.extract(png, w, h)
    xml, preview = await _build_and_render(diagram, w, h, name)
    res = Result(xml, preview, diagram, w, h)

    for _ in range(MAX_REVIEW_ROUNDS):
        if preview is None:
            res.notes.append("Renderer not available: skipped visual self-review.")
            break
        patch = await vision.review(png, preview, diagram)
        res.review_rounds += 1
        if patch.notes:
            res.notes.append(patch.notes)
        if patch.done and not (patch.upsert_nodes or patch.add_edges or patch.remove_node_ids or patch.remove_edges):
            break
        diagram = vision.apply_patch(diagram, patch)
        xml, preview = await _build_and_render(diagram, w, h, name)
        if patch.done:
            break
    res.drawio_xml, res.preview_png, res.diagram = xml, preview, diagram
    return res


async def revise(original_image: bytes, diagram: Diagram, instructions: str, name: str = "Diagram") -> Result:
    png, w, h = normalise_image(original_image)
    patch = await vision.revise(png, diagram, instructions)
    diagram = vision.apply_patch(diagram, patch)
    xml, preview = await _build_and_render(diagram, w, h, name)
    return Result(xml, preview, diagram, w, h, notes=[patch.notes] if patch.notes else [])
