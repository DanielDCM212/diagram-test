NODES_PROMPT = """You are converting a picture of a technical diagram into a structured model.
The picture may be a clean export, a screenshot, or a phone photo of a screen/slide (possibly at an angle).

List EVERY visible shape as a node:
- Boxes with text -> kind "box" (use "cylinder" for database drums, "ellipse" for circles).
- Any shape that visually encloses other shapes (groups, zones, swimlanes, trust boundaries) -> kind "container".
  Include its title as the label and set label_position (usually "top").
- Long bars that many boxes connect to (buses, gateways drawn as bars) -> "hbus" or "vbus".
- Free-standing text (zone names, captions, notes) -> kind "text".
- Pictograms (servers, people, vehicles, UI icons) -> kind "icon" with icon_hint.
- Include the legend's sample shapes as normal nodes so the legend is reproduced too.

Rules:
- box_2d = [ymin, xmin, ymax, xmax] normalised to 0-1000 over the WHOLE image. Be tight and precise.
- Copy text EXACTLY, including application IDs and numbers in parentheses. Use \\n where the text wraps.
- Colours as #RRGGBB, as they appear (ignore photo glare/tint: a white box photographed looks grey but is #FFFFFF).
- dashed=true for dashed borders; stroke colour red for red dashed boundaries, etc.
- Ids: short, unique, snake_case, derived from the label (e.g. "apigee_edge", "brd_cards").
- If the diagram has a legend, fill `legend` with each entry's name and meaning.
Do NOT list connector lines here."""

TILE_PROMPT = """This is a zoomed-in crop of a larger diagram. List every box/text/icon fully visible in this crop
(skip anything cut off at the crop edge, and skip large enclosing containers).
box_2d is normalised 0-1000 over THIS CROP. Copy text exactly. Same field rules as before:
""" + NODES_PROMPT.split("Rules:")[1]

EDGES_PROMPT = """Here is the diagram again, plus the list of nodes already extracted from it (id, label, box_2d):

{nodes}

List EVERY connector line as an edge between node ids:
- Follow each line from end to end, including through bends and junctions. When one line splits into
  several, emit one edge per destination.
- If a line ends on a bar/bus or a container rather than a box, use that bar/container's id.
- source = the end without an arrowhead; target = the end with the arrowhead. For arrowheads at both ends
  set start="arrow" and end="arrow". A filled circle at an end is "dot".
- source_side/target_side = which side of the shape the line attaches to (or "auto" if unclear).
- color as #RRGGBB, dashed if the line is dashed. If the diagram has a legend, set legend_class to the
  matching legend entry (e.g. "API", "Batch", "Event or Message").
Only use ids from the list."""

REVIEW_PROMPT = """You are checking a draw.io reconstruction against the original diagram.
Image 1 = ORIGINAL. Image 2 = RECONSTRUCTION rendered from the model below.

Current model (box_2d is in ORIGINAL-image coordinates, 0-1000):
{model}

Find meaningful differences only: missing or extra shapes, wrong/misspelled text, shapes clearly in the wrong place
or wrong size, wrong colours/dashing, missing, extra or wrongly-connected lines, arrow direction wrong.
Ignore: fonts, anti-aliasing, tiny offsets, line routing paths (routing is automatic), photo tint.
Return a Patch. To fix a node, put the FULL corrected node in upsert_nodes with the same id.
Set done=true if the reconstruction is faithful enough that a human would accept it."""

REVISE_PROMPT = """The user wants to change the reconstructed diagram. Their request:
\"\"\"{instructions}\"\"\"

Image 1 is the ORIGINAL picture for reference. Current model (box_2d is 0-1000 over the original):
{model}

Return a Patch that implements exactly the user's request and nothing else. Set done=true."""
