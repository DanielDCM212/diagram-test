"""Schema the vision model fills in. Coordinates are Gemini-native:
box_2d = [ymin, xmin, ymax, xmax], normalised 0-1000 over the source image."""
from typing import Literal, Optional
from pydantic import BaseModel, Field

NodeKind = Literal["box", "container", "text", "cylinder", "ellipse", "hbus", "vbus", "icon"]
Side = Literal["auto", "top", "bottom", "left", "right"]
Marker = Literal["none", "arrow", "dot"]


class Node(BaseModel):
    id: str = Field(description="Short unique snake_case id, e.g. 'cards_esb'")
    label: str = Field(default="", description="Exact visible text. Use \\n for line breaks. Keep IDs/numbers verbatim.")
    kind: NodeKind = Field(description="container = a box that visually encloses other boxes; hbus/vbus = long bar that connects many boxes")
    box_2d: list[int] = Field(description="[ymin, xmin, ymax, xmax] normalised to 0-1000")
    fill: Optional[str] = Field(default=None, description="Fill colour as #RRGGBB, or 'none' if transparent")
    stroke: Optional[str] = Field(default=None, description="Border colour as #RRGGBB, or 'none'")
    font_color: Optional[str] = None
    dashed: Optional[bool] = False
    stroke_width: Optional[float] = 1
    rounded: Optional[bool] = True
    bold: Optional[bool] = False
    vertical_text: Optional[bool] = Field(default=False, description="True when the text is rotated 90 degrees")
    label_position: Optional[Literal["center", "top", "bottom", "left"]] = Field(
        default="center", description="Where the label sits inside the shape (containers usually 'top')")
    icon_hint: Optional[str] = Field(default=None, description="For kind=icon: server, database, user, users, computer, car, bus, truck, cloud, phone, ui_window")


class Edge(BaseModel):
    source: str = Field(description="Node id where the line starts (the end WITHOUT the arrowhead, unless both ends have one)")
    target: str = Field(description="Node id the line points to")
    source_side: Optional[Side] = "auto"
    target_side: Optional[Side] = "auto"
    start: Optional[Marker] = "none"
    end: Optional[Marker] = "arrow"
    color: Optional[str] = "#000000"
    dashed: Optional[bool] = False
    label: Optional[str] = None
    legend_class: Optional[str] = Field(default=None, description="Legend entry this line style matches, if the diagram has a legend")


class LegendItem(BaseModel):
    name: str
    meaning: str


class Diagram(BaseModel):
    title: Optional[str] = None
    legend: list[LegendItem] = []
    nodes: list[Node] = []
    edges: list[Edge] = []


class NodesOnly(BaseModel):
    title: Optional[str] = None
    legend: list[LegendItem] = []
    nodes: list[Node]


class EdgesOnly(BaseModel):
    edges: list[Edge]


class Patch(BaseModel):
    """Corrections produced by the reviewer or by a user revision request."""
    upsert_nodes: list[Node] = Field(default=[], description="New nodes, or full replacement of an existing node with the same id")
    remove_node_ids: list[str] = []
    add_edges: list[Edge] = []
    remove_edges: list[Edge] = Field(default=[], description="Only source/target matter")
    done: bool = Field(description="True when no meaningful differences remain")
    notes: str = Field(default="", description="One or two sentences on what changed / what is still off")
