"""ADK entry point: `adk web` / `adk api_server` discover the `app` object below."""
import os
import re

from google.adk.agents import LlmAgent
from google.adk.apps import App
from google.adk.plugins.save_files_as_artifacts_plugin import SaveFilesAsArtifactsPlugin
from google.adk.tools import ToolContext
from google.genai import types

from . import pipeline
from .schema import Diagram

DRAWIO_MIME = "application/vnd.jgraph.mxfile"
OUTPUT_SUFFIXES = (".drawio", "_preview.png", "_model.json")


def _stem(name: str) -> str:
    base = re.sub(r"\.[A-Za-z0-9]+$", "", name.split("/")[-1])
    return re.sub(r"[^A-Za-z0-9_-]+", "_", base).strip("_") or "diagram"


async def _save_outputs(tool_context: ToolContext, stem: str, res: pipeline.Result) -> dict:
    files = {}
    files["drawio"] = f"{stem}.drawio"
    v = await tool_context.save_artifact(files["drawio"], types.Part.from_bytes(
        data=res.drawio_xml.encode("utf-8"), mime_type=DRAWIO_MIME))
    files["model"] = f"{stem}_model.json"
    await tool_context.save_artifact(files["model"], types.Part.from_bytes(
        data=res.diagram.model_dump_json(indent=1).encode("utf-8"), mime_type="application/json"))
    if res.preview_png:
        files["preview"] = f"{stem}_preview.png"
        await tool_context.save_artifact(files["preview"], types.Part.from_bytes(
            data=res.preview_png, mime_type="image/png"))
    return {"status": "ok", "artifacts": files, "version": v,
            "nodes": len(res.diagram.nodes), "edges": len(res.diagram.edges),
            "review_rounds": res.review_rounds, "notes": res.notes}


async def list_uploaded_images(tool_context: ToolContext) -> dict:
    """Lists files the user has uploaded in this session (excluding generated outputs)."""
    names = await tool_context.list_artifacts()
    return {"uploads": [n for n in names if not n.endswith(OUTPUT_SUFFIXES)]}


async def convert_image_to_drawio(image_artifact: str, tool_context: ToolContext) -> dict:
    """Converts an uploaded diagram image into an editable draw.io file.

    Args:
        image_artifact: Artifact name of the uploaded image (as shown in the upload placeholder).
    Returns:
        Artifact names of the generated .drawio file, PNG preview and JSON model, plus review notes.
    """
    part = await tool_context.load_artifact(image_artifact)
    if part is None or part.inline_data is None:
        return {"status": "error", "message": f"No uploaded image named '{image_artifact}'.",
                "uploads": (await list_uploaded_images(tool_context))["uploads"]}
    stem = _stem(image_artifact)
    try:
        res = await pipeline.convert(part.inline_data.data, name=stem)
    except Exception as exc:  # surface a useful message to the model/user instead of a stack trace
        return {"status": "error", "message": f"Conversion failed: {exc}"}
    tool_context.state["current_diagram"] = {"image": image_artifact, "stem": stem}
    return await _save_outputs(tool_context, stem, res)


async def revise_diagram(instructions: str, tool_context: ToolContext) -> dict:
    """Applies the user's corrections to the most recently generated diagram.

    Args:
        instructions: What to change, in the user's words (e.g. "the arrow from SSG goes to Experian, not TU").
    """
    cur = tool_context.state.get("current_diagram")
    if not cur:
        return {"status": "error", "message": "No diagram has been generated in this session yet."}
    img = await tool_context.load_artifact(cur["image"])
    model = await tool_context.load_artifact(f"{cur['stem']}_model.json")
    diagram = Diagram.model_validate_json(model.inline_data.data)
    try:
        res = await pipeline.revise(img.inline_data.data, diagram, instructions, name=cur["stem"])
    except Exception as exc:
        return {"status": "error", "message": f"Revision failed: {exc}"}
    return await _save_outputs(tool_context, cur["stem"], res)


root_agent = LlmAgent(
    name="diagram_agent",
    model=os.getenv("AGENT_MODEL", "gemini-3.5-flash"),
    description="Turns pictures of architecture/technical diagrams into editable draw.io files.",
    instruction="""You convert images of diagrams into editable draw.io files.

- When the user uploads an image (you will see a placeholder like [Uploaded Artifact: "photo.jpg"]), call
  convert_image_to_drawio with that name. If you are unsure of the name, call list_uploaded_images.
- Conversion takes a minute or two; tell the user it is running only if they ask.
- Afterwards, reply briefly: the .drawio file name, how many shapes and connectors were found, and any review
  notes that mention remaining problems. Suggest they open the preview and tell you what is wrong.
- When the user describes a correction ("box X is missing", "that arrow points the other way", "make the zones
  red dashed"), call revise_diagram with their request in their own words. New versions keep the same file name.
- Never invent diagram content yourself; all changes go through the tools.""",
    tools=[convert_image_to_drawio, revise_diagram, list_uploaded_images],
)

app = App(name="diagram_agent", root_agent=root_agent, plugins=[SaveFilesAsArtifactsPlugin()])
