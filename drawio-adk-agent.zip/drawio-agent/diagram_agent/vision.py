"""All Gemini calls live here. Everything else in the pipeline is deterministic."""
import asyncio
import io
import json
import os
import re

from google import genai
from google.genai import types
from PIL import Image

from . import prompts
from .schema import Diagram, EdgesOnly, Node, NodesOnly, Patch

EXTRACTION_MODEL = os.getenv("EXTRACTION_MODEL", "gemini-3.1-pro-preview")
REVIEW_MODEL = os.getenv("REVIEW_MODEL", EXTRACTION_MODEL)
MEDIA_RES = os.getenv("MEDIA_RESOLUTION", "MEDIA_RESOLUTION_HIGH")
TILE_THRESHOLD = int(os.getenv("TILE_THRESHOLD", "1800"))  # px; larger images also get a 2x2 zoomed pass

_client = None


def client() -> genai.Client:
    """Uses GOOGLE_API_KEY, or Vertex AI when GOOGLE_GENAI_USE_VERTEXAI=true (+ project/location)."""
    global _client
    if _client is None:
        _client = genai.Client()
    return _client


def _img(png: bytes) -> types.Part:
    return types.Part.from_bytes(data=png, mime_type="image/png",
                                 media_resolution=types.PartMediaResolutionLevel(MEDIA_RES))


def _json_schema(model_cls) -> dict:
    """Pydantic schema -> plain JSON Schema: $refs inlined, defaults/titles dropped
    (defaults are re-applied by Pydantic when parsing the answer)."""
    raw = model_cls.model_json_schema()
    defs = raw.pop("$defs", {})

    def walk(node):
        if isinstance(node, dict):
            if "$ref" in node:
                return walk(defs[node["$ref"].split("/")[-1]])
            return {k: walk(v) for k, v in node.items() if k not in ("default", "title")}
        if isinstance(node, list):
            return [walk(v) for v in node]
        return node
    return walk(raw)


async def _ask(parts: list, schema, model: str = EXTRACTION_MODEL, retries: int = 2):
    config = types.GenerateContentConfig(response_mime_type="application/json",
                                         response_json_schema=_json_schema(schema))
    for attempt in range(retries + 1):
        resp = await client().aio.models.generate_content(model=model, contents=parts, config=config)
        try:
            return schema.model_validate_json(resp.text)
        except Exception:
            if attempt == retries:
                raise


def _iou(a, b):
    ix = max(0, min(a[3], b[3]) - max(a[1], b[1]))
    iy = max(0, min(a[2], b[2]) - max(a[0], b[0]))
    inter = ix * iy
    ua = (a[2] - a[0]) * (a[3] - a[1]) + (b[2] - b[0]) * (b[3] - b[1]) - inter
    return inter / ua if ua > 0 else 0


def _slug(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", text.lower()).strip("_")[:30] or "node"


async def _tile_pass(png: bytes, w: int, h: int) -> list[Node]:
    """2x2 zoomed crops with overlap: much better text reading on dense diagrams and photos."""
    img = Image.open(io.BytesIO(png))
    ov = 0.12
    tiles = []
    for ty in (0, 1):
        for tx in (0, 1):
            x0 = int(max(0, (tx * 0.5 - (ov if tx else 0)) * w)); x1 = int(min(w, ((tx + 1) * 0.5 + (0 if tx else ov)) * w))
            y0 = int(max(0, (ty * 0.5 - (ov if ty else 0)) * h)); y1 = int(min(h, ((ty + 1) * 0.5 + (0 if ty else ov)) * h))
            buf = io.BytesIO(); img.crop((x0, y0, x1, y1)).save(buf, "PNG")
            tiles.append(((x0, y0, x1, y1), buf.getvalue()))
    results = await asyncio.gather(*[_ask([_img(t), prompts.TILE_PROMPT], NodesOnly) for _, t in tiles],
                                   return_exceptions=True)
    out = []
    for ((x0, y0, x1, y1), _), res in zip(tiles, results):
        if isinstance(res, Exception):
            continue
        tw, th = x1 - x0, y1 - y0
        for n in res.nodes:
            if n.kind == "container" or len(n.box_2d) != 4:
                continue
            a, b, c, d = n.box_2d
            n.box_2d = [round((y0 + a / 1000 * th) / h * 1000), round((x0 + b / 1000 * tw) / w * 1000),
                        round((y0 + c / 1000 * th) / h * 1000), round((x0 + d / 1000 * tw) / w * 1000)]
            out.append(n)
    return out


def _merge_tiles(base: list[Node], extra: list[Node]) -> list[Node]:
    ids = {n.id for n in base}
    for t in extra:
        best, score = None, 0
        for n in base:
            s = _iou(n.box_2d, t.box_2d)
            if s > score:
                best, score = n, s
        if best is not None and score > 0.3:
            # same shape seen closer up: trust the zoomed-in text if it is richer
            if score > 0.5 and best.kind == t.kind and len(t.label) > len(best.label):
                best.label = t.label
            continue
        nid = t.id if t.id not in ids else f"{_slug(t.label)}_{len(ids)}"
        ids.add(nid)
        base.append(t.model_copy(update={"id": nid}))
    return base


def _nodes_brief(nodes: list[Node]) -> str:
    return "\n".join(json.dumps({"id": n.id, "label": n.label, "kind": n.kind, "box_2d": n.box_2d}) for n in nodes)


async def extract(png: bytes, w: int, h: int) -> Diagram:
    whole = _ask([_img(png), prompts.NODES_PROMPT], NodesOnly)
    if max(w, h) >= TILE_THRESHOLD:
        first, tiled = await asyncio.gather(whole, _tile_pass(png, w, h))
        nodes = _merge_tiles(list(first.nodes), tiled)
    else:
        first = await whole
        nodes = list(first.nodes)
    edges = await _ask([_img(png), prompts.EDGES_PROMPT.format(nodes=_nodes_brief(nodes))], EdgesOnly)
    return Diagram(title=first.title, legend=first.legend, nodes=nodes, edges=edges.edges)


async def review(original_png: bytes, rendered_png: bytes, diagram: Diagram) -> Patch:
    return await _ask([_img(original_png), _img(rendered_png),
                       prompts.REVIEW_PROMPT.format(model=diagram.model_dump_json(exclude_defaults=True))],
                      Patch, REVIEW_MODEL)


async def revise(original_png: bytes, diagram: Diagram, instructions: str) -> Patch:
    return await _ask([_img(original_png),
                       prompts.REVISE_PROMPT.format(instructions=instructions,
                                                    model=diagram.model_dump_json(exclude_defaults=True))],
                      Patch, REVIEW_MODEL)


def apply_patch(d: Diagram, p: Patch) -> Diagram:
    nodes = {n.id: n for n in d.nodes}
    for rid in p.remove_node_ids:
        nodes.pop(rid, None)
    for n in p.upsert_nodes:
        nodes[n.id] = n
    drop = {(e.source, e.target) for e in p.remove_edges}
    edges = [e for e in d.edges if (e.source, e.target) not in drop] + list(p.add_edges)
    return d.model_copy(update={"nodes": list(nodes.values()), "edges": edges})
