"""All Gemini calls live here. Everything else in the pipeline is deterministic."""
import asyncio
import io
import json
import logging
import os
import re

from google import genai
from google.genai import types
from PIL import Image

from . import prompts
from .schema import Diagram, EdgesOnly, Node, NodesOnly, Patch

EXTRACTION_MODEL = os.getenv("EXTRACTION_MODEL", "gemini-3.1-pro-preview")
REVIEW_MODEL = os.getenv("REVIEW_MODEL", EXTRACTION_MODEL)
MEDIA_RES = os.getenv("MEDIA_RESOLUTION", "MEDIA_RESOLUTION_HIGH")   # or "off"
# How the resolution hint is sent. Not every model/endpoint supports per-image hints, so "auto" tries
# per-image -> request-wide -> none, and remembers what worked for each model.
MEDIA_RES_MODE = os.getenv("MEDIA_RESOLUTION_MODE", "auto")          # auto | part | config | none
_MODES = ["part", "config", "none"]
_working_mode: dict[str, str] = {}
TILE_THRESHOLD = int(os.getenv("TILE_THRESHOLD", "1800"))  # px; larger images also get a 2x2 zoomed pass

_client = None


def client() -> genai.Client:
    """Uses GOOGLE_API_KEY, or Vertex AI when GOOGLE_GENAI_USE_VERTEXAI=true (+ project/location)."""
    global _client
    if _client is None:
        _client = genai.Client()
    return _client


def _img(png: bytes) -> types.Part:
    return types.Part.from_bytes(data=png, mime_type="image/png")


def _is_media_res_error(exc: Exception) -> bool:
    msg = str(exc).lower().replace("_", " ")
    return "media resolution" in msg


def _modes_for(model: str) -> list[str]:
    if MEDIA_RES.lower() == "off":
        return ["none"]
    if model in _working_mode:
        return [_working_mode[model]]
    start = MEDIA_RES_MODE if MEDIA_RES_MODE in _MODES else "part"
    return _MODES[_MODES.index(start):]


def _apply_mode(parts: list, config: types.GenerateContentConfig, mode: str):
    if mode == "part":
        level = types.PartMediaResolutionLevel(MEDIA_RES)
        parts = [types.Part(inline_data=p.inline_data, media_resolution=types.PartMediaResolution(level=level))
                 if isinstance(p, types.Part) and p.inline_data else p for p in parts]
    elif mode == "config":
        # request-wide enum has no ULTRA_HIGH
        name = "MEDIA_RESOLUTION_HIGH" if "ULTRA" in MEDIA_RES else MEDIA_RES
        config = config.model_copy(update={"media_resolution": types.MediaResolution(name)})
    return parts, config


async def _generate(parts: list, config: types.GenerateContentConfig, model: str):
    modes = _modes_for(model)
    for i, mode in enumerate(modes):
        p, c = _apply_mode(parts, config, mode)
        try:
            resp = await client().aio.models.generate_content(model=model, contents=p, config=c)
            _working_mode[model] = mode
            return resp
        except Exception as exc:
            if _is_media_res_error(exc) and i < len(modes) - 1:
                logging.getLogger(__name__).warning(
                    "%s rejected media resolution mode '%s'; falling back to '%s'", model, mode, modes[i + 1])
                continue
            raise


def _json_schema(model_cls) -> dict:
    """Pydantic schema -> plain JSON Schema: $refs inlined, defaults/titles dropped
    (defaults are re-applied by Pydantic when parsing the answer)."""
    raw = model_cls.model_json_schema()
    defs = raw.pop("$defs", {})

    def walk(node):
        if isinstance(node, dict):
            if "$ref" in node:
                return walk(defs[node["$ref"].split("/")[-1]])
            return {k: walk(v) for k, v in node.items() if k not in ("default", "title")}
        if isinstance(node, list):
            return [walk(v) for v in node]
        return node
    return walk(raw)


async def _ask(parts: list, schema, model: str = EXTRACTION_MODEL, retries: int = 2):
    config = types.GenerateContentConfig(response_mime_type="application/json",
                                         response_json_schema=_json_schema(schema))
    for attempt in range(retries + 1):
        resp = await _generate(parts, config, model)
        try:
            return schema.model_validate_json(resp.text)
        except Exception:
            if attempt == retries:
                raise


def _iou(a, b):
    ix = max(0, min(a[3], b[3]) - max(a[1], b[1]))
    iy = max(0, min(a[2], b[2]) - max(a[0], b[0]))
    inter = ix * iy
    ua = (a[2] - a[0]) * (a[3] - a[1]) + (b[2] - b[0]) * (b[3] - b[1]) - inter
    return inter / ua if ua > 0 else 0


def _slug(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", text.lower()).strip("_")[:30] or "node"


async def _tile_pass(png: bytes, w: int, h: int) -> list[Node]:
    """2x2 zoomed crops with overlap: much better text reading on dense diagrams and photos."""
    img = Image.open(io.BytesIO(png))
    ov = 0.12
    tiles = []
    for ty in (0, 1):
        for tx in (0, 1):
            x0 = int(max(0, (tx * 0.5 - (ov if tx else 0)) * w)); x1 = int(min(w, ((tx + 1) * 0.5 + (0 if tx else ov)) * w))
            y0 = int(max(0, (ty * 0.5 - (ov if ty else 0)) * h)); y1 = int(min(h, ((ty + 1) * 0.5 + (0 if ty else ov)) * h))
            buf = io.BytesIO(); img.crop((x0, y0, x1, y1)).save(buf, "PNG")
            tiles.append(((x0, y0, x1, y1), buf.getvalue()))
    results = await asyncio.gather(*[_ask([_img(t), prompts.TILE_PROMPT], NodesOnly) for _, t in tiles],
                                   return_exceptions=True)
    out = []
    for ((x0, y0, x1, y1), _), res in zip(tiles, results):
        if isinstance(res, Exception):
            continue
        tw, th = x1 - x0, y1 - y0
        for n in res.nodes:
            if n.kind == "container" or len(n.box_2d) != 4:
                continue
            a, b, c, d = n.box_2d
            n.box_2d = [round((y0 + a / 1000 * th) / h * 1000), round((x0 + b / 1000 * tw) / w * 1000),
                        round((y0 + c / 1000 * th) / h * 1000), round((x0 + d / 1000 * tw) / w * 1000)]
            out.append(n)
    return out


def _merge_tiles(base: list[Node], extra: list[Node]) -> list[Node]:
    ids = {n.id for n in base}
    for t in extra:
        best, score = None, 0
        for n in base:
            s = _iou(n.box_2d, t.box_2d)
            if s > score:
                best, score = n, s
        if best is not None and score > 0.3:
            # same shape seen closer up: trust the zoomed-in text if it is richer
            if score > 0.5 and best.kind == t.kind and len(t.label) > len(best.label):
                best.label = t.label
            continue
        nid = t.id if t.id not in ids else f"{_slug(t.label)}_{len(ids)}"
        ids.add(nid)
        base.append(t.model_copy(update={"id": nid}))
    return base


def _nodes_brief(nodes: list[Node]) -> str:
    return "\n".join(json.dumps({"id": n.id, "label": n.label, "kind": n.kind, "box_2d": n.box_2d}) for n in nodes)


async def extract(png: bytes, w: int, h: int) -> Diagram:
    whole = _ask([_img(png), prompts.NODES_PROMPT], NodesOnly)
    if max(w, h) >= TILE_THRESHOLD:
        first, tiled = await asyncio.gather(whole, _tile_pass(png, w, h))
        nodes = _merge_tiles(list(first.nodes), tiled)
    else:
        first = await whole
        nodes = list(first.nodes)
    edges = await _ask([_img(png), prompts.EDGES_PROMPT.format(nodes=_nodes_brief(nodes))], EdgesOnly)
    return Diagram(title=first.title, legend=first.legend, nodes=nodes, edges=edges.edges)


async def review(original_png: bytes, rendered_png: bytes, diagram: Diagram) -> Patch:
    return await _ask([_img(original_png), _img(rendered_png),
                       prompts.REVIEW_PROMPT.format(model=diagram.model_dump_json(exclude_defaults=True))],
                      Patch, REVIEW_MODEL)


async def revise(original_png: bytes, diagram: Diagram, instructions: str) -> Patch:
    return await _ask([_img(original_png),
                       prompts.REVISE_PROMPT.format(instructions=instructions,
                                                    model=diagram.model_dump_json(exclude_defaults=True))],
                      Patch, REVIEW_MODEL)


def apply_patch(d: Diagram, p: Patch) -> Diagram:
    nodes = {n.id: n for n in d.nodes}
    for rid in p.remove_node_ids:
        nodes.pop(rid, None)
    for n in p.upsert_nodes:
        nodes[n.id] = n
    drop = {(e.source, e.target) for e in p.remove_edges}
    edges = [e for e in d.edges if (e.source, e.target) not in drop] + list(p.add_edges)
    return d.model_copy(update={"nodes": list(nodes.values()), "edges": edges})
