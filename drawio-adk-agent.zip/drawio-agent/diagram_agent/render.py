"""Image normalisation (in) and draw.io rendering (out)."""
import asyncio
import io
import os
import shutil
import tempfile

from PIL import Image, ImageOps

try:  # iPhone photos arrive as HEIC
    from pillow_heif import register_heif_opener
    register_heif_opener()
except ImportError:
    pass

MAX_SIDE = int(os.getenv("MAX_IMAGE_SIDE", "3072"))
DRAWIO_BIN = os.getenv("DRAWIO_BIN", "drawio")


def normalise_image(data: bytes) -> tuple[bytes, int, int]:
    """Any image -> upright PNG no larger than MAX_SIDE. Returns (png_bytes, width, height)."""
    img = ImageOps.exif_transpose(Image.open(io.BytesIO(data))).convert("RGB")
    img.thumbnail((MAX_SIDE, MAX_SIDE))
    buf = io.BytesIO()
    img.save(buf, "PNG")
    return buf.getvalue(), img.width, img.height


def renderer_available() -> bool:
    return shutil.which(DRAWIO_BIN) is not None


async def render_png(drawio_xml: str, timeout: int = 90) -> bytes | None:
    """Render with the real draw.io app so the preview is exactly what users will open."""
    if not renderer_available():
        return None
    with tempfile.TemporaryDirectory() as tmp:
        src, out = os.path.join(tmp, "d.drawio"), os.path.join(tmp, "d.png")
        with open(src, "w", encoding="utf-8") as f:
            f.write(drawio_xml)
        cmd = [DRAWIO_BIN, "--no-sandbox", "-x", "-f", "png", "-s", "1", "-o", out, src]
        if shutil.which("xvfb-run") and not os.getenv("DISPLAY"):
            cmd = ["xvfb-run", "-a"] + cmd
        proc = await asyncio.create_subprocess_exec(*cmd, stdout=asyncio.subprocess.DEVNULL,
                                                    stderr=asyncio.subprocess.DEVNULL)
        try:
            await asyncio.wait_for(proc.wait(), timeout)
        except asyncio.TimeoutError:
            proc.kill()
            return None
        if not os.path.exists(out):
            return None
        with open(out, "rb") as f:
            return f.read()
