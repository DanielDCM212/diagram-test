"""How a client app uses the deployed agent over REST.
usage: python client_example.py http://localhost:8080 path/to/diagram.jpg"""
import base64, json, mimetypes, os, sys, uuid
import requests

base, path = sys.argv[1].rstrip("/"), sys.argv[2]
app, user, session = "diagram_agent", "demo-user", str(uuid.uuid4())
name = os.path.basename(path)

requests.post(f"{base}/apps/{app}/users/{user}/sessions/{session}", json={}).raise_for_status()

msg = {"role": "user", "parts": [
    {"text": "Convert this diagram to draw.io"},
    {"inlineData": {"mimeType": mimetypes.guess_type(path)[0] or "image/jpeg",
                    "displayName": name,
                    "data": base64.b64encode(open(path, "rb").read()).decode()}}]}
events = requests.post(f"{base}/run", json={"appName": app, "userId": user, "sessionId": session,
                                            "newMessage": msg}, timeout=600).json()
for ev in events:
    for p in (ev.get("content") or {}).get("parts", []):
        if p.get("text"): print("agent:", p["text"])

stem = os.path.splitext(name)[0]
for artifact in (f"{stem}.drawio", f"{stem}_preview.png"):
    r = requests.get(f"{base}/apps/{app}/users/{user}/sessions/{session}/artifacts/{artifact}")
    if r.ok:
        open(artifact, "wb").write(base64.b64decode(r.json()["inlineData"]["data"]))
        print("saved", artifact)
