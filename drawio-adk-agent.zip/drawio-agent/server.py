"""Production entry point: ADK's FastAPI server (REST + optional dev UI + optional A2A)."""
import os
from google.adk.cli.fast_api import get_fast_api_app

app = get_fast_api_app(
    agents_dir=os.path.dirname(os.path.abspath(__file__)),
    web=os.getenv("SERVE_WEB_UI", "false").lower() == "true",        # dev UI, keep off in prod
    a2a=os.getenv("ENABLE_A2A", "false").lower() == "true",           # expose to other agents
    session_service_uri=os.getenv("SESSION_SERVICE_URI"),            # e.g. postgresql+asyncpg://... ; default in-memory
    artifact_service_uri=os.getenv("ARTIFACT_SERVICE_URI"),          # e.g. gs://my-bucket ; default local
    allow_origins=[o for o in os.getenv("ALLOW_ORIGINS", "").split(",") if o] or None,
    auto_create_session=True,
)
