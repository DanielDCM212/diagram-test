# Diagram → draw.io agent (Google ADK)

Users upload any picture of a diagram (export, screenshot or phone photo); the agent returns an editable
`.drawio` file, a PNG preview rendered by draw.io itself, and the JSON model it built.

## How it works
```
upload ──> SaveFilesAsArtifactsPlugin ──> artifact "IMG_0264.JPG"
             │
LlmAgent (AGENT_MODEL) ── calls tool convert_image_to_drawio(image_artifact)
             │
   pipeline.convert
     1. normalise   (EXIF rotate, HEIC, resize)                          render.py
     2. extract     Gemini pass A: shapes + containers + legend           vision.py
                    Gemini pass B: 2x2 zoomed tiles for large images (better text)
                    Gemini pass C: connectors between the extracted ids
     3. build       deterministic JSON -> draw.io XML                     build.py
                    (nesting from geometry, legend-driven styles, font harmonising,
                     straight anchors, orthogonal routing)
     4. render      draw.io CLI -> PNG                                    render.py
     5. review      Gemini compares original vs render -> Patch; repeat (MAX_REVIEW_ROUNDS)
             │
artifacts: IMG_0264.drawio, IMG_0264_preview.png, IMG_0264_model.json
```
Follow-up corrections ("the SSG arrow goes to Experian") go through `revise_diagram`, which patches the
JSON model and saves a new version of the same files.

The only LLM steps are extraction, review and revision. Everything that shapes the XML is plain code,
so output is reproducible and fixable without prompt changes.

## Run locally
```bash
pip install -r requirements.txt          # plus draw.io desktop for previews/self-review
cp .env.example .env                     # set GOOGLE_API_KEY or Vertex AI settings
adk web                                   # dev UI: upload an image in the chat
python cli.py photo.jpg out/              # same pipeline, no agent
python tests/test_offline.py && python tests/test_adk_runtime.py && python tests/test_upload_trigger.py && python tests/test_media_resolution.py   # no credentials needed
```

## Deploy (Cloud Run)
```bash
gcloud run deploy diagram-agent --source . --region us-central1 --memory 2Gi --cpu 2 --timeout 900 \
  --set-env-vars GOOGLE_GENAI_USE_VERTEXAI=true,GOOGLE_CLOUD_PROJECT=...,GOOGLE_CLOUD_LOCATION=global,ARTIFACT_SERVICE_URI=gs://your-bucket
```
Cloud Run (custom Dockerfile) rather than Agent Engine, because the draw.io renderer must be installed.
Clients call the standard ADK REST API; see `client_example.py`. Set `ENABLE_A2A=true` to expose the agent
to other agents.

## Notes
- Company diagrams: use Vertex AI in your own project and check the data classification before sending
  internal architecture images to any model.
- Hardest inputs: photos at an angle with dense crossing lines. Quality levers: `EXTRACTION_MODEL`,
  `MEDIA_RESOLUTION`, `TILE_THRESHOLD`, `MAX_REVIEW_ROUNDS`.
- Without draw.io installed the agent still produces the .drawio file; it just skips preview and self-review.
