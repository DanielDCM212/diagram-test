"""Tools for the FIXER agent. All edits go through validated operations on spec.json."""
from __future__ import annotations

import json

from google.adk.tools import ToolContext

from .drawio_kit.schema import DiagramSpec, Edge, EdgeStyle, Node, Style
from .drawio_kit.validate import validate_spec
from .drawio_kit.vision_ops import detect_boxes, detect_lines, ocr_lines, sample_colors as _sample

from .pipeline_ops import load_spec, save_spec, score_and_export, spec_digest
from .workspace import ws_from_state


def _merge_style(model_cls, current, patch: dict):
    data = current.model_dump() if current is not None else {}
    data.update({k: v for k, v in (patch or {}).items() if v is not None})
    return model_cls(**data)


def _apply(spec: DiagramSpec, ops: list[dict]) -> list[str]:
    log = []
    nodes = {n.id: n for n in spec.nodes}
    edges = {e.id: e for e in spec.edges}
    for i, op in enumerate(ops):
        kind = op.get("op")
        try:
            if kind == "add_node":
                d = dict(op["node"])
                d["style"] = Style(**(d.get("style") or {}))
                n = Node(**d)
                if n.id in nodes:
                    raise ValueError(f"id {n.id} exists")
                nodes[n.id] = n
            elif kind == "update_node":
                n = nodes[op["id"]]
                s = dict(op.get("set") or {})
                if "style" in s:
                    s["style"] = _merge_style(Style, n.style, s.pop("style"))
                nodes[n.id] = n.model_copy(update=s)
                Node.model_validate(nodes[n.id].model_dump())
            elif kind == "delete_node":
                nid = op["id"]
                dead = nodes.pop(nid)
                for c in list(nodes.values()):
                    if c.parent == nid:
                        nodes[c.id] = c.model_copy(update={"parent": dead.parent})
                for e in list(edges.values()):
                    if e.source == nid or e.target == nid:
                        edges.pop(e.id)
            elif kind == "add_edge":
                d = dict(op["edge"])
                d["style"] = EdgeStyle(**(d.get("style") or {}))
                e = Edge(**d)
                if e.id in edges:
                    raise ValueError(f"id {e.id} exists")
                edges[e.id] = e
            elif kind == "update_edge":
                e = edges[op["id"]]
                s = dict(op.get("set") or {})
                if "style" in s:
                    s["style"] = _merge_style(EdgeStyle, e.style, s.pop("style"))
                edges[e.id] = e.model_copy(update=s)
                Edge.model_validate(edges[e.id].model_dump())
            elif kind == "delete_edge":
                edges.pop(op["id"])
            elif kind == "set_canvas":
                for k, v in (op.get("set") or {}).items():
                    if k in ("scale", "background", "width", "height"):
                        setattr(spec, k, v)
            else:
                raise ValueError(f"unknown op {kind!r}")
            log.append(f"#{i} {kind} ok")
        except Exception as ex:  # keep going; report precisely
            log.append(f"#{i} {kind} FAILED: {type(ex).__name__}: {ex}")
    spec.nodes = list(nodes.values())
    spec.edges = list(edges.values())
    return log


def apply_spec_patch(operations_json: str, tool_context: ToolContext) -> dict:
    """Apply a JSON list of edit operations (add/update/delete node or edge, set_canvas) to
    the replica spec. Returns per-operation results and validation errors/warnings."""
    ws = ws_from_state(tool_context.state)
    try:
        ops = json.loads(operations_json)
        if isinstance(ops, dict):
            ops = ops.get("operations", [ops])
    except json.JSONDecodeError as e:
        return {"status": "error", "message": f"invalid JSON: {e}"}
    spec = load_spec(ws)
    log = _apply(spec, ops)
    v = validate_spec(spec)
    if v["errors"]:
        return {"status": "rejected", "results": log, "validation_errors": v["errors"],
                "message": "spec NOT saved – fix the errors and resend"}
    save_spec(ws, spec, tag="patch")
    tool_context.state["patches_applied"] = tool_context.state.get("patches_applied", 0) + len(ops)
    return {"status": "saved", "results": log, "warnings": v["warnings"][:30], "stats": v["stats"]}


def measure_region(x0: float, y0: float, x1: float, y1: float, tool_context: ToolContext) -> dict:
    """Measure a source-image region: OCR text lines, detected rectangles (precise geometry and
    colours) and line segments, all in source pixels."""
    ws = ws_from_state(tool_context.state)
    box = [x0, y0, x1, y1]
    if tool_context.state.get("ocr_backend") == "tesseract":
        text = ocr_lines(ws.source, box, upscale=3.0)
    else:  # Gemini OCR results were computed once for the whole image – filter them
        cv = ws.read_json("cv.json", {})
        text = [l for l in cv.get("ocr_lines", [])
                if l["x"] + l["w"] >= x0 and l["x"] <= x1 and l["y"] + l["h"] >= y0 and l["y"] <= y1]
    return {"ocr_lines": text,
            "boxes": detect_boxes(ws.source, box, min_w=8, min_h=8, upscale=2.0)[:80],
            "lines": detect_lines(ws.source, box, min_len=12)[:80]}


def sample_colors(points_json: str, tool_context: ToolContext) -> dict:
    """Sample source colours at a JSON list of [x,y] points (median of a 5x5 patch)."""
    ws = ws_from_state(tool_context.state)
    return {"samples": _sample(ws.source, json.loads(points_json))}


def get_spec(x0: float = 0, y0: float = 0, x1: float = 0, y1: float = 0, tool_context: ToolContext = None) -> dict:
    """Return the current spec digest (optionally only elements intersecting a region;
    pass all zeros for the whole spec)."""
    ws = ws_from_state(tool_context.state)
    region = None if (x0 == y0 == x1 == y1 == 0) else [x0, y0, x1, y1]
    return {"digest": spec_digest(load_spec(ws), region)}


def rebuild_and_score(tool_context: ToolContext) -> dict:
    """Recompile the spec, render it with draw.io, and return similarity/coverage metrics."""
    ws = ws_from_state(tool_context.state)
    rep = score_and_export(ws, load_spec(ws))
    tool_context.state["metrics"] = rep["metrics"]
    return {"metrics": rep["metrics"], "validation_errors": rep["validation"]["errors"],
            "missing_text": [t["token"] for t in rep["audit"]["text"]["missing"][:40]]}


FIXER_TOOLS = [apply_spec_patch, measure_region, sample_colors, get_spec, rebuild_and_score]
