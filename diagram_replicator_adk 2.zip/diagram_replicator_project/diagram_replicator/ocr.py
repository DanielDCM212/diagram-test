"""Gemini-based OCR (drop-in replacement for Tesseract).

Gemini returns text with bounding boxes in its native convention:
    box_2d = [ymin, xmin, ymax, xmax], integers normalised to 0-1000 of the image it saw.
We send CLEAN (grid-free), upscaled, overlapping tiles so boxes stay tight, convert back
to source pixels, de-duplicate across overlaps, and derive word boxes so every downstream
consumer (planner/extractor prompts, gap-fill passes, text-coverage audit, measure_region)
works exactly as with Tesseract.
"""
from __future__ import annotations

import difflib
import json
import os
from typing import AsyncGenerator, Literal

from google.adk.agents import BaseAgent, LlmAgent
from google.adk.agents.invocation_context import InvocationContext
from google.adk.events import Event
from pydantic import BaseModel, Field
from PIL import Image

from .drawio_kit.vision_ops import ocr_lines as group_lines

from .config import CONFIG
from .workspace import ws_from_state


# ------------------------------------------------------------------ schema
class OcrLine(BaseModel):
    text: str                                   # exact transcription of ONE visual line
    box_2d: list[int] = Field(min_length=4, max_length=4)   # [ymin, xmin, ymax, xmax] 0-1000
    orientation: Literal["horizontal", "vertical_up", "vertical_down"] = "horizontal"
    confidence: float = 0.9


class OcrResult(BaseModel):
    lines: list[OcrLine] = Field(default_factory=list)


# ------------------------------------------------------------------ prompt + images
def ocr_instruction(ctx) -> str:
    t = ctx.state.get("current_ocr_tile") or {}
    return f"""ROLE: OCR_READER
You are a precise OCR engine. Transcribe EVERY piece of text visible in the image,
one entry per VISUAL LINE (a box label with 3 lines = 3 entries).
- text: exact characters as printed (case, punctuation, brackets, digits, typos).
  Do not correct, translate or merge lines. Include tiny text, legend text, IDs,
  numbers like [99.6], watermarks, page numbers, rotated text.
- box_2d: tight box around that line as [ymin, xmin, ymax, xmax], integers 0-1000
  normalised to THIS image's height/width.
- orientation: vertical_up if the line reads bottom→top, vertical_down if top→bottom.
- Text cut off by the image edge: transcribe the visible part and box it.
- Ignore connector lines and shapes; text only. Never summarise or skip repeats.
(tile {t.get('id', '?')}, source region {t.get('box')}; the caller converts coordinates)"""


def ocr_images(callback_context, llm_request):
    from .callbacks import _inject
    t = callback_context.state.get("current_ocr_tile") or {}
    _inject(llm_request, [("IMAGE TO TRANSCRIBE:", t.get("path"))])
    return None


# ------------------------------------------------------------------ geometry helpers
def make_ocr_tiles(src: str, out_dir: str) -> list[dict]:
    im = Image.open(src).convert("RGB")
    W, H = im.size
    cols = max(1, round(W / CONFIG.ocr_tile_src_px + 0.25))
    rows = max(1, round(H / CONFIG.ocr_tile_src_px + 0.25))
    tw, th = W / cols, H / rows
    ow, oh = tw * CONFIG.ocr_tile_overlap, th * CONFIG.ocr_tile_overlap
    os.makedirs(out_dir, exist_ok=True)
    tiles = []
    for r in range(rows):
        for c in range(cols):
            box = [max(0, c * tw - ow), max(0, r * th - oh), min(W, (c + 1) * tw + ow), min(H, (r + 1) * th + oh)]
            crop = im.crop(tuple(int(round(v)) for v in box))
            zoom = max(1.0, min(4.0, CONFIG.ocr_tile_target_px / max(crop.size)))
            crop = crop.resize((int(crop.width * zoom), int(crop.height * zoom)), Image.LANCZOS)
            p = os.path.join(out_dir, f"ocr_r{r}_c{c}.png")
            crop.save(p)
            tiles.append({"id": f"ocr_r{r}c{c}", "box": [round(v, 1) for v in box], "path": p})
    return tiles


def to_source(line: dict, tile: dict) -> dict:
    x0, y0, x1, y1 = tile["box"]
    tw, th = x1 - x0, y1 - y0
    ymin, xmin, ymax, xmax = [max(0, min(1000, v)) for v in line["box_2d"]]
    if ymin > ymax:
        ymin, ymax = ymax, ymin
    if xmin > xmax:
        xmin, xmax = xmax, xmin
    sx0, sy0 = x0 + xmin / 1000 * tw, y0 + ymin / 1000 * th
    sx1, sy1 = x0 + xmax / 1000 * tw, y0 + ymax / 1000 * th
    W, H = tile["image_size"]
    clipped = ((sx0 - x0 < 3 and x0 > 1) or (sy0 - y0 < 3 and y0 > 1) or
               (x1 - sx1 < 3 and x1 < W - 1) or (y1 - sy1 < 3 and y1 < H - 1))
    return {"text": line["text"].strip(), "x": round(sx0, 1), "y": round(sy0, 1), "w": round(sx1 - sx0, 1),
            "h": round(sy1 - sy0, 1), "conf": round(100 * float(line.get("confidence", 0.9)), 1),
            "orientation": line.get("orientation", "horizontal"), "tile": tile["id"], "clipped": clipped}


def _iou(a, b):
    ax1, ay1, bx1, by1 = a["x"] + a["w"], a["y"] + a["h"], b["x"] + b["w"], b["y"] + b["h"]
    iw = max(0, min(ax1, bx1) - max(a["x"], b["x"]))
    ih = max(0, min(ay1, by1) - max(a["y"], b["y"]))
    i = iw * ih
    return i / max(1e-6, a["w"] * a["h"] + b["w"] * b["h"] - i)


def dedupe(lines: list[dict]) -> list[dict]:
    """Same line seen in two overlapping tiles → keep the un-clipped / longer reading."""
    keep: list[dict] = []
    for ln in sorted(lines, key=lambda l: (l["clipped"], -len(l["text"]))):
        dup = False
        for k in keep:
            if k["tile"] == ln["tile"]:
                continue
            sim = difflib.SequenceMatcher(None, k["text"].lower(), ln["text"].lower()).ratio()
            contained = ln["text"].lower() in k["text"].lower()
            if _iou(k, ln) > 0.3 and (sim > 0.75 or contained):
                dup = True
                break
        if not dup and ln["text"]:
            keep.append(ln)
    return sorted(keep, key=lambda l: (l["y"], l["x"]))


def words_from_lines(lines: list[dict]) -> list[dict]:
    """Split each line box proportionally to character counts (enough for the text audit
    and for the gap-fill passes, which only need token + approximate position)."""
    words = []
    for ln in lines:
        toks = ln["text"].split()
        total = max(1, len(ln["text"]))
        vertical = ln.get("orientation", "horizontal") != "horizontal"
        pos = 0
        for t in toks:
            i = ln["text"].find(t, pos)
            a, b = i / total, (i + len(t)) / total
            pos = i + len(t)
            if vertical:   # vertical text: tokens run along y
                if ln.get("orientation") == "vertical_up":
                    a, b = 1 - b, 1 - a
                words.append({"text": t, "conf": ln["conf"], "x": ln["x"], "w": ln["w"],
                              "y": round(ln["y"] + a * ln["h"], 1), "h": round((b - a) * ln["h"], 1)})
            else:
                words.append({"text": t, "conf": ln["conf"], "y": ln["y"], "h": ln["h"],
                              "x": round(ln["x"] + a * ln["w"], 1), "w": round((b - a) * ln["w"], 1)})
    return words


# ------------------------------------------------------------------ stage
class GeminiOcrStage(BaseAgent):
    """Runs only when the resolved OCR backend is 'gemini'; fills cv.json like Tesseract would."""
    reader: LlmAgent

    def __init__(self, name: str, reader: LlmAgent):
        super().__init__(name=name, reader=reader, sub_agents=[reader])

    async def _run_async_impl(self, ctx: InvocationContext) -> AsyncGenerator[Event, None]:
        from .stages import _as_dict, _event
        state = ctx.session.state
        if state.get("fatal") or state.get("ocr_backend") != "gemini":
            return
        ws = ws_from_state(state)
        size = Image.open(ws.source).size
        tiles = make_ocr_tiles(ws.source, ws.p("ocr_tiles"))
        raw: list[dict] = []
        failed = []
        for t in tiles:
            t["image_size"] = list(size)
            yield _event(self, ctx, None, {"current_ocr_tile": t, "ocr_result": None})
            out = None
            for attempt in range(CONFIG.llm_retries + 1):
                try:
                    async for ev in self.reader.run_async(ctx):
                        yield ev
                    out = _as_dict(ctx.session.state.get("ocr_result"))
                    if out is not None:
                        break
                except Exception as ex:
                    yield _event(self, ctx, f"OCR tile {t['id']} attempt {attempt} failed: {ex}")
            if out is None:
                failed.append(t["id"])
                continue
            for ln in out.get("lines", []):
                try:
                    raw.append(to_source(ln, t))
                except Exception:
                    continue
        lines = dedupe(raw)
        words = words_from_lines(lines)
        cv = ws.read_json("cv.json", {})
        cv.update({"ocr_words": words, "ocr_lines": [{k: l[k] for k in ("text", "x", "y", "w", "h", "conf",
                                                                         "orientation")} for l in lines],
                   "ocr_backend": "gemini", "ocr_failed_tiles": failed})
        ws.write_json("cv.json", cv)
        meta = dict(state.get("image_meta") or {})
        meta["ocr_lines"] = len(lines)
        yield _event(self, ctx, f"Gemini OCR: {len(lines)} text lines ({len(raw)} raw across {len(tiles)} tiles"
                                f"{', failed: ' + ','.join(failed) if failed else ''}).",
                     {"image_meta": meta, "current_ocr_tile": None, "ocr_result": None})
