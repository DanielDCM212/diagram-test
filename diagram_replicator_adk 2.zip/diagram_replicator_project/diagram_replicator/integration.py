"""Ways to embed the replicator in another ADK project.

1. As a SUB-AGENT of your coordinator (shares the session):
       from app.diagram_replicator import build_root_agent
       coordinator = LlmAgent(..., sub_agents=[build_root_agent()])

2. As a TOOL (recommended: isolated state, returns artifacts to the caller's session):
       from app.diagram_replicator import replicate_diagram_tool
       coordinator = LlmAgent(..., tools=[replicate_diagram_tool])
"""
from __future__ import annotations

import mimetypes
import os
import tempfile
from typing import Optional

from google.adk.runners import InMemoryRunner
from google.adk.tools import FunctionTool, ToolContext
from google.genai import types

from .agent import build_root_agent

_INNER_APP = "diagram_replicator_inner"
_MODEL_OVERRIDE = None   # set via configure_tool() (tests / other providers)


def configure_tool(model_override=None):
    """Optionally force every LLM role of the nested pipeline onto one model/BaseLlm."""
    global _MODEL_OVERRIDE
    _MODEL_OVERRIDE = model_override


async def _find_image(tool_context: ToolContext, image_artifact: str, image_path: str) -> tuple[bytes, str]:
    if image_artifact:
        part = await tool_context.load_artifact(image_artifact)
        if part is None or not part.inline_data:
            raise ValueError(f"artifact {image_artifact!r} not found or not binary")
        return part.inline_data.data, image_artifact
    if image_path:
        with open(os.path.expanduser(image_path), "rb") as f:
            return f.read(), os.path.basename(image_path)
    # fall back to an image attached to the user's current message
    uc = tool_context.user_content
    for p in (uc.parts if uc else []) or []:
        if p.inline_data and (p.inline_data.mime_type or "").startswith("image/"):
            return p.inline_data.data, p.inline_data.display_name or "attached_image.png"
    # or the most recent image artifact in the session
    for name in reversed(await tool_context.list_artifacts()):
        if name.lower().endswith((".png", ".jpg", ".jpeg", ".webp", ".bmp", ".gif")):
            part = await tool_context.load_artifact(name)
            if part and part.inline_data:
                return part.inline_data.data, name
    raise ValueError("no image: attach one, or pass image_artifact / image_path")


async def replicate_diagram(image_artifact: str = "", image_path: str = "",
                            tool_context: ToolContext = None) -> dict:
    """Replicate a diagram image as an editable draw.io file.

    Args:
        image_artifact: name of an image artifact in this session (optional).
        image_path: filesystem path to the image (optional).
        If both are empty, the image attached to the user's current message is used.

    Returns: status, the saved artifact names (.drawio, .spec.json, .render.png,
    .report.json) and quality metrics.
    """
    data, name = await _find_image(tool_context, image_artifact, image_path)
    stem = os.path.splitext(os.path.basename(name))[0] or "diagram"
    with tempfile.TemporaryDirectory() as td:
        src = os.path.join(td, f"{stem}{os.path.splitext(name)[1] or '.png'}")
        with open(src, "wb") as f:
            f.write(data)
        runner = InMemoryRunner(agent=build_root_agent(_MODEL_OVERRIDE), app_name=_INNER_APP)
        session = await runner.session_service.create_session(
            app_name=_INNER_APP, user_id="tool", state={"input_image_path": src})
        msg = types.Content(role="user", parts=[types.Part.from_text(text="Replicate this diagram.")])
        progress = []
        async for ev in runner.run_async(user_id="tool", session_id=session.id, new_message=msg):
            if ev.author in ("ingest", "ocr", "merge", "assemble", "quality_gate", "export") and ev.content \
                    and ev.content.parts and ev.content.parts[0].text:
                progress.append(f"[{ev.author}] {ev.content.parts[0].text[:160]}")
        inner = await runner.session_service.get_session(app_name=_INNER_APP, user_id="tool", session_id=session.id)
        if inner.state.get("fatal"):
            return {"status": "error", "message": str(inner.state["fatal"]), "progress": progress}
        saved = []
        for fname, path in (inner.state.get("outputs") or {}).items():
            ext = fname.split(".", 1)[1]
            out_name = f"{stem}.{ext}"
            mime = {"drawio": "application/vnd.jgraph.mxfile", "png": "image/png"}.get(
                ext.rsplit(".", 1)[-1], "application/json")
            with open(path, "rb") as f:
                await tool_context.save_artifact(out_name, types.Part.from_bytes(data=f.read(), mime_type=mime))
            saved.append(out_name)
    return {"status": "ok", "artifacts": saved, "metrics": inner.state.get("final_metrics"),
            "stop_reason": inner.state.get("stop_reason"), "progress": progress[-6:]}


replicate_diagram_tool = FunctionTool(replicate_diagram)
