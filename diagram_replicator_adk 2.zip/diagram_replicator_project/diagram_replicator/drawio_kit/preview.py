"""Rasterise a DiagramSpec with Pillow (in source-pixel space, scale ignored).

This is NOT meant to be pixel-identical to draw.io; it is a faithful-enough raster so a
critic (human or multimodal LLM) can compare the replica side-by-side with the source,
and so ``vision_ops.similarity`` can compute a numeric layout score.
"""
from __future__ import annotations

import math
from functools import lru_cache
from typing import Optional

from PIL import Image, ImageDraw, ImageFont

from .schema import DiagramSpec, Node

_FONT_CANDIDATES = {
    False: ["/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
            "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", "Arial.ttf", "DejaVuSans.ttf"],
    True: ["/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
           "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", "Arial Bold.ttf", "DejaVuSans-Bold.ttf"],
}


@lru_cache(maxsize=256)
def _font(size: int, bold: bool):
    for p in _FONT_CANDIDATES[bold]:
        try:
            return ImageFont.truetype(p, max(4, size))
        except OSError:
            continue
    return ImageFont.load_default()


def _rgb(c: Optional[str]):
    if not c or c.lower() in ("none", "transparent"):
        return None
    c = c.lstrip("#")
    if len(c) == 3:
        c = "".join(ch * 2 for ch in c)
    return tuple(int(c[i:i + 2], 16) for i in (0, 2, 4))


def _dash_line(d, a, b, fill, width, dash=(6, 4)):
    (x0, y0), (x1, y1) = a, b
    L = math.hypot(x1 - x0, y1 - y0)
    if L == 0:
        return
    ux, uy = (x1 - x0) / L, (y1 - y0) / L
    t, on = 0.0, True
    while t < L:
        seg = dash[0] if on else dash[1]
        t2 = min(L, t + seg)
        if on:
            d.line([(x0 + ux * t, y0 + uy * t), (x0 + ux * t2, y0 + uy * t2)], fill=fill, width=width)
        t, on = t2, not on


def _poly(d, pts, color, width, dashed):
    for a, b in zip(pts, pts[1:]):
        if dashed:
            _dash_line(d, a, b, color, width)
        else:
            d.line([a, b], fill=color, width=width)


def _rect(d, n: Node, radius=None):
    s = n.style
    fill, stroke = _rgb(s.fill), _rgb(s.stroke)
    box = [n.x, n.y, n.x + n.w, n.y + n.h]
    sw = max(1, int(round(s.stroke_width)))
    rounded = s.rounded if s.rounded is not None else n.kind in ("rounded", "container", "pill")
    if n.kind == "pill":
        radius = min(n.w, n.h) / 2
    elif rounded:
        radius = radius or (s.arc_size / 100 * min(n.w, n.h) if s.arc_size and not s.abs_arc else
                            (s.arc_size / 2 if s.arc_size else min(n.w, n.h) * 0.15))
    if s.dashed and stroke:
        if fill:
            d.rounded_rectangle(box, radius=radius or 0, fill=fill)
        x0, y0, x1, y1 = box
        for a, b in [((x0, y0), (x1, y0)), ((x1, y0), (x1, y1)), ((x1, y1), (x0, y1)), ((x0, y1), (x0, y0))]:
            _dash_line(d, a, b, stroke, sw, (8, 5))
        return
    if radius:
        d.rounded_rectangle(box, radius=radius, fill=fill, outline=stroke, width=sw if stroke else 0)
    else:
        d.rectangle(box, fill=fill, outline=stroke, width=sw if stroke else 0)


def _wrap(text, font, maxw, d):
    lines = []
    for para in text.split("\n"):
        words, cur = para.split(" "), ""
        for w in words:
            t = (cur + " " + w).strip()
            if d.textlength(t, font=font) <= maxw or not cur:
                cur = t
            else:
                lines.append(cur)
                cur = w
        lines.append(cur)
    return lines


def _strip_html(label: str) -> str:
    import re
    if label.startswith("html:"):
        label = re.sub(r"<br\s*/?>", "\n", label[5:])
        label = re.sub(r"<[^>]+>", "", label)
        import html as _h
        label = _h.unescape(label)
    return label


def _text(canvas: Image.Image, n: Node, box=None):
    label = _strip_html(n.label)
    if not label:
        return
    s = n.style
    x0, y0, x1, y1 = box or (n.x, n.y, n.x + n.w, n.y + n.h)
    vertical = s.text_dir != "horizontal"
    bw, bh = (y1 - y0, x1 - x0) if vertical else (x1 - x0, y1 - y0)
    tile = Image.new("RGBA", (max(1, int(bw)), max(1, int(bh))), (0, 0, 0, 0))
    d = ImageDraw.Draw(tile)
    font = _font(int(round(s.font_size)), s.bold)
    pad = s.spacing + 1
    lines = _wrap(label, font, bw - 2 * pad, d)
    lh = s.font_size * 1.2
    total = lh * len(lines)
    ty = {"top": pad, "middle": (bh - total) / 2, "bottom": bh - total - pad}[s.valign]
    for ln in lines:
        tw = d.textlength(ln, font=font)
        tx = {"left": pad, "center": (bw - tw) / 2, "right": bw - tw - pad}[s.align]
        d.text((tx, ty), ln, font=font, fill=_rgb(s.font_color) or (0, 0, 0))
        if s.underline:
            d.line([(tx, ty + s.font_size + 1), (tx + tw, ty + s.font_size + 1)], fill=_rgb(s.font_color), width=1)
        ty += lh
    if s.text_dir == "vertical_up":
        tile = tile.rotate(90, expand=True)
    elif s.text_dir == "vertical_down":
        tile = tile.rotate(-90, expand=True)
    canvas.alpha_composite(tile, (int(x0), int(y0)))


def _arrow(d, tip, prev, kind, color, size, fill=True):
    if kind == "none":
        return
    ang = math.atan2(tip[1] - prev[1], tip[0] - prev[0])
    if kind == "oval":
        r = size / 2 + 1
        d.ellipse([tip[0] - r, tip[1] - r, tip[0] + r, tip[1] + r], fill=color if fill else None, outline=color)
        return
    L, W = size * 1.6, size * 0.9
    bx, by = tip[0] - L * math.cos(ang), tip[1] - L * math.sin(ang)
    p1 = (bx + W * math.sin(ang), by - W * math.cos(ang))
    p2 = (bx - W * math.sin(ang), by + W * math.cos(ang))
    if kind == "open":
        d.line([p1, tip, p2], fill=color, width=1)
    else:
        d.polygon([tip, p1, p2], fill=color if fill else None, outline=color)


def _anchor(spec: DiagramSpec, nid, pt, other):
    if pt:
        return tuple(pt)
    n = spec.node(nid)
    cx, cy = n.x + n.w / 2, n.y + n.h / 2
    if other is None:
        return (cx, cy)
    # clip centre->other to the box perimeter
    dx, dy = other[0] - cx, other[1] - cy
    if dx == dy == 0:
        return (cx, cy)
    t = min(abs(n.w / 2 / dx) if dx else 1e9, abs(n.h / 2 / dy) if dy else 1e9)
    return (cx + dx * t, cy + dy * t)


def render_preview(spec: DiagramSpec, image_path: Optional[str] = None, out_path: Optional[str] = None) -> Image.Image:
    W, H = int(math.ceil(spec.width)), int(math.ceil(spec.height))
    canvas = Image.new("RGBA", (W, H), _rgb(spec.background) + (255,) if _rgb(spec.background) else (255, 255, 255, 255))
    d = ImageDraw.Draw(canvas)
    src = None
    img = image_path or spec.source_image
    if img:
        try:
            src = Image.open(img).convert("RGBA")
        except Exception:
            src = None

    def depth(n):
        k, cur = 0, n
        while cur.parent:
            cur = spec.node(cur.parent)
            k += 1
        return k

    for n in sorted(spec.nodes, key=lambda n: (depth(n), n.z)):
        s = n.style
        if n.kind == "line":
            horiz = n.w >= n.h
            a = (n.x, n.y + n.h / 2) if horiz else (n.x + n.w / 2, n.y)
            b = (n.x + n.w, n.y + n.h / 2) if horiz else (n.x + n.w / 2, n.y + n.h)
            _poly(d, [a, b], _rgb(s.stroke), max(1, int(s.stroke_width)), s.dashed)
        elif n.kind == "server_stack":
            if n.tint:
                d.rectangle([n.x, n.y - 4, n.x + n.w, n.y + n.h], fill=_rgb(n.tint))
            uh = (n.h - 2 * (n.units - 1)) / n.units
            for i in range(n.units):
                uy = n.y + i * (uh + 2)
                d.rounded_rectangle([n.x, uy, n.x + n.w, uy + uh], radius=4, fill=(110, 110, 112))
                d.ellipse([n.x + 5, uy + 4, n.x + 11, uy + 10], fill="white")
                d.rectangle([n.x + n.w - 42, uy + uh - 9, n.x + n.w - 8, uy + uh - 6], fill="white")
            if n.status_color:
                d.ellipse([n.x + 5, n.y + n.h - 17, n.x + 19, n.y + n.h - 3], fill=_rgb(n.status_color))
        elif n.kind == "app_icon":
            col = _rgb(s.stroke if s.stroke not in ("#000000", "none") else "#2A6EBB")
            d.rectangle([n.x, n.y, n.x + n.w, n.y + n.h], outline=col, width=2, fill="white")
            d.rectangle([n.x, n.y, n.x + n.w, n.y + max(2.5, n.h * .18)], fill=col)
        elif n.kind in ("db_icon", "cylinder"):
            fill = _rgb(s.fill) if (n.kind == "cylinder" or s.fill != "#FFFFFF") else (36, 71, 184)
            e = max(3, n.h * 0.18)
            d.rectangle([n.x, n.y + e / 2, n.x + n.w, n.y + n.h - e / 2], fill=fill)
            d.ellipse([n.x, n.y + n.h - e, n.x + n.w, n.y + n.h], fill=fill, outline=_rgb(s.stroke))
            d.ellipse([n.x, n.y, n.x + n.w, n.y + e], fill=fill, outline=_rgb(s.stroke))
            _text(canvas, n)
        elif n.kind == "pipe":
            d.rectangle([n.x, n.y, n.x + n.w, n.y + n.h], fill=(166, 166, 166), outline="black", width=2)
            if n.w <= n.h:
                d.rectangle([n.x + n.w * .3, n.y, n.x + n.w * .6, n.y + n.h], fill="white", outline="black")
        elif n.kind == "raster":
            if src is not None:
                from .compiler import load_crop
                piece = load_crop(img, n.crop or [n.x, n.y, n.x + n.w, n.y + n.h], n.meta.get("knockout"),
                                  float(n.meta.get("knockout_tol", 38))).resize((max(1, int(n.w)), max(1, int(n.h))))
                canvas.alpha_composite(piece, (int(n.x), int(n.y)))
            else:
                d.rectangle([n.x, n.y, n.x + n.w, n.y + n.h], outline=(150, 150, 150))
        elif n.kind == "hexagon":
            q = n.w * 0.25
            pts = [(n.x + q, n.y), (n.x + n.w - q, n.y), (n.x + n.w, n.y + n.h / 2), (n.x + n.w - q, n.y + n.h),
                   (n.x + q, n.y + n.h), (n.x, n.y + n.h / 2)]
            d.polygon(pts, fill=_rgb(s.fill), outline=_rgb(s.stroke))
            _text(canvas, n)
        elif n.kind == "ellipse":
            d.ellipse([n.x, n.y, n.x + n.w, n.y + n.h], fill=_rgb(s.fill), outline=_rgb(s.stroke),
                      width=max(1, int(s.stroke_width)))
            _text(canvas, n)
        elif n.kind == "text":
            if s.fill not in ("#FFFFFF", "none"):
                d.rectangle([n.x, n.y, n.x + n.w, n.y + n.h], fill=_rgb(s.fill))
            _text(canvas, n)
        else:
            _rect(d, n)
            if n.kind == "container":
                cs = s.model_copy(update={"valign": s.valign})
                _text(canvas, n.model_copy(update={"style": cs}))
            else:
                _text(canvas, n)

    for e in spec.edges:
        es = e.style
        col = _rgb(es.color) or (0, 0, 0)
        first_other = e.waypoints[0] if e.waypoints else (e.target_point or None)
        last_other = e.waypoints[-1] if e.waypoints else (e.source_point or None)
        a = _anchor(spec, e.source, e.source_point, first_other) if (e.source or e.source_point) else None
        b = _anchor(spec, e.target, e.target_point, last_other) if (e.target or e.target_point) else None
        if a is None or b is None:
            continue
        pts = [a] + [tuple(p) for p in e.waypoints] + [b]
        _poly(d, pts, col, max(1, int(round(es.width))), es.dashed)
        _arrow(d, pts[-1], pts[-2], es.end_arrow, col, es.arrow_size, es.end_fill)
        _arrow(d, pts[0], pts[1], es.start_arrow, col, es.arrow_size, es.start_fill)

    out = canvas.convert("RGB")
    if out_path:
        out.save(out_path)
    return out
