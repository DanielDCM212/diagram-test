"""drawio_kit – deterministic toolkit to turn a structured DiagramSpec into a draw.io file.

The same toolkit is used (a) by the hand-authored replica specs in ``specs/`` and
(b) as the tool layer of the ADK agent in ``diagram_replicator/``. The LLM never
writes raw mxGraph XML: it writes a validated DiagramSpec, and this package
compiles, validates, previews and scores it.
"""
from .schema import DiagramSpec, Node, Edge, Style, EdgeStyle, NodeKind  # noqa: F401
from .compiler import compile_spec, compile_pages  # noqa: F401
from .validate import validate_spec  # noqa: F401
from .preview import render_preview  # noqa: F401
from .render import render_spec, render_drawio  # noqa: F401
