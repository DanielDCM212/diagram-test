"""Pydantic schema for a diagram replica.

All coordinates are ABSOLUTE PIXELS OF THE SOURCE IMAGE (top-left origin), even for
children of containers. The compiler converts to draw.io's parent-relative geometry
and applies a global scale. Working in source-pixel space lets an extractor (human or
LLM) measure things straight off the image and lets the critic compare 1:1.
"""
from __future__ import annotations

from typing import Literal, Optional
from pydantic import BaseModel, Field, field_validator

NodeKind = Literal[
    "rect",            # plain rectangle
    "rounded",         # rounded rectangle
    "container",       # group/swimlane-like box that holds children (label at top)
    "text",            # free text, no border
    "ellipse",
    "hexagon",
    "cylinder",        # database
    "pill",            # fully rounded bar (bus / communication backbone)
    "band",            # thick horizontal/vertical bar (gateways, title bars, load balancers)
    "server_stack",    # composite: N rack units + status LED (+ optional tint)
    "app_icon",        # composite: small application-window glyph
    "db_icon",         # composite: small blue cylinder glyph
    "pipe",            # composite: double-walled vertical/horizontal pipe
    "raster",          # cropped pixels of the source image (logos, clip-art, photos)
    "line",            # free-standing line (boundaries, separators) – no source/target
]

TextDir = Literal["horizontal", "vertical_up", "vertical_down"]


class Style(BaseModel):
    fill: str = "#FFFFFF"            # hex or "none"
    stroke: str = "#000000"          # hex or "none"
    stroke_width: float = 1.0
    dashed: bool = False
    dash_pattern: Optional[str] = None   # e.g. "8 4"
    rounded: Optional[bool] = None       # None -> kind default
    arc_size: Optional[int] = None       # draw.io arcSize (percent) or absolute when abs_arc
    abs_arc: bool = False
    opacity: int = 100
    shadow: bool = False
    gradient: Optional[str] = None       # second colour for vertical gradient
    font_color: str = "#000000"
    font_size: float = 12
    font_family: str = "Helvetica"
    bold: bool = False
    italic: bool = False
    underline: bool = False
    align: Literal["left", "center", "right"] = "center"
    valign: Literal["top", "middle", "bottom"] = "middle"
    text_dir: TextDir = "horizontal"
    spacing: float = 2
    spacing_left: Optional[float] = None
    spacing_right: Optional[float] = None
    spacing_top: Optional[float] = None
    spacing_bottom: Optional[float] = None
    label_bg: Optional[str] = None
    line_height: Optional[float] = None


class Node(BaseModel):
    id: str
    kind: NodeKind = "rect"
    x: float
    y: float
    w: float
    h: float
    label: str = ""                 # "\n" for line breaks; simple <b>,<i>,<u>,<font> allowed
    style: Style = Field(default_factory=Style)
    parent: Optional[str] = None    # id of a container node
    z: int = 0                      # draw order hint inside the same parent (higher = on top)
    # composite / kind specific parameters
    units: int = 3                  # server_stack
    status_color: Optional[str] = None
    tint: Optional[str] = None      # server_stack background tint
    crop: Optional[list[float]] = None   # raster: [x0,y0,x1,y1] in source pixels (default = node box)
    tooltip: Optional[str] = None
    meta: dict = Field(default_factory=dict)   # free-form: legend category, raster "knockout"/"knockout_tol", ...

    @field_validator("w", "h")
    @classmethod
    def _positive(cls, v):
        if v <= 0:
            raise ValueError("width/height must be > 0")
        return v


class EdgeStyle(BaseModel):
    color: str = "#000000"
    width: float = 1.0
    dashed: bool = False
    dash_pattern: Optional[str] = None
    end_arrow: Literal["none", "block", "classic", "open", "oval", "diamond"] = "block"
    end_fill: bool = True
    start_arrow: Literal["none", "block", "classic", "open", "oval", "diamond"] = "none"
    start_fill: bool = True
    arrow_size: float = 6
    routing: Literal["straight", "orthogonal", "polyline"] = "polyline"
    rounded: bool = False
    font_size: float = 11
    font_color: str = "#000000"
    opacity: int = 100


class Edge(BaseModel):
    id: str
    source: Optional[str] = None       # node id (None -> free end)
    target: Optional[str] = None
    source_point: Optional[list[float]] = None   # absolute [x,y] where the line leaves
    target_point: Optional[list[float]] = None   # absolute [x,y] where the arrow tip lands
    waypoints: list[list[float]] = Field(default_factory=list)  # absolute bends in order
    label: str = ""
    style: EdgeStyle = Field(default_factory=EdgeStyle)
    meta: dict = Field(default_factory=dict)


class DiagramSpec(BaseModel):
    name: str
    source_image: Optional[str] = None
    width: float
    height: float
    background: str = "#FFFFFF"
    scale: float = 1.0                 # global output scale (coords + fonts)
    grid: bool = False
    nodes: list[Node] = Field(default_factory=list)
    edges: list[Edge] = Field(default_factory=list)
    notes: str = ""

    def node(self, nid: str) -> Node:
        for n in self.nodes:
            if n.id == nid:
                return n
        raise KeyError(nid)
