"""Compile a DiagramSpec into draw.io (mxGraph) XML.

Design notes
------------
* Spec coordinates are absolute source-image pixels; draw.io wants child geometry
  relative to the parent cell, so we subtract the parent's absolute origin.
* Edges are always attached to real cells when the spec names a source/target, and the
  exact attachment point measured on the image is preserved via exitX/exitY/entryX/entryY
  (perimeter disabled) – the connector stays "live" in draw.io but looks identical.
* Composite kinds (server_stack, app_icon, db_icon, pipe) expand into small groups of
  native cells so every part stays editable.
* Raster kinds embed a PNG crop of the source image as a data URI (draw.io format
  ``data:image/png,<base64>``) for clip-art/logos/photos that have no vector equivalent.
"""
from __future__ import annotations

import base64
import html
import io
from typing import Optional
from xml.sax.saxutils import quoteattr

from .schema import DiagramSpec, Edge, Node, Style

FONT_BITS = {"bold": 1, "italic": 2, "underline": 4}


def _c(v: str) -> str:
    return "none" if (v is None or str(v).lower() in ("none", "transparent", "")) else v


def _label_html(label: str) -> str:
    if label.startswith("html:"):
        return label[5:]
    return "<br>".join(html.escape(p, quote=False) for p in label.split("\n"))


def _text_style(s: Style, k: float) -> list[str]:
    fs = (FONT_BITS["bold"] if s.bold else 0) | (FONT_BITS["italic"] if s.italic else 0) | (
        FONT_BITS["underline"] if s.underline else 0)
    out = [
        f"fontColor={_c(s.font_color)}",
        f"fontSize={round(s.font_size * k, 1)}",
        f"fontFamily={s.font_family}",
        f"fontStyle={fs}",
        f"align={s.align}",
        f"verticalAlign={s.valign}",
        f"spacing={round(s.spacing * k, 1)}",
        "html=1",
        "whiteSpace=wrap",
    ]
    for side in ("left", "right", "top", "bottom"):
        v = getattr(s, f"spacing_{side}")
        if v is not None:
            out.append(f"spacing{side.capitalize()}={round(v * k, 1)}")
    if s.label_bg:
        out.append(f"labelBackgroundColor={s.label_bg}")
    if s.line_height:
        out.append(f"lineHeight={s.line_height}")
    if s.text_dir == "vertical_up":
        out.append("horizontal=0")
    return out


def _box_style(s: Style, k: float, rounded_default: bool) -> list[str]:
    rounded = s.rounded if s.rounded is not None else rounded_default
    out = [
        f"fillColor={_c(s.fill)}",
        f"strokeColor={_c(s.stroke)}",
        f"strokeWidth={s.stroke_width}",
        f"rounded={1 if rounded else 0}",
    ]
    if rounded and s.arc_size is not None:
        out.append(f"arcSize={s.arc_size}")
        if s.abs_arc:
            out.append("absoluteArcSize=1")
    if s.dashed:
        out.append("dashed=1")
        if s.dash_pattern:
            out.append(f"dashPattern={s.dash_pattern}")
    if s.opacity != 100:
        out.append(f"opacity={s.opacity}")
    if s.shadow:
        out.append("shadow=1")
    if s.gradient:
        out += [f"gradientColor={s.gradient}", "gradientDirection=south"]
    return out


class _Emitter:
    def __init__(self, prefix: str):
        self.cells: list[str] = []
        self.prefix = prefix

    def vertex(self, cid, parent, style, x, y, w, h, value="", tooltip=None):
        tip = f" tooltip={quoteattr(tooltip)}" if tooltip else ""
        self.cells.append(
            f'<mxCell id={quoteattr(cid)} value={quoteattr(value)} style={quoteattr(style)} '
            f'vertex="1" parent={quoteattr(parent)}{tip}>'
            f'<mxGeometry x="{x:.2f}" y="{y:.2f}" width="{w:.2f}" height="{h:.2f}" as="geometry"/></mxCell>')

    def edge(self, cid, parent, style, source, target, spt, tpt, pts, value=""):
        attrs = f' source={quoteattr(source)}' if source else ""
        attrs += f' target={quoteattr(target)}' if target else ""
        geo = '<mxGeometry relative="1" as="geometry">'
        if spt:
            geo += f'<mxPoint x="{spt[0]:.2f}" y="{spt[1]:.2f}" as="sourcePoint"/>'
        if tpt:
            geo += f'<mxPoint x="{tpt[0]:.2f}" y="{tpt[1]:.2f}" as="targetPoint"/>'
        if pts:
            geo += '<Array as="points">' + "".join(
                f'<mxPoint x="{p[0]:.2f}" y="{p[1]:.2f}"/>' for p in pts) + "</Array>"
        geo += "</mxGeometry>"
        self.cells.append(
            f'<mxCell id={quoteattr(cid)} value={quoteattr(value)} style={quoteattr(style)} '
            f'edge="1" parent={quoteattr(parent)}{attrs}>{geo}</mxCell>')


def load_crop(image_path: str, box: list[float], knockout: Optional[str] = None, tol: float = 38.0):
    """Crop source pixels. ``knockout`` = "auto" (median colour of the crop border) or a hex
    colour: pixels close to it become transparent, so photographed paper/backgrounds vanish."""
    from PIL import Image
    import numpy as np
    im = Image.open(image_path).convert("RGBA")
    x0, y0, x1, y1 = [int(round(v)) for v in box]
    crop = im.crop((max(0, x0), max(0, y0), min(im.width, x1), min(im.height, y1)))
    if knockout:
        a = np.asarray(crop).astype(np.int32).copy()
        if knockout == "auto":
            border = np.concatenate([a[0, :, :3], a[-1, :, :3], a[:, 0, :3], a[:, -1, :3]])
            ref = np.median(border, axis=0)
        else:
            h = knockout.lstrip("#")
            ref = np.array([int(h[i:i + 2], 16) for i in (0, 2, 4)])
        dist = np.sqrt(((a[:, :, :3] - ref) ** 2).sum(axis=2))
        alpha = np.clip((dist - tol * 0.6) / (tol * 0.4), 0, 1) * 255
        a[:, :, 3] = np.minimum(a[:, :, 3], alpha.astype(np.int32))
        crop = Image.fromarray(a.astype(np.uint8), "RGBA")
    return crop


def _png_data_uri(image_path: str, box: list[float], knockout: Optional[str] = None, tol: float = 38.0) -> str:
    crop = load_crop(image_path, box, knockout, tol)
    buf = io.BytesIO()
    crop.save(buf, format="PNG", optimize=True)
    return "data:image/png," + base64.b64encode(buf.getvalue()).decode()


def _depth(spec: DiagramSpec, n: Node) -> int:
    d, cur, seen = 0, n, set()
    while cur.parent:
        if cur.parent in seen:
            raise ValueError(f"parent cycle at {n.id}")
        seen.add(cur.parent)
        cur = spec.node(cur.parent)
        d += 1
    return d


def compile_graph_model(spec: DiagramSpec, image_path: Optional[str] = None, prefix: str = "") -> str:
    k = spec.scale
    em = _Emitter(prefix)
    P = lambda i: f"{prefix}{i}"  # noqa: E731
    root, layer = P("0"), P("1")
    em.cells.append(f'<mxCell id="{root}"/>')
    em.cells.append(f'<mxCell id="{layer}" parent="{root}"/>')
    # invisible, locked canvas cell: keeps exports aligned 1:1 with the source frame
    em.vertex(P("__canvas"), layer, "fillColor=none;strokeColor=none;locked=1;movable=0;resizable=0;selectable=0;",
              0, 0, spec.width * k, spec.height * k)
    if spec.background and spec.background.upper() not in ("#FFFFFF", "NONE"):
        em.vertex(P("__bg"), layer, f"fillColor={spec.background};strokeColor=none;locked=1;",
                  0, 0, spec.width * k, spec.height * k)

    by_id = {n.id: n for n in spec.nodes}
    order = sorted(spec.nodes, key=lambda n: (_depth(spec, n), n.z))
    img = image_path or spec.source_image

    for n in order:
        s = n.style
        parent_cell = P(n.parent) if n.parent else layer
        ox, oy = (by_id[n.parent].x, by_id[n.parent].y) if n.parent else (0.0, 0.0)
        x, y, w, h = (n.x - ox) * k, (n.y - oy) * k, n.w * k, n.h * k
        value = _label_html(n.label)
        cid = P(n.id)
        text = _text_style(s, k)

        if n.kind == "line":
            horiz = n.w >= n.h
            a = (n.x, n.y + n.h / 2) if horiz else (n.x + n.w / 2, n.y)
            b = (n.x + n.w, n.y + n.h / 2) if horiz else (n.x + n.w / 2, n.y + n.h)
            st = [f"endArrow=none", f"strokeColor={_c(s.stroke)}", f"strokeWidth={s.stroke_width}", "html=1"]
            if s.dashed:
                st += ["dashed=1"] + ([f"dashPattern={s.dash_pattern}"] if s.dash_pattern else [])
            em.edge(cid, layer, ";".join(st) + ";", None, None,
                    (a[0] * k, a[1] * k), (b[0] * k, b[1] * k), [])
            continue

        if n.kind == "server_stack":
            em.vertex(cid, parent_cell, "group;", x, y, w, h, tooltip=n.tooltip)
            gap = 2 * k
            if n.tint:
                em.vertex(P(f"{n.id}__tint"), cid, f"fillColor={n.tint};strokeColor=none;", 0, -4 * k, w, h + 4 * k)
            uh = (h - gap * (n.units - 1)) / n.units
            for i in range(n.units):
                uy = i * (uh + gap)
                em.vertex(P(f"{n.id}__u{i}"), cid,
                          f"rounded=1;arcSize=12;fillColor={_c(s.fill) if s.fill != '#FFFFFF' else '#6E6E70'};strokeColor=none;",
                          0, uy, w, uh)
                em.vertex(P(f"{n.id}__d{i}"), cid, "ellipse;fillColor=#FFFFFF;strokeColor=none;",
                          5 * k, uy + 4 * k, 6 * k, 6 * k)
                em.vertex(P(f"{n.id}__b{i}"), cid, "fillColor=#FFFFFF;strokeColor=none;",
                          w - 42 * k, uy + uh - 9 * k, 34 * k, 3 * k)
            if n.status_color:
                em.vertex(P(f"{n.id}__led"), cid, f"ellipse;fillColor={n.status_color};strokeColor=none;",
                          5 * k, h - 17 * k, 14 * k, 14 * k)
            continue

        if n.kind == "app_icon":
            col = s.stroke if s.stroke not in ("#000000", "none") else "#2A6EBB"
            em.vertex(cid, parent_cell, "group;", x, y, w, h)
            em.vertex(P(f"{n.id}__frame"), cid, f"fillColor=#FFFFFF;strokeColor={col};strokeWidth={max(1.5, s.stroke_width)};",
                      0, 0, w, h)
            em.vertex(P(f"{n.id}__bar"), cid, f"fillColor={col};strokeColor=none;", 0, 0, w, max(2.5, h * 0.18))
            continue

        if n.kind == "db_icon":
            fill = s.fill if s.fill != "#FFFFFF" else "#2447B8"
            em.vertex(cid, parent_cell,
                      f"shape=cylinder3;boundedLbl=1;backgroundOutline=1;size={max(3, h * 0.18):.1f};"
                      f"fillColor={fill};gradientColor=#0B2C8C;gradientDirection=south;strokeColor=#0A2366;",
                      x, y, w, h)
            continue

        if n.kind == "pipe":
            em.vertex(cid, parent_cell, "group;", x, y, w, h)
            em.vertex(P(f"{n.id}__o"), cid, f"fillColor={_c(s.fill) if s.fill!='#FFFFFF' else '#A6A6A6'};strokeColor={_c(s.stroke)};strokeWidth={s.stroke_width};",
                      0, 0, w, h)
            if n.w <= n.h:
                em.vertex(P(f"{n.id}__i"), cid, "fillColor=#FFFFFF;strokeColor=#000000;strokeWidth=1;", w * 0.3, 0, w * 0.3, h)
            else:
                em.vertex(P(f"{n.id}__i"), cid, "fillColor=#FFFFFF;strokeColor=#000000;strokeWidth=1;", 0, h * 0.3, w, h * 0.3)
            continue

        if n.kind == "raster":
            if not img:
                # no source image available – degrade to a labelled placeholder
                em.vertex(cid, parent_cell, "rounded=0;dashed=1;fillColor=#F5F5F5;strokeColor=#999999;fontSize=9;html=1;",
                          x, y, w, h, value or "[image]")
                continue
            uri = _png_data_uri(img, n.crop or [n.x, n.y, n.x + n.w, n.y + n.h], n.meta.get("knockout"),
                                float(n.meta.get("knockout_tol", 38)))
            em.vertex(cid, parent_cell,
                      f"shape=image;verticalLabelPosition=bottom;verticalAlign=top;imageAspect=0;image={uri};",
                      x, y, w, h, value)
            continue

        # ---- simple kinds -------------------------------------------------------------
        shape: list[str] = []
        if n.kind == "text":
            shape = ["text", "strokeColor=none", f"fillColor={_c(s.fill) if s.fill != '#FFFFFF' else 'none'}"]
            if s.stroke not in ("#000000", "none"):
                shape[1] = f"strokeColor={s.stroke}"
        elif n.kind == "ellipse":
            shape = ["ellipse"] + _box_style(s, k, False)
        elif n.kind == "hexagon":
            shape = ["shape=hexagon", "perimeter=hexagonPerimeter2", "size=0.25", "fixedSize=0"] + _box_style(s, k, False)
        elif n.kind == "cylinder":
            shape = ["shape=cylinder3", "boundedLbl=1", "backgroundOutline=1", f"size={max(4, h * 0.15):.1f}"] + _box_style(s, k, False)
        elif n.kind == "pill":
            st = s.model_copy(update={"rounded": True, "arc_size": 50, "abs_arc": False})
            shape = _box_style(st, k, True)
        elif n.kind == "container":
            shape = _box_style(s, k, True) + ["container=1", "collapsible=0", "recursiveResize=0"]
        elif n.kind in ("rounded",):
            shape = _box_style(s, k, True)
        else:  # rect, band
            shape = _box_style(s, k, False)

        rot = []
        if s.text_dir == "vertical_down":
            # rotate the whole cell 90° clockwise: geometry is the un-rotated box around the same centre
            cx, cy = x + w / 2, y + h / 2
            x, y, w, h = cx - h / 2, cy - w / 2, h, w
            rot = ["rotation=90"]
        em.vertex(cid, parent_cell, ";".join(shape + text + rot) + ";", x, y, w, h, value, n.tooltip)

    # ---- edges --------------------------------------------------------------------------
    for e in spec.edges:
        em.edge(*_edge_args(spec, e, k, P, layer))

    return ('<mxGraphModel dx="0" dy="0" grid="{g}" gridSize="10" guides="1" tooltips="1" connect="1" arrows="1" '
            'fold="1" page="1" pageScale="1" pageWidth="{w}" pageHeight="{h}" math="0" shadow="0"><root>'
            .format(g=1 if spec.grid else 0, w=int(spec.width * k), h=int(spec.height * k))
            + "".join(em.cells) + "</root></mxGraphModel>")


def _rel(n: Node, pt) -> tuple[float, float]:
    rx = (pt[0] - n.x) / n.w
    ry = (pt[1] - n.y) / n.h
    return min(1.0, max(0.0, rx)), min(1.0, max(0.0, ry))


def _edge_args(spec: DiagramSpec, e: Edge, k: float, P, layer):
    s = e.style
    st = [
        "html=1",
        f"strokeColor={s.color}",
        f"strokeWidth={s.width}",
        f"endArrow={s.end_arrow}",
        f"endFill={1 if s.end_fill else 0}",
        f"startArrow={s.start_arrow}",
        f"startFill={1 if s.start_fill else 0}",
        f"endSize={s.arrow_size}",
        f"startSize={s.arrow_size}",
        f"rounded={1 if s.rounded else 0}",
        f"fontSize={s.font_size * k}",
        f"fontColor={s.font_color}",
    ]
    st.append({"straight": "edgeStyle=none", "polyline": "edgeStyle=none",
               "orthogonal": "edgeStyle=orthogonalEdgeStyle"}[s.routing])
    if s.dashed:
        st.append("dashed=1")
        if s.dash_pattern:
            st.append(f"dashPattern={s.dash_pattern}")
    if s.opacity != 100:
        st.append(f"opacity={s.opacity}")
    src = spec.node(e.source) if e.source else None
    tgt = spec.node(e.target) if e.target else None
    if src and e.source_point:
        ex, ey = _rel(src, e.source_point)
        st += [f"exitX={ex:.4f}", f"exitY={ey:.4f}", "exitDx=0", "exitDy=0", "exitPerimeter=0"]
    if tgt and e.target_point:
        nx, ny = _rel(tgt, e.target_point)
        st += [f"entryX={nx:.4f}", f"entryY={ny:.4f}", "entryDx=0", "entryDy=0", "entryPerimeter=0"]
    spt = [v * k for v in e.source_point] if e.source_point else None
    tpt = [v * k for v in e.target_point] if e.target_point else None
    pts = [[v * k for v in p] for p in e.waypoints]
    return (P(e.id), layer, ";".join(st) + ";", P(e.source) if src else None, P(e.target) if tgt else None,
            spt, tpt, pts, _label_html(e.label))


def compile_spec(spec: DiagramSpec, image_path: Optional[str] = None) -> str:
    return compile_pages([(spec, image_path)])


def compile_pages(pages) -> str:
    """pages: iterable of (DiagramSpec, image_path|None). One draw.io page per spec."""
    out = ['<mxfile host="drawio_kit" agent="diagram_replicator" version="24.0.0" type="device">']
    for i, (spec, img) in enumerate(pages):
        prefix = f"p{i}-"
        out.append(f'<diagram id="page-{i}" name={quoteattr(spec.name)}>')
        out.append(compile_graph_model(spec, img, prefix))
        out.append("</diagram>")
    out.append("</mxfile>")
    return "\n".join(out)
