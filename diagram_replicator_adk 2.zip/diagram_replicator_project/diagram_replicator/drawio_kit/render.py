"""Render .drawio with the real draw.io desktop CLI (headless via xvfb) when available,
falling back to the Pillow preview. Real renders are what the critic should look at."""
from __future__ import annotations

import os
import shutil
import subprocess
import tempfile
from typing import Optional

from PIL import Image

from .preview import render_preview
from .schema import DiagramSpec


def drawio_binary() -> Optional[str]:
    for cand in (os.environ.get("DRAWIO_BIN"), "drawio", "draw.io",
                 "/opt/drawio/drawio", "/Applications/draw.io.app/Contents/MacOS/draw.io"):
        if cand and (shutil.which(cand) or os.path.exists(cand)):
            return shutil.which(cand) or cand
    return None


def render_drawio(drawio_path: str, out_png: str, page_index: int = 0, scale: float = 1.0,
                  timeout: int = 180) -> bool:
    exe = drawio_binary()
    if not exe:
        return False
    cmd = [exe, "--no-sandbox", "-x", "-f", "png", "-b", "0", "-s", str(scale), "-p", str(page_index),
           "-o", out_png, drawio_path]
    if os.name != "nt" and not os.environ.get("DISPLAY") and shutil.which("xvfb-run"):
        cmd = ["xvfb-run", "-a"] + cmd
    for _ in range(2):  # first headless Electron launch occasionally fails; retry once
        try:
            subprocess.run(cmd, check=True, capture_output=True, timeout=timeout)
            if os.path.exists(out_png):
                return True
        except (subprocess.SubprocessError, OSError):
            continue
    return False


def render_spec(spec: DiagramSpec, drawio_xml: str, out_png: str, image_path: Optional[str] = None) -> dict:
    """Render in SOURCE pixel space (so it can be diffed against the source)."""
    with tempfile.TemporaryDirectory() as td:
        p = os.path.join(td, "d.drawio")
        open(p, "w").write(drawio_xml)
        if render_drawio(p, out_png, scale=1.0 / spec.scale):
            im = Image.open(out_png).convert("RGB")
            W, H = int(round(spec.width)), int(round(spec.height))
            if im.size != (W, H):
                im = im.resize((W, H))
            bg = Image.new("RGB", (W, H), "white")
            bg.paste(im)
            bg.save(out_png)
            return {"renderer": "drawio", "path": out_png}
    render_preview(spec, image_path, out_png)
    return {"renderer": "pillow", "path": out_png}
