"""Structural + geometric validation of a DiagramSpec (no image needed)."""
from __future__ import annotations

import math
import re

from .schema import DiagramSpec

HEX = re.compile(r"^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$")


def _hex_ok(c):
    return c is None or c.lower() in ("none", "transparent") or bool(HEX.match(c))


def _dist_to_box(pt, n):
    x, y = pt
    dx = max(n.x - x, 0, x - (n.x + n.w))
    dy = max(n.y - y, 0, y - (n.y + n.h))
    outside = math.hypot(dx, dy)
    if outside > 0:
        return outside
    return min(x - n.x, n.x + n.w - x, y - n.y, n.y + n.h - y)  # distance to perimeter from inside


def validate_spec(spec: DiagramSpec, tol: float = 8.0) -> dict:
    errors, warnings, info = [], [], []
    ids = [n.id for n in spec.nodes] + [e.id for e in spec.edges]
    dup = {i for i in ids if ids.count(i) > 1}
    if dup:
        errors.append(f"duplicate ids: {sorted(dup)}")
    by = {n.id: n for n in spec.nodes}

    for n in spec.nodes:
        for c in (n.style.fill, n.style.stroke, n.style.font_color, n.status_color, n.tint):
            if not _hex_ok(c):
                errors.append(f"{n.id}: invalid colour {c!r}")
        if n.parent:
            p = by.get(n.parent)
            if p is None:
                errors.append(f"{n.id}: parent {n.parent!r} does not exist")
                continue
            if p.kind != "container":
                errors.append(f"{n.id}: parent {p.id} must be kind=container (is {p.kind})")
            if (n.x < p.x - tol or n.y < p.y - tol or n.x + n.w > p.x + p.w + tol or n.y + n.h > p.y + p.h + tol):
                warnings.append(f"{n.id}: sticks out of parent {p.id}")
        if n.x < -tol or n.y < -tol or n.x + n.w > spec.width + tol or n.y + n.h > spec.height + tol:
            warnings.append(f"{n.id}: outside canvas")
        if n.kind in ("rect", "rounded", "pill", "band") and not n.label.strip() and n.style.fill in ("#FFFFFF", "none"):
            info.append(f"{n.id}: empty unlabeled white box (is that intended?)")
        if n.style.font_size < 4 or n.style.font_size > 96:
            warnings.append(f"{n.id}: suspicious font size {n.style.font_size}")
        # rough text overflow check (avg glyph ≈ 0.52em)
        if n.label and n.kind not in ("raster", "server_stack", "app_icon", "db_icon", "line"):
            txt = re.sub(r"<[^>]+>", "", n.label.replace("html:", ""))
            lines = txt.split("\n")
            horiz = n.style.text_dir == "horizontal"
            avail_w, avail_h = (n.w, n.h) if horiz else (n.h, n.w)
            longest = max(len(l) for l in lines) * n.style.font_size * 0.52
            wrapped = sum(max(1, math.ceil(len(l) * n.style.font_size * 0.52 / max(1, avail_w - 4))) for l in lines)
            need_h = wrapped * n.style.font_size * 1.2
            if need_h > avail_h * 1.35 + 4 and n.kind != "container":
                warnings.append(f"{n.id}: label probably overflows ({need_h:.0f}px needed vs {avail_h:.0f}px)")
            if longest > avail_w * 2.5:
                info.append(f"{n.id}: long label will wrap heavily")

    # identical-geometry duplicates
    seen = {}
    for n in spec.nodes:
        key = (round(n.x), round(n.y), round(n.w), round(n.h), n.kind)
        if key in seen and n.kind != "text":
            warnings.append(f"{n.id}: same box as {seen[key]} (duplicate element?)")
        seen[key] = n.id

    # parent cycles
    for n in spec.nodes:
        cur, hops = n, 0
        while cur.parent and hops < 50:
            cur = by.get(cur.parent)
            if cur is None:
                break
            hops += 1
        if hops >= 50:
            errors.append(f"{n.id}: parent cycle")

    connected = set()
    for e in spec.edges:
        if not _hex_ok(e.style.color):
            errors.append(f"{e.id}: invalid colour {e.style.color!r}")
        for role, nid, pt in (("source", e.source, e.source_point), ("target", e.target, e.target_point)):
            if nid is None and pt is None:
                errors.append(f"{e.id}: {role} needs a node id or a point")
            if nid is not None:
                if nid not in by:
                    errors.append(f"{e.id}: {role} {nid!r} does not exist")
                    continue
                connected.add(nid)
                if pt is not None and _dist_to_box(pt, by[nid]) > tol:
                    warnings.append(f"{e.id}: {role}_point {pt} is {_dist_to_box(pt, by[nid]):.0f}px from {nid}'s border")
        if e.source and e.source == e.target and not e.waypoints:
            warnings.append(f"{e.id}: self loop without waypoints")

    stats = {
        "nodes": len(spec.nodes),
        "edges": len(spec.edges),
        "containers": sum(n.kind == "container" for n in spec.nodes),
        "rasters": sum(n.kind == "raster" for n in spec.nodes),
        "labelled_nodes": sum(bool(n.label.strip()) for n in spec.nodes),
        "unconnected_boxes": sorted(n.id for n in spec.nodes if n.kind in ("rect", "rounded") and n.id not in connected),
    }
    return {"ok": not errors, "errors": errors, "warnings": warnings, "info": info, "stats": stats}
