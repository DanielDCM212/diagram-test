"""Deterministic computer-vision helpers used for grounding and scoring.

Everything here is classic CV (OpenCV / Tesseract / Pillow). The agent calls these as
tools so that coordinates, text and colours come from measurements rather than from the
LLM's imagination; the LLM decides semantics (what is a container, what connects to what).
"""
from __future__ import annotations

import os
import re
from typing import Optional

import numpy as np
from PIL import Image, ImageDraw, ImageFont

try:
    import cv2
except ImportError:  # pragma: no cover
    cv2 = None
try:
    import pytesseract
except ImportError:  # pragma: no cover
    pytesseract = None


def _hex(rgb) -> str:
    return "#%02X%02X%02X" % tuple(int(v) for v in rgb[:3])


def image_info(path: str, k: int = 8) -> dict:
    im = Image.open(path).convert("RGB")
    small = np.asarray(im.resize((min(300, im.width), int(im.height * min(300, im.width) / im.width))))
    px = small.reshape(-1, 3).astype(np.float32)
    palette = []
    if cv2 is not None:
        crit = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 20, 1.0)
        _, labels, centers = cv2.kmeans(px, k, None, crit, 3, cv2.KMEANS_PP_CENTERS)
        counts = np.bincount(labels.ravel(), minlength=k)
        for idx in np.argsort(-counts):
            palette.append({"color": _hex(centers[idx]), "share": round(float(counts[idx] / counts.sum()), 3)})
    border = np.concatenate([small[0], small[-1], small[:, 0], small[:, -1]])
    bg = _hex(np.median(border, axis=0))
    return {"width": im.width, "height": im.height, "background": bg, "palette": palette,
            "is_photo_like": bool(np.std(border) > 12)}


def sample_colors(path: str, points: list[list[float]], radius: int = 2) -> list[dict]:
    im = np.asarray(Image.open(path).convert("RGB"))
    out = []
    for x, y in points:
        x, y = int(x), int(y)
        patch = im[max(0, y - radius):y + radius + 1, max(0, x - radius):x + radius + 1].reshape(-1, 3)
        out.append({"point": [x, y], "color": _hex(np.median(patch, axis=0))})
    return out


def tesseract_available() -> bool:
    """True only if pytesseract is importable AND the tesseract binary actually runs."""
    if pytesseract is None:
        return False
    try:
        pytesseract.get_tesseract_version()
        return True
    except Exception:
        return False


def ocr_words(path: str, region: Optional[list[float]] = None, upscale: float = 2.0, min_conf: float = 35) -> list[dict]:
    if not tesseract_available():
        return []
    im = Image.open(path).convert("RGB")
    ox = oy = 0
    if region:
        ox, oy = int(region[0]), int(region[1])
        im = im.crop(tuple(int(v) for v in region))
    big = im.resize((int(im.width * upscale), int(im.height * upscale)), Image.LANCZOS)
    d = pytesseract.image_to_data(big, config="--psm 11", output_type=pytesseract.Output.DICT)
    words = []
    for i, t in enumerate(d["text"]):
        if t.strip() and float(d["conf"][i]) >= min_conf:
            words.append({"text": t, "conf": float(d["conf"][i]),
                          "x": round(d["left"][i] / upscale + ox, 1), "y": round(d["top"][i] / upscale + oy, 1),
                          "w": round(d["width"][i] / upscale, 1), "h": round(d["height"][i] / upscale, 1)})
    return words


def ocr_lines(path: str, region: Optional[list[float]] = None, upscale: float = 2.0,
              words: Optional[list[dict]] = None) -> list[dict]:
    """Group OCR words into text lines (left-to-right, similar baseline, small gaps)."""
    if words is None:
        words = ocr_words(path, region, upscale)
    words = sorted(words, key=lambda w: (w["y"], w["x"]))
    lines: list[list[dict]] = []
    for w in words:
        for L in lines:
            last = L[-1]
            if abs(last["y"] - w["y"]) < max(6, last["h"] * 0.7) and -4 <= w["x"] - (last["x"] + last["w"]) < last["h"] * 2.2:
                L.append(w)
                break
        else:
            lines.append([w])
    out = []
    for L in lines:
        x0 = min(w["x"] for w in L); y0 = min(w["y"] for w in L)
        x1 = max(w["x"] + w["w"] for w in L); y1 = max(w["y"] + w["h"] for w in L)
        out.append({"text": " ".join(w["text"] for w in L), "x": x0, "y": y0, "w": round(x1 - x0, 1),
                    "h": round(y1 - y0, 1), "conf": round(sum(w["conf"] for w in L) / len(L), 1)})
    return sorted(out, key=lambda l: (l["y"], l["x"]))


def detect_boxes(path: str, region: Optional[list[float]] = None, min_w: int = 20, min_h: int = 12,
                 upscale: float = 1.0) -> list[dict]:
    """Axis-aligned rectangles (outlined or filled) with fill + stroke colour estimates."""
    if cv2 is None:
        return []
    img = cv2.imread(path)
    ox = oy = 0
    if region:
        x0, y0, x1, y1 = [int(v) for v in region]
        img, ox, oy = img[y0:y1, x0:x1], x0, y0
    if upscale != 1.0:
        img = cv2.resize(img, None, fx=upscale, fy=upscale, interpolation=cv2.INTER_CUBIC)
    g = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    e = cv2.dilate(cv2.Canny(g, 40, 120), np.ones((2, 2), np.uint8))
    cs, _ = cv2.findContours(e, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    seen, out = [], []
    for c in cs:
        x, y, w, h = cv2.boundingRect(c)
        if w < min_w * upscale or h < min_h * upscale:
            continue
        if cv2.contourArea(c) < 0.7 * w * h:
            continue
        if any(abs(x - a) < 4 and abs(y - b) < 4 and abs(w - cc) < 6 and abs(h - dd) < 6 for a, b, cc, dd in seen):
            continue
        seen.append((x, y, w, h))
        inner = img[y + h // 4:y + 3 * h // 4, x + w // 8:x + 7 * w // 8].reshape(-1, 3)
        edge = img[y:y + 2, x + w // 4:x + 3 * w // 4].reshape(-1, 3)
        fill = np.median(inner, axis=0)[::-1] if len(inner) else [255, 255, 255]
        stroke = np.median(edge, axis=0)[::-1] if len(edge) else [0, 0, 0]
        approx = cv2.approxPolyDP(c, 0.02 * cv2.arcLength(c, True), True)
        out.append({"x": round(x / upscale + ox, 1), "y": round(y / upscale + oy, 1), "w": round(w / upscale, 1),
                    "h": round(h / upscale, 1), "fill": _hex(fill), "stroke": _hex(stroke),
                    "corners": int(len(approx)), "rounded_hint": bool(len(approx) > 4)})
    out.sort(key=lambda b: (b["y"], b["x"]))
    return out


def detect_lines(path: str, region: Optional[list[float]] = None, min_len: int = 25) -> list[dict]:
    """Line segments (Hough). Dashed lines show up as several collinear short segments –
    we merge collinear pieces and flag them as dashed when the fill ratio is low."""
    if cv2 is None:
        return []
    img = cv2.imread(path)
    ox = oy = 0
    if region:
        x0, y0, x1, y1 = [int(v) for v in region]
        img, ox, oy = img[y0:y1, x0:x1], x0, y0
    g = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    e = cv2.Canny(g, 50, 150)
    segs = cv2.HoughLinesP(e, 1, np.pi / 180, 30, minLineLength=8, maxLineGap=12)
    if segs is None:
        return []
    raw = []
    for x1, y1, x2, y2 in segs[:, 0]:
        L = float(np.hypot(x2 - x1, y2 - y1))
        orient = "h" if abs(y2 - y1) <= 2 else "v" if abs(x2 - x1) <= 2 else "d"
        raw.append({"x1": int(x1) + ox, "y1": int(y1) + oy, "x2": int(x2) + ox, "y2": int(y2) + oy, "len": L, "o": orient})
    merged = []
    for s in sorted(raw, key=lambda s: -s["len"]):
        for m in merged:
            if m["o"] == s["o"] == "h" and abs(m["y1"] - s["y1"]) <= 3 and not (max(s["x1"], s["x2"]) < min(m["x1"], m["x2"]) - 14 or min(s["x1"], s["x2"]) > max(m["x1"], m["x2"]) + 14):
                m["x1"], m["x2"] = min(m["x1"], m["x2"], s["x1"], s["x2"]), max(m["x1"], m["x2"], s["x1"], s["x2"]); m["pieces"] += 1; m["ink"] += s["len"]; break
            if m["o"] == s["o"] == "v" and abs(m["x1"] - s["x1"]) <= 3 and not (max(s["y1"], s["y2"]) < min(m["y1"], m["y2"]) - 14 or min(s["y1"], s["y2"]) > max(m["y1"], m["y2"]) + 14):
                m["y1"], m["y2"] = min(m["y1"], m["y2"], s["y1"], s["y2"]), max(m["y1"], m["y2"], s["y1"], s["y2"]); m["pieces"] += 1; m["ink"] += s["len"]; break
        else:
            merged.append(dict(s, pieces=1, ink=s["len"]))
    out = []
    for m in merged:
        L = float(np.hypot(m["x2"] - m["x1"], m["y2"] - m["y1"]))
        if L < min_len:
            continue
        out.append({"x1": m["x1"], "y1": m["y1"], "x2": m["x2"], "y2": m["y2"], "orientation": m["o"],
                    "length": round(L, 1), "dashed_hint": bool(m["pieces"] >= 4 and m["ink"] < 0.8 * L)})
    return sorted(out, key=lambda l: -l["length"])


def crop_with_grid(path: str, box: list[float], out_path: str, zoom: float = 2.0, step: int = 50) -> dict:
    """Zoomed crop with an overlaid coordinate grid labelled in SOURCE pixels.
    Showing this to a multimodal model makes coordinate reading far more accurate."""
    im = Image.open(path).convert("RGB")
    x0, y0, x1, y1 = [int(v) for v in box]
    c = im.crop((x0, y0, x1, y1)).resize((int((x1 - x0) * zoom), int((y1 - y0) * zoom)), Image.LANCZOS)
    d = ImageDraw.Draw(c)
    try:
        f = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 11)
    except OSError:
        f = ImageFont.load_default()
    for gx in range((x0 // step + 1) * step, x1, step):
        X = (gx - x0) * zoom
        d.line([(X, 0), (X, c.height)], fill=(255, 0, 255), width=1)
        d.text((X + 2, 2), str(gx), fill=(200, 0, 200), font=f)
    for gy in range((y0 // step + 1) * step, y1, step):
        Y = (gy - y0) * zoom
        d.line([(0, Y), (c.width, Y)], fill=(0, 150, 255), width=1)
        d.text((2, Y + 2), str(gy), fill=(0, 110, 230), font=f)
    c.save(out_path)
    return {"path": out_path, "box": [x0, y0, x1, y1], "zoom": zoom, "grid_step": step}


def make_tiles(path: str, out_dir: str, rows: int, cols: int, overlap: float = 0.12, zoom: float = 1.5,
               grid_step: int = 50) -> list[dict]:
    im = Image.open(path)
    W, H = im.size
    tw, th = W / cols, H / rows
    ow, oh = tw * overlap, th * overlap
    os.makedirs(out_dir, exist_ok=True)
    tiles = []
    for r in range(rows):
        for c in range(cols):
            box = [max(0, c * tw - ow), max(0, r * th - oh), min(W, (c + 1) * tw + ow), min(H, (r + 1) * th + oh)]
            p = os.path.join(out_dir, f"tile_r{r}_c{c}.png")
            meta = crop_with_grid(path, box, p, zoom=zoom, step=grid_step)
            meta.update({"row": r, "col": c, "id": f"r{r}c{c}"})
            tiles.append(meta)
    return tiles


def suggest_tiling(width: int, height: int, words: int = 0) -> tuple[int, int]:
    """Heuristic: aim for tiles ≤ ~900px source and ≤ ~60 text lines each."""
    cols = max(1, round(width / 900))
    rows = max(1, round(height / 700))
    while words and words / (rows * cols) > 120:
        if width / cols > height / rows:
            cols += 1
        else:
            rows += 1
    return rows, cols


def similarity(original: str, replica_png: str, diff_out: Optional[str] = None) -> dict:
    """Layout similarity between source and preview: SSIM-like score on blurred grayscale,
    plus edge-map F1 (tolerant to 3px misalignment). Writes a red/green diff heat-map."""
    a = Image.open(original).convert("L")
    b = Image.open(replica_png).convert("L").resize(a.size)
    target_w = 800
    s = target_w / a.width
    size = (target_w, max(1, int(a.height * s)))
    A = np.asarray(a.resize(size), dtype=np.float32)
    B = np.asarray(b.resize(size), dtype=np.float32)
    out = {}
    if cv2 is not None:
        Ab, Bb = cv2.GaussianBlur(A, (7, 7), 1.5), cv2.GaussianBlur(B, (7, 7), 1.5)
        mu_a, mu_b = cv2.GaussianBlur(Ab, (11, 11), 3), cv2.GaussianBlur(Bb, (11, 11), 3)
        va = cv2.GaussianBlur(Ab * Ab, (11, 11), 3) - mu_a ** 2
        vb = cv2.GaussianBlur(Bb * Bb, (11, 11), 3) - mu_b ** 2
        cov = cv2.GaussianBlur(Ab * Bb, (11, 11), 3) - mu_a * mu_b
        C1, C2 = (0.01 * 255) ** 2, (0.03 * 255) ** 2
        ssim = ((2 * mu_a * mu_b + C1) * (2 * cov + C2)) / ((mu_a ** 2 + mu_b ** 2 + C1) * (va + vb + C2))
        out["ssim"] = round(float(ssim.mean()), 4)
        ea = cv2.Canny(A.astype(np.uint8), 50, 150) > 0
        eb = cv2.Canny(B.astype(np.uint8), 50, 150) > 0
        k = np.ones((7, 7), np.uint8)
        da, db = cv2.dilate(ea.astype(np.uint8), k) > 0, cv2.dilate(eb.astype(np.uint8), k) > 0
        prec = float((eb & da).sum() / max(1, eb.sum()))
        rec = float((ea & db).sum() / max(1, ea.sum()))
        out.update({"edge_precision": round(prec, 4), "edge_recall": round(rec, 4),
                    "edge_f1": round(2 * prec * rec / max(1e-6, prec + rec), 4)})
        if diff_out:
            h = np.zeros(A.shape + (3,), np.uint8) + 255
            h[ea & ~db] = (220, 30, 30)    # in source, missing in replica -> red
            h[eb & ~da] = (30, 160, 30)    # in replica, not in source -> green
            h[ea & db] = (160, 160, 160)
            Image.fromarray(h).resize(a.size).save(diff_out)
            out["diff_image"] = diff_out
    out["score"] = round(0.4 * out.get("ssim", 0) + 0.6 * out.get("edge_f1", 0), 4)
    return out


_TOKEN = re.compile(r"[A-Za-z0-9]{2,}")
_CONFUSABLE = str.maketrans({"o": "0", "i": "1", "l": "1", "|": "1", "s": "5", "b": "8", "z": "2", "g": "9"})


def _canon(t: str) -> str:
    """OCR-robust token form: case-folded, look-alike glyphs unified (O/0, I/l/1, S/5, B/8)."""
    return t.lower().translate(_CONFUSABLE)


def _near(tok: str, pool: set) -> bool:
    if tok in pool:
        return True
    if len(tok) < 5:
        return False
    import difflib
    return bool(difflib.get_close_matches(tok, pool, n=1, cutoff=0.8))


def text_coverage(spec_labels: list[str], ocr: list[dict]) -> dict:
    """Which OCR'd tokens from the source never appear in any spec label (likely missed text)."""
    have = set()
    for l in spec_labels:
        have |= {_canon(t) for t in _TOKEN.findall(re.sub(r"<[^>]+>", " ", l))}
    missing = []
    total = 0
    for w in ocr:
        for t in _TOKEN.findall(w["text"]):
            if len(t) < 3 or w.get("conf", 100) < 60:
                continue
            total += 1
            if not _near(_canon(t), have):
                missing.append({"token": t, "x": w["x"], "y": w["y"]})
    return {"checked_tokens": total, "missing_count": len(missing),
            "coverage": round(1 - len(missing) / max(1, total), 4), "missing": missing[:200]}
