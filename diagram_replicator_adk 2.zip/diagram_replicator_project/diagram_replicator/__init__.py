"""ADK agent that replicates a diagram image as an editable draw.io file.

Public API:
    root_agent               ready-made pipeline (for `adk web` / `adk run`)
    build_root_agent()       fresh pipeline instance (an ADK agent can only have one parent)
    replicate_diagram_tool   FunctionTool wrapper running the pipeline in an isolated session
"""
from . import agent  # noqa: F401
from .agent import build_root_agent, root_agent  # noqa: F401
from .integration import configure_tool, replicate_diagram, replicate_diagram_tool  # noqa: F401
