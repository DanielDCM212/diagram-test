"""Per-session working directory. Large payloads live on disk; session state keeps paths."""
from __future__ import annotations

import json
import os


class Workspace:
    def __init__(self, root: str):
        self.root = root
        for d in ("", "tiles", "extractions", "history", "crops", "out"):
            os.makedirs(os.path.join(root, d), exist_ok=True)

    def p(self, *parts) -> str:
        return os.path.join(self.root, *parts)

    def write_json(self, name, obj) -> str:
        path = self.p(name)
        with open(path, "w") as f:
            json.dump(obj, f, indent=1, default=str)
        return path

    def read_json(self, name, default=None):
        path = self.p(name)
        if not os.path.exists(path):
            return default
        with open(path) as f:
            return json.load(f)

    @property
    def source(self):
        return self.p("source.png")


def ws_from_state(state) -> Workspace:
    root = state.get("ws_dir")
    if not root:
        raise RuntimeError("workspace not initialised – ingest stage must run first")
    return Workspace(root)
