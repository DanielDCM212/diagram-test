"""Instruction providers. Each returns the full instruction for one LLM role, built from
session state + workspace files at call time (no {placeholder} templating, so JSON braces
in the text are safe)."""
from __future__ import annotations

import json

from .config import CONFIG
from .workspace import ws_from_state

CORE_RULES = """
You are part of a pipeline that rebuilds a diagram IMAGE as an editable draw.io file with
maximum fidelity. You never write draw.io XML. You produce structured JSON that a
deterministic compiler turns into draw.io. Fidelity rules (non-negotiable):

COORDINATES
- Every coordinate is in SOURCE IMAGE PIXELS, origin top-left, even for children of
  containers. Images you receive carry a magenta (x) / blue (y) grid labelled in SOURCE
  pixels: read positions off those labels, never off the zoomed picture's own pixels.
- Boxes: x,y = top-left corner of the visible border; w,h = border to border. Measure;
  do not round to "nice" numbers. Tolerance target: ±3 px.

EXHAUSTIVENESS
- Every visible thing becomes an element: every box, every label, every free-floating
  caption, numbers in brackets, IDs, legend entries, title bars, zone labels,
  page numbers, watermarks/copyright lines, icons and logos. Never summarise ("…",
  "etc.", "and 12 more"), never merge two boxes into one, never skip "decorative"
  items. If 40 boxes are visible, output 40 elements.
- Text is transcribed EXACTLY (case, punctuation, spacing, typos in the source).
  Put "\\n" where the source breaks a line. Small secondary text inside a box
  (e.g. "[99.6]" in a corner) is a SEPARATE kind=text element with its own box.

KINDS (choose the most specific)
- rect / rounded: ordinary boxes (rounded if corners are visibly curved).
- container: a box that visually groups other elements (group frames, swimlanes,
  sections, dashed trust boundaries around boxes). Its label is its title.
- text: text with no box of its own.
- pill: fully rounded bar (communication buses/backbones). band: long thin bar
  (gateways, proxies, load balancers, title bars, separator rules).
- ellipse, hexagon, cylinder (databases drawn as shapes with text).
- server_stack: stacked rack-server glyph; set status_color for its LED.
- app_icon: small application-window glyph; db_icon: small database glyph;
  pipe: double-walled pipe glyph.
- raster: anything that cannot be drawn with shapes – clip-art, photos, logos,
  product marks, mouse cursors, people. Give its tight bounding box; its pixels are
  copied from the source.
- line: free-standing line that is not a connector (zone boundaries, rules).

STYLE
- Colours as #RRGGBB measured from the image (use the provided palette / samples).
  "none" for no fill or no border. Dashed borders → dashed=true.
- font_size in source pixels ≈ cap-height × 1.4. bold/italic/underline as seen.
- text_dir: vertical_up = rotated 90° counter-clockwise (reads bottom→top),
  vertical_down = rotated 90° clockwise (reads top→bottom).
- Text alignment/valign as seen (container titles are usually valign=top).

SEMANTICS
- Legends: if the diagram has a legend, map each colour/border/line style to its
  meaning and set legend_category on the elements/edges that use it.
"""


def _state(ctx):
    return ctx.state


def _plan_text(state) -> str:
    plan = state.get("layout_plan")
    if not plan:
        return "(no plan)"
    if isinstance(plan, str):
        return plan[:6000]
    return json.dumps(plan, indent=0)[:9000]


def _cv_summary(ws, region=None, max_lines=250, max_boxes=250) -> str:
    cv = ws.read_json("cv.json", {})
    def inside(o):
        if not region:
            return True
        x0, y0, x1, y1 = region
        return x0 - 2 <= o["x"] <= x1 + 2 and y0 - 2 <= o["y"] <= y1 + 2
    lines = [l for l in cv.get("ocr_lines", []) if inside(l)][:max_lines]
    boxes = [b for b in cv.get("boxes", []) if inside(b)][:max_boxes]
    segs = [s for s in cv.get("lines", []) if not region or inside({"x": s["x1"], "y": s["y1"]})][:150]
    out = ["OCR TEXT LINES (x,y,w,h: text) – OCR can misread; trust the image for spelling:"]
    out += [f"  {l['x']:.0f},{l['y']:.0f},{l['w']:.0f},{l['h']:.0f}: {l['text']}" for l in lines]
    out.append("DETECTED RECTANGLES (x,y,w,h fill stroke) – measured, precise; reuse these numbers:")
    out += [f"  {b['x']:.0f},{b['y']:.0f},{b['w']:.0f},{b['h']:.0f} {b['fill']} {b['stroke']}" for b in boxes]
    out.append("DETECTED LINE SEGMENTS (x1,y1→x2,y2 orientation dashed?):")
    out += [f"  {s['x1']},{s['y1']}→{s['x2']},{s['y2']} {s['orientation']}{' dashed?' if s['dashed_hint'] else ''}"
            for s in segs]
    return "\n".join(out)


# ------------------------------------------------------------------------ planner
def planner_instruction(ctx) -> str:
    st = _state(ctx)
    ws = ws_from_state(st)
    meta = st.get("image_meta", {})
    return f"""ROLE: LAYOUT_PLANNER
{CORE_RULES}
TASK
You receive the whole source image with a coordinate grid. Produce a LayoutPlan that
the element extractors (who only see one zoomed tile each) will rely on:
- diagram_type and title; canvas_background; is_photo (photographed slide/paper?).
- regions: every major area with role (container/zone/legend/title/band/raster/boundary)
  and precise bounds. Include network zones, swimlanes, grouping frames, legend area.
- palette: each distinct colour and what it means (legend-driven where possible).
- templates: repeated visual element types (e.g. "app box 92x57 rounded grey border with
  app_icon top-left and value text bottom-right") so tiles stay consistent.
- raster_regions: every clip-art/logo/photo/icon that must be copied as pixels.
- connector_styles: every distinct line style (colour, width, dash, start/end markers)
  and its meaning.
- recommended_scale: 1.0 unless the image is small (<900 px wide) – then ~1200/width.
- expected_element_count / expected_connector_count: honest counts, used later to
  detect omissions.
- extraction_notes: anything tile extractors must know (fonts, rotated text, legend).

IMAGE METADATA: {json.dumps(meta)}
MEASUREMENTS (whole image):
{_cv_summary(ws, max_lines=400, max_boxes=400)}
"""


# ------------------------------------------------------------------------ tile extractor
def tile_instruction(ctx) -> str:
    st = _state(ctx)
    ws = ws_from_state(st)
    tile = st.get("current_tile", {})
    box = tile.get("box", [0, 0, 0, 0])
    missing = st.get("current_tile_missing_text") or []
    prior = st.get("current_tile_prior") or ""
    gap = ""
    if missing:
        gap = ("\nGAP-FILL PASS: a previous pass on this tile produced the elements listed under "
               "PREVIOUS ELEMENTS but these source texts are still not covered by any element:\n  "
               + "\n  ".join(missing[:120]) +
               "\nReturn ONLY the additional elements needed (boxes and/or text) – do not repeat "
               "previous elements.\nPREVIOUS ELEMENTS:\n" + prior[:12000])
    return f"""ROLE: TILE_EXTRACTOR
{CORE_RULES}
TASK
You see ONE tile of the source image: source region x0={box[0]:.0f}, y0={box[1]:.0f},
x1={box[2]:.0f}, y1={box[3]:.0f} (zoom {tile.get('zoom')}; grid step {tile.get('grid_step')} px).
List EVERY element whose visible part lies in this tile, in SOURCE coordinates.
- An element cut by the tile edge: give its visible extent and set clipped_by_tile=true
  (the merger stitches halves from neighbouring tiles).
- Elements that continue outside the tile but are containers: still give your best
  estimate of their full bounds using the LAYOUT PLAN regions.
- local_id must be unique within this tile; parent_local_id refers to a container you
  also output in this tile (or "" if the parent is outside the tile).
- Output tile_id="{tile.get('id')}".
Do NOT output connectors/arrows here (a later step does that), except free-standing
kind=line boundaries.

LAYOUT PLAN (from the whole-image pass):
{_plan_text(st)}

MEASUREMENTS INSIDE THIS TILE:
{_cv_summary(ws, region=box)}
{gap}
"""


# ------------------------------------------------------------------------ connectors
def connector_instruction(ctx) -> str:
    st = _state(ctx)
    ws = ws_from_state(st)
    nodes = ws.read_json("nodes.json", [])
    listing = "\n".join(
        f"  {n['id']} [{n['kind']}] ({n['x']:.0f},{n['y']:.0f},{n['w']:.0f},{n['h']:.0f}) {json.dumps(n.get('label',''))[:60]}"
        for n in nodes)
    return f"""ROLE: CONNECTOR_EXTRACTOR
{CORE_RULES}
TASK
Extract EVERY connector (line or arrow joining things) in the diagram. You get the whole
image with a grid, then zoomed gridded tiles, and the full list of nodes already
extracted (with ids and source-pixel bounds).
For each connector:
- source_id / target_id: ids from NODE LIST (use the innermost box the line touches).
  Direction = arrowhead end is the target. For undirected lines keep the visual order
  and set end_arrow="none". Use "" only if an end touches nothing.
- source_point / target_point: the exact pixel where the line leaves/touches the box
  (on its border; for arrows, the arrowhead tip).
- waypoints: every bend, in order. Straight diagonal lines have no waypoints.
- Markers: dot/circle at an end → "oval"; filled triangle → "block"; open V → "open".
- Lines that merge into a shared trunk (bus style) are separate connectors that share
  waypoints – emit one connector per source→target pair you can see.
- color/width/dashed measured; legend_category from the legend (e.g. "API", "Batch").
Count check: the planner expected about {(_state(ctx).get('layout_plan') or {}).get('expected_connector_count', '?') if isinstance(_state(ctx).get('layout_plan'), dict) else '?'} connectors.

LAYOUT PLAN:
{_plan_text(st)}

NODE LIST:
{listing}

LINE SEGMENT MEASUREMENTS:
{_cv_summary(ws, max_lines=0, max_boxes=0)}
"""


# ------------------------------------------------------------------------ critic
def critic_instruction(ctx) -> str:
    st = _state(ctx)
    ws = ws_from_state(st)
    rep = ws.read_json("report.json", {})
    m = rep.get("metrics", {})
    aud = rep.get("audit", {})
    val = rep.get("validation", {})
    missing = ", ".join(f"{t['token']}@({t['x']:.0f},{t['y']:.0f})" for t in aud.get("text", {}).get("missing", [])[:80])
    return f"""ROLE: CRITIC
{CORE_RULES}
TASK
Compare the SOURCE image with the REPLICA render (rendered by the real draw.io at the same
scale) and list concrete defects. Images provided, in order: source (gridded), replica
(gridded), diff heat-map (red = present in source but missing in replica, green = extra
in replica), then source/replica crop pairs of the worst regions (source on top).
Be exhaustive and precise: each issue gets a tight region in source pixels, the ids of
the elements involved (from the SPEC DIGEST), what is wrong, and the exact fix
(numbers, colours, text). Check: missing/extra elements, wrong text, geometry off by
>3 px, wrong colours/borders/dashes/fonts, wrong hierarchy, missing/misrouted
connectors and arrowheads, raster crops that are mis-framed.
verdict = PASS only if a careful human could not spot a meaningful difference.

METRICS: {json.dumps(m)}
VALIDATION ERRORS: {val.get('errors', [])}
VALIDATION WARNINGS: {val.get('warnings', [])[:40]}
SOURCE TEXT NOT FOUND IN ANY LABEL: {missing or 'none'}
UNMATCHED DETECTED BOXES (maybe missing elements): {json.dumps(aud.get('unmatched_cv_boxes', [])[:30])}
UNMATCHED DETECTED LINES (maybe missing connectors/borders): {json.dumps(aud.get('unmatched_cv_lines', [])[:30])}

SPEC DIGEST:
{_digest(ws)}
"""


def _digest(ws, region=None):
    from .pipeline_ops import load_spec, spec_digest
    try:
        return spec_digest(load_spec(ws), region)
    except Exception as e:  # pragma: no cover
        return f"(spec unavailable: {e})"


# ------------------------------------------------------------------------ fixer
def fixer_instruction(ctx) -> str:
    st = _state(ctx)
    crit = st.get("critique") or {}
    if isinstance(crit, str):
        crit_txt = crit
    else:
        crit_txt = json.dumps(crit, indent=0)[:20000]
    ws = ws_from_state(st)
    return f"""ROLE: FIXER
{CORE_RULES}
TASK
Resolve EVERY issue in the CRITIQUE by editing the spec with tools. Work issue by issue:
1. If you need exact numbers, call measure_region(x0,y0,x1,y1) (OCR text + detected
   rectangles + line segments inside the region) and/or sample_colors.
2. Call apply_spec_patch with a JSON list of operations. Batch many operations per call.
   Operations:
     {{"op":"add_node","node":{{"id":..,"kind":..,"x":..,"y":..,"w":..,"h":..,"label":..,"parent":..,
        "style":{{"fill":..,"stroke":..,"stroke_width":..,"dashed":..,"rounded":..,"font_size":..,
                  "font_color":..,"bold":..,"align":..,"valign":..,"text_dir":..}},
        "status_color":..,"crop":[x0,y0,x1,y1],"meta":{{"knockout":"auto"}}}}}}
     {{"op":"update_node","id":..,"set":{{"x":..,"label":..,"parent":..,"style":{{"fill":..}}}}}}
     {{"op":"delete_node","id":..}}            (also deletes its edges; children re-parented)
     {{"op":"add_edge","edge":{{"id":..,"source":..,"target":..,"source_point":[x,y],
        "target_point":[x,y],"waypoints":[[x,y]],"label":..,"style":{{"color":..,"width":..,
        "dashed":..,"start_arrow":..,"end_arrow":..}}}}}}
     {{"op":"update_edge","id":..,"set":{{...same fields...}}}}
     {{"op":"delete_edge","id":..}}
     {{"op":"set_canvas","set":{{"scale":..,"background":..}}}}
3. Call rebuild_and_score once at the end and report the new metrics in one short line.
Never delete correct content to game metrics. Keep ids stable.

CRITIQUE:
{crit_txt}

SPEC DIGEST:
{_digest(ws)}
"""
