"""LLM-facing structured output schemas.

Kept flat and free of open-ended dicts so they translate cleanly to Gemini
response schemas. Every coordinate is in SOURCE IMAGE PIXELS.
"""
from __future__ import annotations

from typing import Literal, Optional
from pydantic import BaseModel, Field

ElementKind = Literal["rect", "rounded", "container", "text", "ellipse", "hexagon", "cylinder", "pill", "band",
                      "server_stack", "app_icon", "db_icon", "pipe", "raster", "line"]


class Box(BaseModel):
    x0: float
    y0: float
    x1: float
    y1: float
    label: str = ""


class Region(BaseModel):
    name: str
    role: Literal["container", "zone", "legend", "title", "band", "raster", "boundary", "other"]
    x0: float
    y0: float
    x1: float
    y1: float
    notes: str = ""


class PaletteEntry(BaseModel):
    color: str
    meaning: str


class Template(BaseModel):
    name: str
    description: str
    kind: ElementKind
    typical_w: float
    typical_h: float
    style_notes: str = ""


class LayoutPlan(BaseModel):
    diagram_type: str
    title: str = ""
    canvas_background: str = "#FFFFFF"
    is_photo: bool = False
    recommended_scale: float = 1.0
    regions: list[Region] = Field(default_factory=list)
    palette: list[PaletteEntry] = Field(default_factory=list)
    templates: list[Template] = Field(default_factory=list)
    raster_regions: list[Box] = Field(default_factory=list)
    connector_styles: list[str] = Field(default_factory=list)
    font_notes: str = ""
    extraction_notes: str = ""
    expected_element_count: int = 0
    expected_connector_count: int = 0


class ExtractedElement(BaseModel):
    local_id: str
    kind: ElementKind
    label: str = ""                       # exact text, "\n" between visual lines
    x: float
    y: float
    w: float
    h: float
    parent_local_id: str = ""
    fill: str = "#FFFFFF"                 # hex or "none"
    stroke: str = "#000000"
    stroke_width: float = 1.0
    dashed: bool = False
    rounded: bool = False
    corner_radius: float = 0              # px, when rounded
    font_size: float = 12
    font_color: str = "#000000"
    bold: bool = False
    italic: bool = False
    underline: bool = False
    align: Literal["left", "center", "right"] = "center"
    valign: Optional[Literal["top", "middle", "bottom"]] = None   # None → top for containers, else middle
    text_dir: Literal["horizontal", "vertical_up", "vertical_down"] = "horizontal"
    status_color: str = ""                # server_stack LED
    legend_category: str = ""
    clipped_by_tile: bool = False
    confidence: float = 0.8


class TileExtraction(BaseModel):
    tile_id: str
    elements: list[ExtractedElement] = Field(default_factory=list)
    notes: str = ""


class Point(BaseModel):
    x: float
    y: float


class ExtractedEdge(BaseModel):
    id: str
    source_id: str = ""                   # node id from the provided node list, "" if free end
    target_id: str = ""
    source_point: Point
    target_point: Point
    waypoints: list[Point] = Field(default_factory=list)
    color: str = "#000000"
    width: float = 1.0
    dashed: bool = False
    start_arrow: Literal["none", "block", "classic", "open", "oval", "diamond"] = "none"
    end_arrow: Literal["none", "block", "classic", "open", "oval", "diamond"] = "block"
    label: str = ""
    legend_category: str = ""
    confidence: float = 0.8


class ConnectorExtraction(BaseModel):
    edges: list[ExtractedEdge] = Field(default_factory=list)
    notes: str = ""


class Issue(BaseModel):
    severity: Literal["high", "medium", "low"]
    category: Literal["missing_element", "extra_element", "wrong_text", "wrong_position", "wrong_size",
                      "wrong_style", "missing_edge", "wrong_edge", "extra_edge", "wrong_hierarchy", "raster", "other"]
    x0: float
    y0: float
    x1: float
    y1: float
    element_ids: list[str] = Field(default_factory=list)
    description: str
    fix: str


class Critique(BaseModel):
    verdict: Literal["PASS", "REVISE"]
    fidelity_0_to_10: float
    issues: list[Issue] = Field(default_factory=list)
    summary: str = ""
