"""Runtime configuration (env-overridable)."""
from __future__ import annotations

import os
from dataclasses import dataclass, field


def _f(name, default):
    return float(os.environ.get(name, default))


def _i(name, default):
    return int(os.environ.get(name, default))


@dataclass
class Config:
    # Models. Any ADK model string works (Gemini ids, or "litellm:<provider/model>" -> LiteLlm).
    model_planner: str = os.environ.get("DR_MODEL_PLANNER", "gemini-2.5-pro")
    model_extractor: str = os.environ.get("DR_MODEL_EXTRACTOR", "gemini-2.5-pro")
    model_connectors: str = os.environ.get("DR_MODEL_CONNECTORS", "gemini-2.5-pro")
    model_critic: str = os.environ.get("DR_MODEL_CRITIC", "gemini-2.5-pro")
    model_fixer: str = os.environ.get("DR_MODEL_FIXER", "gemini-2.5-pro")
    model_ocr: str = os.environ.get("DR_MODEL_OCR", "gemini-2.5-flash")
    # OCR backend: "auto" (tesseract if installed, else gemini) | "tesseract" | "gemini" | "none"
    ocr_backend: str = os.environ.get("DR_OCR_BACKEND", "auto")
    ocr_tile_src_px: int = _i("DR_OCR_TILE_SRC_PX", 700)     # smaller tiles → tighter boxes
    ocr_tile_target_px: int = _i("DR_OCR_TILE_TARGET_PX", 1536)
    ocr_tile_overlap: float = _f("DR_OCR_TILE_OVERLAP", 0.15)
    temperature: float = _f("DR_TEMPERATURE", 0.1)
    max_output_tokens: int = _i("DR_MAX_OUTPUT_TOKENS", 65536)

    workdir: str = os.environ.get("DR_WORKDIR", os.path.join(os.environ.get("TMPDIR", "/tmp"), "diagram_replicator_runs"))
    # tiling
    max_tile_src_px: int = _i("DR_MAX_TILE_SRC_PX", 900)       # longest tile side in source px
    tile_overlap: float = _f("DR_TILE_OVERLAP", 0.12)
    tile_target_px: int = _i("DR_TILE_TARGET_PX", 1600)       # tile width sent to the model
    extraction_passes: int = _i("DR_EXTRACTION_PASSES", 2)    # gap-filling passes per tile
    tile_text_coverage_target: float = _f("DR_TILE_TEXT_COVERAGE", 0.92)
    max_images_per_request: int = _i("DR_MAX_IMAGES", 14)
    # refinement
    max_refine_iterations: int = _i("DR_MAX_REFINE_ITERS", 6)
    pass_score: float = _f("DR_PASS_SCORE", 0.90)             # similarity score threshold
    pass_text_coverage: float = _f("DR_PASS_TEXT_COVERAGE", 0.95)
    plateau_patience: int = _i("DR_PLATEAU_PATIENCE", 2)
    min_improvement: float = _f("DR_MIN_IMPROVEMENT", 0.003)
    llm_retries: int = _i("DR_LLM_RETRIES", 2)
    extra: dict = field(default_factory=dict)


CONFIG = Config()


def make_model(name):
    """Return something LlmAgent(model=...) accepts."""
    if not isinstance(name, str):
        return name                      # already a BaseLlm instance (tests / custom)
    if name.startswith("litellm:"):
        from google.adk.models.lite_llm import LiteLlm
        return LiteLlm(model=name.split(":", 1)[1])
    return name


def resolve_ocr_backend() -> str:
    b = CONFIG.ocr_backend.lower()
    if b == "auto":
        from .drawio_kit.vision_ops import tesseract_available
        return "tesseract" if tesseract_available() else "gemini"
    if b == "tesseract":
        from .drawio_kit.vision_ops import tesseract_available
        if not tesseract_available():
            raise RuntimeError("DR_OCR_BACKEND=tesseract but tesseract is not installed; use gemini or auto")
    return b
