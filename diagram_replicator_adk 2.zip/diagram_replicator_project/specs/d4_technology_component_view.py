"""Image 4 – 'Technology / Component View' (photo of a slide; card-origination platform)."""
from ._dsl import Builder

INK = "#2E2E2E"
BAND = "#BDBAB3"
REMOVED = "#E39A9A"
DARKBLUE = "#1F4E79"
LIGHTBLUE = "#8BA6C1"
TEAL = "#2F6F8F"
MAROON = "#6B2D4A"
PURPLE = "#8E6BA8"
ZONE = "#2B3A67"
BOUNDARY = "#B22222"


def build(src):
    b = Builder("4 - Technology Component View", 2576, 1420, src)
    box = dict(fill="#FFFFFF", stroke=INK, stroke_width=1.5, font_size=20, font_color="#1A1A1A", line_height=1.2)
    rbox = dict(box, rounded=True, arc_size=10, abs_arc=True)

    def R(id, x, y, w, h, label, parent=None, **kw):
        st = dict(box); st.update(kw)
        return b.box(x, y, w, h, label, id=id, parent=parent, **st)

    def RR(id, x, y, w, h, label, parent=None, **kw):
        st = dict(rbox); st.update(kw)
        return b.box(x, y, w, h, label, id=id, parent=parent, **st)

    def C(id, x, y, w, h, label="", parent=None, **kw):
        st = dict(rbox, valign="top"); st.update(kw)
        return b.node("container", x, y, w, h, label, id=id, parent=parent, **st)

    def band(id, x, y, w, h, label, fs=20):
        return b.node("band", x, y, w, h, label, id=id, fill=BAND, stroke=INK, stroke_width=2, font_size=fs,
                      font_color="#1A1A1A", rounded=True, arc_size=3, abs_arc=True)

    # ---- title ---------------------------------------------------------------------------
    b.box(38, 0, 2510, 56, "Technology / Component View:", id="title", fill="#1F4E9A", stroke="none",
          font_color="#FFFFFF", font_size=30, bold=True, align="left", spacing_left=12)

    # ---- channels (top-left) ------------------------------------------------------------------
    R("ivr", 157, 119, 226, 40, "IVR(43461)")
    R("mobile", 78, 158, 305, 40, "Mobile(154811,168524)")
    RR("crs_fusion", 83, 207, 303, 95, "CRS Fusion\n(172221,176370\n166958, 169196)", valign="top", spacing_top=6)
    b.box(338, 264, 38, 36, "", id="crs_fusion_ui", fill="#1FA3D8", gradient="#0E3E8A", stroke="none", z=5)
    R("datavision", 390, 125, 155, 62, "Datavision", stroke=REMOVED, meta={"legend": "Removed"})
    R("telemarketer", 548, 125, 172, 65, "Telemarketer\nApps")
    R("sapient", 397, 208, 211, 52, "Sapient\n(156693)")
    b.text(398, 266, 130, 22, "Web Link API", font_size=16, font_color="#5A5A5A", align="left")
    C("vtpos", 732, 125, 276, 203)
    R("thd", 738, 135, 107, 31, "THD", parent="vtpos")
    R("bby", 851, 135, 130, 31, "BBY", parent="vtpos")
    b.text(790, 171, 160, 26, "179785", parent="vtpos", font_size=20)
    R("partners", 738, 198, 250, 29, "15 + Partners", parent="vtpos")
    R("otherpos", 738, 235, 250, 41, "Other POS", parent="vtpos")
    b.text(742, 285, 256, 30, "VT/POS Apps (CRS)", parent="vtpos", font_size=20, bold=True)

    RR("acxiom", 1036, 130, 166, 138, "ACXIOM\n(160271 )", arc_size=22)
    RR("fiserv", 1222, 128, 166, 137, "Product\nProcessor\nFiserv Optis\n(153529)", arc_size=22)
    b.node("raster", 1196, 180, 46, 70, id="cursor", meta={"knockout": "auto"}, crop=[1196, 180, 1242, 250], z=6)
    b.node("pipe", 1300, 265, 20, 117, id="pipe", stroke="#000000", stroke_width=2, z=3)

    # ---- network zones & gateways ------------------------------------------------------------
    band("akamai", 163, 337, 849, 33, "Akamai (Partner B2B Gateway)")
    band("dmg", 246, 380, 974, 28, "DMG Secure Proxy")
    band("apigee_edge", 335, 420, 683, 30, "Apigee Edge", fs=22)
    band("ssg1", 1388, 376, 178, 32, "SSG")
    band("apigee_dmz", 1776, 371, 181, 38, "Apigee")
    band("ssg2", 2144, 372, 180, 32, "SSG")
    for i, y in enumerate((371, 413)):
        b.node("line", 100, y - 1, 2340, 2, id=f"boundary{i}", stroke=BOUNDARY, stroke_width=3, dashed=True,
               dash_pattern="4 2", z=-1)
    zl = dict(font_size=21, font_color=ZONE, align="right")
    b.text(2380, 334, 100, 28, "Internet", **zl)
    b.text(2380, 378, 100, 28, "DMZ", **zl)
    b.text(2330, 432, 150, 28, "Green Zone", **zl)
    b.text(98, 381, 140, 46, "mTLS 1.2 with\nclient auth", font_size=17, font_color="#6A6A6A", align="left",
           line_height=1.15)

    # ---- external vendors / bureaus ---------------------------------------------------------------
    C("vendors", 1467, 125, 536, 155)
    RR("adeptra", 1486, 140, 138, 58, "Adeptra\n(167777)", parent="vendors", stroke=REMOVED, arc_size=4,
       meta={"legend": "Removed"})
    RR("lexis", 1642, 138, 156, 60, "Lexis Nexis\n(181486)", parent="vendors", arc_size=4)
    RR("neustar", 1818, 140, 160, 60, "Neustar\n(177271)", parent="vendors", arc_size=4)
    RR("socure", 1487, 205, 136, 52, "Socure\n(175699)", parent="vendors", arc_size=4)
    RR("innovis", 1642, 203, 121, 51, "Innovis\n(170472)", parent="vendors", arc_size=4)
    RR("actimize", 1815, 205, 157, 57, "Actimize\n(171835)", parent="vendors", arc_size=4)
    C("bureaus", 2018, 122, 448, 156)
    RR("experian", 2038, 133, 420, 60, "EXPERIAN\n(179635)", parent="bureaus", arc_size=4)
    RR("tu", 2040, 202, 173, 53, "TU\n(181099)", parent="bureaus", arc_size=4)
    RR("equifax", 2232, 200, 223, 52, "Equifax\n(179786)", parent="bureaus", arc_size=4)
    b.text(2085, 293, 275, 24, "Credit Pulls from Credit bureau", font_size=16)

    # ---- OpenShift acquisition services --------------------------------------------------------------
    C("os_acq", 610, 527, 408, 100)
    b.node("raster", 635, 518, 157, 19, id="os_logo1", meta={"knockout": "auto"}, crop=[635, 518, 792, 537], parent="os_acq", z=6)
    RR("fusion_acq", 613, 538, 189, 85, "Fusion Acquire\nServices\n(172221,176370,1669\n58, 169196)", parent="os_acq",
       font_size=16, line_height=1.1)
    RR("nextgen", 808, 548, 189, 74, "Apply and Buy\nNextGen\n(173817)", parent="os_acq", font_size=19)
    RR("ips", 1027, 523, 240, 110, "Apply and Buy (IPS)\nServices (145603) I\nWindows (.NET)", font_size=19,
       arc_size=12)
    RR("lb", 612, 656, 618, 19, "Load Balancer", font_size=15, arc_size=4)

    # ---- source systems (left) --------------------------------------------------------------------------
    C("grp_a", 55, 522, 227, 306, arc_size=18)
    RR("pegarules", 62, 543, 200, 80, "Pegarules\nDisputes\n(155527)", parent="grp_a", arc_size=4)
    RR("custhub_l", 66, 636, 198, 54, "Customer Hub\n(153308)", parent="grp_a", arc_size=4)
    RR("cims", 68, 702, 198, 50, "CIMS\n(160037)", parent="grp_a", arc_size=4)
    RR("optima", 70, 760, 197, 50, "Optima\n(161602)", parent="grp_a", arc_size=4)
    C("grp_b", 65, 846, 227, 352, arc_size=18)
    RR("als_l", 75, 858, 201, 46, "ALS – (172205)", parent="grp_b", arc_size=4, font_size=21)
    RR("fraud", 78, 916, 200, 76, "Fraud Policy\nWebsite\n(161602)", parent="grp_b", arc_size=4)
    RR("digital", 87, 1000, 194, 88, "Digital Cards\nA/C Opening\n(173210)", parent="grp_b", arc_size=4)
    RR("cbna", 86, 1098, 195, 62, "CBNA BI - ETL\n(147316)", parent="grp_b", arc_size=4)

    # ---- BRD CARDS microservices (OpenShift) -------------------------------------------------------------
    C("brd_cards", 765, 698, 508, 120, arc_size=12)
    b.node("raster", 772, 700, 156, 20, id="os_logo2", meta={"knockout": "auto"}, crop=[772, 700, 928, 720], parent="brd_cards", z=6)
    b.text(780, 722, 270, 64, "BRD CARDS\nMicroservices (171532)", parent="brd_cards", font_size=21, align="left")
    R("brd_cards_ext", 1047, 733, 203, 30, "External Services", parent="brd_cards", font_size=18)
    R("brd_cards_int", 1045, 775, 204, 30, "Internal  Services", parent="brd_cards", font_size=18)

    # ---- BRD CI (TIBCO) ---------------------------------------------------------------------------------------
    C("brd_ci", 436, 826, 837, 170, dashed=True, dash_pattern="6 4", stroke_width=2, arc_size=6)
    b.text(560, 833, 420, 30, 'html:BRD CI&nbsp;&nbsp;<font style="font-size:12px">TIBCO</font> (168108)',
           parent="brd_ci", font_size=21)
    RR("med_bw", 448, 860, 189, 30, "Mediation- BW", parent="brd_ci", font_size=16, arc_size=3)
    RR("ci_bw", 650, 864, 113, 29, "CI -BW", parent="brd_ci", font_size=16, arc_size=3)
    RR("cde_bw", 779, 864, 136, 29, "CDE -BW", parent="brd_ci", font_size=16, arc_size=3)
    for i, (y, t) in enumerate([(898, "Rule Flow Control, Cache, Execution, CDE BW"),
                                 (926, "Risk scoring, Fraud checks fulfillment  CI-BW"),
                                 (958, "Routing, Protocol Trans, Auth Mediation - BW")]):
        RR(f"brd_ci_row{i}", 449, y, 467, 26, t, parent="brd_ci", font_size=15, arc_size=3)
    RR("ems1", 972, 870, 64, 115, "E\nM\nS", parent="brd_ci", font_size=20, line_height=1.35, arc_size=4)
    RR("brd_ci_ext", 1041, 872, 208, 38, "External Services", parent="brd_ci", font_size=19, arc_size=3)
    RR("brd_ci_int", 1045, 940, 206, 37, "Internal    Services", parent="brd_ci", font_size=19, arc_size=3)

    # ---- CRS CI (TIBCO) – flagged deviation (red dashed) ------------------------------------------------------
    C("crs_ci", 440, 1007, 830, 128, stroke="#C0392B", dashed=True, dash_pattern="6 3", stroke_width=3, arc_size=4,
      meta={"legend": "Deviations"})
    b.text(560, 1004, 420, 24, 'html:CRS CI&nbsp;&nbsp;<font style="font-size:12px">TIBCO</font> (167835)',
           parent="crs_ci", font_size=21)
    RR("appval", 449, 1028, 467, 32, "Application Validation / Creation- CI BW", parent="crs_ci", font_size=16, arc_size=3)
    RR("ci_bpm", 449, 1067, 141, 27, "CI BPM BW", parent="crs_ci", font_size=16, arc_size=3)
    RR("ci_ui", 661, 1063, 255, 27, "CI UI Case Management", parent="crs_ci", font_size=16, arc_size=3)
    RR("rfc_input", 452, 1100, 465, 30, "Rule Flow Control  Input, Cache, Execution, CDE BW", parent="crs_ci",
       font_size=15, arc_size=3)
    RR("ems2", 972, 1027, 64, 96, "E\nM\nS", parent="crs_ci", font_size=20, line_height=1.2, arc_size=4)
    RR("crs_ci_ext", 1046, 1030, 204, 36, "External Services", parent="crs_ci", font_size=19, arc_size=3)
    RR("crs_ci_int", 1048, 1086, 201, 36, "Internal  Services", parent="crs_ci", font_size=19, arc_size=3)

    RR("ci_db", 384, 1149, 235, 48, "CI database", align="left", spacing_left=18, font_size=21, arc_size=4)
    b.node("db_icon", 540, 1155, 37, 37, id="ci_db_icon", z=5)

    # ---- Citi internal -------------------------------------------------------------------------------------------
    C("citi", 1576, 545, 889, 440, arc_size=22)
    b.text(1870, 712, 170, 30, "Citi Internal", parent="citi", font_size=21, bold=True)
    items = [
        ("cards_esb", 1589, 564, 230, 56, "Cards ESB\n(162445)", 16), ("cru", 1831, 565, 231, 57, "CRU / Magnum\n(152101)", 4),
        ("rat", 2071, 566, 222, 56, "Risk Attributes\nTool (171068)", 4), ("custhub_r", 2299, 566, 150, 124, "Customer\nHub\n(153308)", 14),
        ("citi_screen", 1588, 636, 228, 50, "Citi screening\n(155094)", 4),
        ("alerts", 1831, 635, 311, 55, "Citi Alerts &\nNotifications\n(179254)", 4),
        ("g360", 2158, 632, 132, 58, "G360\n(43451)", 4), ("rscc", 1586, 695, 229, 55, "RSCC letters\n(43514)", 10),
        ("ibs_ar", 2158, 698, 284, 59, "IBS - Accounts\nReceivable(43448)", 4),
        ("risk_credit", 1585, 763, 228, 54, "Citi Risk Credit\n(161534)", 4),
        ("ibs_host", 1830, 763, 264, 55, "IBS - Host Interface\n(43458)", 4),
        ("als_rlpp", 2106, 763, 333, 59, "ALS – Retail Lending\nProduct Processor(172205)", 4),
        ("suspect", 1585, 830, 225, 54, 'html:Suspect/<font style="font-size:15px">QACT DB</font><br>(171710)', 14),
        ("cb_credit", 1829, 832, 263, 54, "CB Credit Check,\nACAPS (41681)", 4),
        ("crs_acm", 2106, 832, 335, 55, "CRS A/C Management\n(172033)", 4),
        ("datahub", 1586, 903, 224, 57, "Data HUB\n(169912)", 14),
        ("it_svc", 1829, 900, 261, 55, "IT Services\nCenter162745", 4),
        ("gcb_ml", 2106, 897, 332, 56, "CRS GCB ML Applications\n(174048)", 4),
    ]
    for iid, x, y, w, h, lbl, arc in items:
        tight = lbl.count("\n") >= 2 and h < 70
        RR(iid, x, y, w, h, lbl, parent="citi", arc_size=arc, font_size=18 if tight else 20,
           line_height=1.0 if tight else 1.2)

    # ---- OpenShift security / ML services ----------------------------------------------------------------------------
    C("os_sec", 1575, 998, 865, 102, stroke="#7A2A2A", dashed=True, dash_pattern="5 3", stroke_width=2, arc_size=6)
    b.node("hexagon", 1638, 1010, 50, 40, "N", id="nhex", parent="os_sec", fill="#0F2A6B", stroke="#FFFFFF",
           stroke_width=2, font_color="#FFFFFF", font_size=26, bold=False)
    R("psg", 1742, 1008, 328, 50,
      'html:Platform Security Gateway<br><font style="font-size:11px">(ClientID / CN validation, access policy for Auth)</font>',
      parent="os_sec", font_size=18)
    R("micro", 2145, 1010, 260, 47, 'html:Micro Service<br><font style="font-size:12px">(Python ML Model)</font>',
      parent="os_sec", font_size=18)
    cap = dict(font_size=12, font_color="#1A1A1A", parent="os_sec")
    b.text(1625, 1078, 140, 18, "Calls Vanity URLs", **cap)
    b.text(1820, 1076, 270, 18, "Generate offer requests/Adverse Letters", **cap)
    b.text(2105, 1076, 170, 18, "Customer account setup", **cap)
    b.node("raster", 2290, 1068, 158, 22, id="os_logo3", meta={"knockout": "auto"}, crop=[2290, 1068, 2448, 1090], parent="os_sec", z=6)

    C("cde", 1565, 1128, 348, 94, "CDE  (167848)", align="left", spacing_left=45, spacing_top=6, font_size=21,
      arc_size=8)
    R("fico", 1575, 1166, 310, 44, "FICO Blaze Rules (CDE)", parent="cde", font_size=21)
    RR("custhub_db", 2010, 1103, 305, 65, "Customer Hub DB", font_size=20, arc_size=6, spacing_right=60)
    b.node("db_icon", 2255, 1125, 48, 36, id="custhub_db_icon", z=5)
    RR("datahub_db", 2007, 1172, 305, 66, "Data Hub DB", font_size=20, arc_size=6, spacing_right=60, valign="bottom",
       spacing_bottom=6)
    b.node("db_icon", 2255, 1186, 48, 36, id="datahub_db_icon", z=5)

    # ---- legend ------------------------------------------------------------------------------------------------------
    b.box(88, 1242, 2420, 10, "", id="legend_rule", fill="#C4C4C4", stroke="none")
    b.node("raster", 112, 1316, 100, 22, id="lg_nopic", meta={"knockout": "auto"}, crop=[112, 1316, 212, 1338])
    b.node("pipe", 277, 1280, 22, 92, id="lg_pipe", stroke="#000000", stroke_width=2)
    b.text(304, 1322, 120, 26, "Direct Pipe", font_size=19, align="left")
    b.edge(sp=(455, 1288), tp=(588, 1288), id="lg_logical", color="#1F5A99", width=3, arrow_size=8)
    b.edge(sp=(455, 1318), tp=(584, 1318), id="lg_batch", color="#000000", width=2, arrow_size=7)
    b.edge(sp=(455, 1346), tp=(588, 1346), id="lg_api", color="#000000", width=2, start_arrow="oval", arrow_size=7)
    for y, t in [(1275, "Logical Flow"), (1302, "Batch"), (1329, "API"), (1356, "Event or Message")]:
        b.text(612, y, 190, 26, t, font_size=19, align="left")
    lg = dict(fill="#FFFFFF", font_size=19, rounded=True, arc_size=6, abs_arc=True, stroke_width=3)
    b.box(843, 1293, 182, 37, "Removed", id="lg_removed", stroke="#D0342C", **lg)
    b.box(843, 1342, 178, 36, "New CSI*", id="lg_new", stroke="#2E9E3E", **lg)
    b.box(1040, 1290, 180, 38, "Changed", id="lg_changed", stroke="#F0A030", **lg)
    b.box(1042, 1341, 180, 37, "Configured", id="lg_configured", stroke="#2A8CC8", **lg)
    b.box(1248, 1271, 190, 29, "Security Infra", id="lg_secinfra", fill="#A6A6A6", stroke=INK, stroke_width=2,
          font_size=18)
    b.box(1250, 1310, 185, 28, "Trust Boundary", id="lg_trust", fill="#FFFFFF", stroke="#000000", stroke_width=2,
          dashed=True, dash_pattern="4 3", font_size=18)
    b.box(1248, 1350, 189, 27, "Systems & Services", id="lg_systems", fill="#FFFFFF", stroke=INK, font_size=18)
    b.box(1466, 1268, 242, 112, "Deviations\nProhibited Solution\nRestricted Solution\nVulnerable Solution",
          id="lg_dev", fill="#FFFFFF", stroke="#C0392B", dashed=True, dash_pattern="5 3", stroke_width=3,
          font_size=17, line_height=1.25)
    b.box(1781, 1287, 85, 65, "", id="lg_ui", fill="#2B9ED8", gradient="#1C74B8", stroke="none")
    b.box(1781, 1287, 85, 13, "", id="lg_ui_bar", fill="#123E86", stroke="none", z=2)
    b.text(1752, 1356, 145, 26, "User Interface", font_size=19)
    b.box(1940, 1296, 194, 62, "Committed/Sell\n(CSI)", id="lg_csi", fill="#FFFFFF", stroke="#7B4A8E",
          stroke_width=2.5, font_size=19)
    b.text(2440, 1304, 24, 24, "1", font_size=16)

    # ---- connectors ------------------------------------------------------------------------------------------------------
    api = dict(color="#111111", width=2, start_arrow="oval", arrow_size=7)
    b.edge("crs_fusion", "akamai", (299, 302), (299, 369), **api)
    b.edge("sapient", "apigee_edge", (505, 260), (508, 421), color="#111111", width=2, arrow_size=7)
    b.edge("telemarketer", "dmg", (634, 189), (640, 407), **api)
    b.edge("vtpos", "apigee_edge", (871, 328), (871, 421), **api)
    b.edge("dmg", "acxiom", (1117, 380), (1117, 269), color=LIGHTBLUE, width=2, arrow_size=7)
    b.edge("dmg", "ips", (1147, 408), (1147, 523), color=DARKBLUE, width=2, arrow_size=8)
    b.edge("apigee_edge", "os_acq", (680, 450), (815, 527), pts=[(680, 487), (815, 487)], color=LIGHTBLUE, width=2,
           start_arrow="oval", arrow_size=7)
    b.edge("apigee_edge", "ips", (680, 450), (1147, 523), pts=[(680, 487), (1147, 487)], color=LIGHTBLUE, width=2,
           start_arrow="oval", arrow_size=7)
    pipe_flow = dict(color=DARKBLUE, width=2, start_arrow="oval", arrow_size=8)
    b.edge("ips", "pipe", (1267, 578), (1310, 382), pts=[(1308, 578)], **pipe_flow)
    b.edge("crs_ci_ext", "pipe", (1250, 1048), (1310, 382), pts=[(1308, 1048)], **pipe_flow)
    b.edge("nextgen", "lb", (903, 622), (903, 656), color="#555555", width=1.5, end_arrow="none")
    lbf = dict(color=TEAL, width=2, start_arrow="oval", arrow_size=8)
    b.edge("lb", "brd_ci", (612, 666), (436, 911), pts=[(383, 666), (383, 911)], **lbf)
    b.edge("lb", "crs_ci", (612, 666), (440, 1075), pts=[(383, 666), (383, 1075)], **lbf)
    ev = dict(color=MAROON, width=2, start_arrow="oval", arrow_size=8)
    b.edge("custhub_l", "brd_cards", (264, 677), (765, 760), pts=[(360, 677), (360, 760)], **ev)
    b.edge("als_l", "brd_cards", (276, 881), (765, 760), pts=[(362, 881), (362, 760)], **ev)
    b.edge("fraud", "brd_cards", (278, 953), (765, 760), pts=[(365, 953), (365, 760)], **ev)
    b.edge("digital", "crs_ci", (281, 1044), (440, 1075), pts=[(300, 1044), (300, 1075)], **ev)
    ext = dict(color=DARKBLUE, width=2, start_arrow="oval", arrow_size=8)
    b.edge("brd_cards_ext", "ssg1", (1250, 748), (1476, 409), pts=[(1476, 748)], **ext)
    b.edge("brd_ci_ext", "ssg1", (1249, 891), (1476, 409), pts=[(1476, 891)], **ext)
    b.edge(None, "apigee_dmz", (1476, 463), (1866, 409), pts=[(1866, 463)], id="e_to_apigee_dmz", color=DARKBLUE,
           width=2, end_arrow="none")
    out = dict(color="#111111", width=2, start_arrow="oval", arrow_size=8)
    b.edge("ssg1", "vendors", (1476, 376), (1729, 280), pts=[(1476, 327), (1729, 327)], **out)
    b.edge("apigee_dmz", "vendors", (1866, 371), (1729, 280), pts=[(1866, 327), (1729, 327)], **out)
    b.edge("ssg2", "bureaus", (2236, 372), (2236, 278), **out)
    b.edge("citi", "ssg2", (2025, 545), (2233, 404), pts=[(2025, 478), (2233, 478)], **ext)
    pur = dict(color=PURPLE, width=2, start_arrow="oval", arrow_size=8)
    b.edge("brd_cards_int", "citi", (1249, 790), (1576, 766), pts=[(1500, 790), (1500, 766)], **pur)
    b.edge("brd_ci_int", "citi", (1251, 959), (1576, 766), pts=[(1500, 959), (1500, 766)], **pur)
    b.edge("crs_ci_int", "citi", (1249, 1104), (1576, 766), pts=[(1500, 1104), (1500, 766)], **pur)
    b.edge("crs_ci_int", "nhex", (1249, 1104), (1638, 1030), pts=[(1500, 1104), (1500, 1030)], **pur)
    b.edge("crs_ci", "fico", (686, 1135), (1575, 1188), pts=[(686, 1188)], color="#111111", width=2, arrow_size=8)
    dbl = dict(color="#111111", width=1.5, start_arrow="open", end_arrow="open", arrow_size=8)
    b.edge("nhex", "psg", (1688, 1030), (1742, 1030), **dbl)
    b.edge("psg", "micro", (2070, 1033), (2145, 1033), **dbl)
    return b.spec
