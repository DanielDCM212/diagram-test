"""Image 1 – 'Manage Customer Service' capability → application → server impact map."""
from ._dsl import Builder

BLUE_LINE = "#6EB6FF"
PALE = "#ECF7FD"
EDGE_BLUE = "#1F4E8C"
EDGE_GRAY = "#7A7A7A"
TXT = "#333333"
SUB = "#5B7390"


def build(src):
    b = Builder("1 - Manage Customer Service", 1246, 732, src)
    b.box(1, 1, 1244, 730, "", id="frame", fill="#FFFFFF", stroke="#D0D0D0")

    # ---- capability containers --------------------------------------------------------
    cap = dict(fill=PALE, stroke=BLUE_LINE, font_color="#1F3E6E", font_size=12, rounded=True, arc_size=5)
    b.node("container", 62, 37, 1011, 169, "Manage Customer Service", id="mcs", fill="#FFFFFF", stroke=BLUE_LINE,
           rounded=True, arc_size=3, font_color=TXT, font_size=12, valign="top", spacing_top=2)
    b.text(1030, 190, 40, 14, "[94.65]", parent="mcs", font_size=9, font_color=TXT, align="right")
    b.node("container", 81, 66, 534, 112, "Plan and manage customer service contacts", id="plan", parent="mcs",
           valign="top", **cap)
    b.text(572, 161, 40, 14, "[97.12]", parent="plan", font_size=9, font_color=TXT, align="right")
    b.node("container", 100, 94, 112, 65, "Manage customer\nservice\nrequests/inquiries", id="req", parent="plan",
           valign="top", spacing_top=2, **cap)
    b.text(170, 143, 40, 14, "[99.12]", parent="req", font_size=9, font_color=TXT, align="right")
    b.node("container", 456, 94, 112, 65, "Manage customer\ncomplaints", id="cmp", parent="plan", valign="top",
           spacing_top=2, **cap)
    b.text(526, 143, 40, 14, "[99.99]", parent="cmp", font_size=9, font_color=TXT, align="right")
    b.node("container", 653, 66, 112, 112, "Evaluate customer\nservice operations\nand customer\nsatisfaction",
           id="eval", parent="mcs", valign="top", spacing_top=4, line_height=1.6, **cap)
    b.text(722, 161, 40, 14, "[99.46]", parent="eval", font_size=9, font_color=TXT, align="right")
    b.node("container", 916, 66, 112, 112, "Develop customer\ncare/customer\nservice strategy", id="dev",
           parent="mcs", valign="top", spacing_top=4, line_height=1.6, **cap)
    b.text(985, 161, 40, 14, "[97.99]", parent="dev", font_size=9, font_color=TXT, align="right")

    # ---- applications -------------------------------------------------------------------
    apps = [("ivr", 43, "IVR", "[99.6]"), ("web", 147, "Website", "[99.96]"), ("a689", 250, "Application 689", "[98.43]"),
            ("a87", 354, "Application 87", "[99.6]"), ("a979", 456, "Application 979", "[99.96]"),
            ("aucs", 557, "AU-Customer\nService", "[99.99]"), ("crm", 662, "CRM", "[99.93]"),
            ("a1014", 765, "Application\n1014", "[99.6]"), ("a104", 868, "Application 104", "[98.43]"),
            ("a963", 972, "Application 963", "[99.96]"), ("a388", 1075, "Application 388", "[99.6]")]
    for aid, x, name, val in apps:
        w = 95 if aid == "aucs" else 92
        b.node("container", x, 299, w, 57, name, id=aid, fill="#FFFFFF", stroke="#C8C8C8", rounded=True,
               arc_size=8, font_size=12, font_color=TXT, spacing_top=8, line_height=1.5)
        b.text(x + w - 42, 339, 40, 14, val, parent=aid, font_size=9, font_color=TXT, align="right")
        if aid == "aucs":
            b.node("raster", 561, 303, 20, 20, id="aucs_icon", parent=aid, crop=[561, 303, 581, 323], z=5)
        else:
            b.node("app_icon", x + 6, 307, 18, 13, id=f"{aid}_icon", parent=aid, stroke="#2A6EBB", z=5)

    # ---- servers ------------------------------------------------------------------------
    servers = [
        ("au_h01", 52, 403, "AU-H01\n[99.6]", "#FF9801", "#FFF6DA",
         "Hewlett-Packard\nCompany\n9000/800 N-Class\nServer N4000\nRed Hat\nEnterprise Linux\n5.x"),
        ("uk_cws", 258, 403, "UK-\nCWSVR052\n[98.43]", "#33EE11", "#FFE8EA", "IBM RS/6000"),
        ("us_ssv", 464, 403, "US-SSVR030\n[99.96]", "#FF9801", "#E6F8E6", "IBM System p p5\n590 / p5"),
        ("au_h02", 670, 403, "AU-H02\n[99.933]", "#FF9801", "#FFF6DA",
         "Hewlett-Packard\nCompany\nProLiant ML370\nG5 Server\n416619-xx1\nMicrosoft\nWindows Server\n2008 R2"),
        ("fr_d031", 877, 403, "FR-DSVR031\n[98.43]", "#FF9801", "#FFF6DA", "IBM RS/6000"),
        ("kr_s005", 1083, 403, "KR-SSVR005\n[99.6]", "#FF9801", "#FFF6DA",
         "Hewlett-Packard\nCompany\n9000/800 N-Class\nServer N4000"),
        ("au_dc03", 155, 506, "AU-DC03\n[99.96]", "#1E5BFF", "#FFFFFF",
         "IBM System p p5\n590 / p5\nMicrosoft\nWindows Server\n2003"),
        ("fr_d107", 361, 506, "FR-DSVR107\n[99.6]", "#FF9801", "#FFF6DA",
         "Hewlett-Packard\nCompany\n9000/800 N-Class\nServer N4000"),
        ("us_c019", 773, 506, "US-CSVR019\n[99.6]", "#FF0000", "#FFFFFF",
         "Hewlett-Packard\nCompany\n9000/800 N-Class\nServer N4000"),
    ]
    for sid, x, y, name, led, tint, desc in servers:
        b.node("server_stack", x, y, 76, 95, id=sid, status_color=led, tint=tint, units=3)
        lines = name.count("\n") + 1
        b.text(x + 79, y + 95 - 16 * lines - 3, 80, 16 * lines, name, align="left", valign="top", font_size=11,
               font_color=TXT, spacing=0, line_height=1.35, id=f"{sid}_lbl")
        b.text(x - 12, y + 98, 100, 13 * (desc.count("\n") + 1), desc, font_size=7.5, font_color=SUB,
               valign="top", spacing=0, line_height=1.45, id=f"{sid}_desc")

    # ---- capability → application links ---------------------------------------------------
    solid = dict(color=EDGE_BLUE, width=1, arrow_size=7)
    gray = dict(color=EDGE_GRAY, width=0.8, arrow_size=7)
    b.edge("req", "ivr", (142, 159), (95, 299), **solid)
    b.edge("req", "web", (162, 159), (185, 299), **solid)
    b.edge("req", "aucs", (205, 150), (557, 306), **gray)
    b.edge("plan", "a689", (334, 178), (299, 299), **solid)
    b.edge("plan", "a87", (362, 178), (389, 299), **solid)
    b.edge("plan", "a979", (390, 178), (482, 299), **solid)
    b.edge("cmp", "aucs", (530, 159), (590, 299), **gray)
    b.edge("eval", "aucs", (680, 178), (620, 299), **gray)
    b.edge("eval", "crm", (708, 178), (708, 299), **solid)
    b.edge("eval", "a1014", (737, 178), (797, 299), **solid)
    b.edge("dev", "a104", (954, 178), (921, 299), **solid)
    b.edge("dev", "a963", (985, 178), (1013, 299), **solid)
    b.edge("dev", "a388", (1016, 178), (1100, 299), **solid)

    # ---- application → server hosting links (dashed) -------------------------------------------
    dash = dict(color="#666666", width=0.8, dashed=True, dash_pattern="4 3", arrow_size=7)
    for app, srv, x, ytop in [("ivr", "au_h01", 89, 403), ("web", "au_dc03", 193, 506), ("a689", "uk_cws", 296, 403),
                              ("a87", "fr_d107", 399, 506), ("a979", "us_ssv", 502, 403), ("crm", "au_h02", 708, 403),
                              ("a1014", "us_c019", 811, 506), ("a104", "fr_d031", 915, 403),
                              ("a388", "kr_s005", 1120, 403)]:
        b.edge(app, srv, (x, 356), (x, ytop), **dash)
    b.edge("a963", "us_ssv", (985, 356), (540, 418), pts=[(955, 383), (585, 383)], **dash)
    return b.spec
