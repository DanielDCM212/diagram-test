"""Tiny builder so hand-written specs stay readable. Produces drawio_kit.DiagramSpec."""
from diagram_replicator.drawio_kit.schema import DiagramSpec, Edge, EdgeStyle, Node, Style


class Builder:
    def __init__(self, name, w, h, source_image=None, scale=1.0, background="#FFFFFF"):
        self.spec = DiagramSpec(name=name, width=w, height=h, source_image=source_image, scale=scale,
                                background=background)
        self._n = 0

    def _id(self, p):
        self._n += 1
        return f"{p}{self._n}"

    def node(self, kind, x, y, w, h, label="", id=None, parent=None, z=0, **style):
        extra = {k: style.pop(k) for k in ("units", "status_color", "tint", "crop", "tooltip", "meta") if k in style}
        n = Node(id=id or self._id(kind[:3]), kind=kind, x=x, y=y, w=w, h=h, label=label, parent=parent, z=z,
                 style=Style(**style), **extra)
        self.spec.nodes.append(n)
        return n.id

    def box(self, x, y, w, h, label="", **kw):
        return self.node("rect", x, y, w, h, label, **kw)

    def rbox(self, x, y, w, h, label="", **kw):
        return self.node("rounded", x, y, w, h, label, **kw)

    def text(self, x, y, w, h, label, **kw):
        kw.setdefault("fill", "none"); kw.setdefault("stroke", "none")
        return self.node("text", x, y, w, h, label, **kw)

    def edge(self, src=None, tgt=None, sp=None, tp=None, pts=(), label="", id=None, **style):
        e = Edge(id=id or self._id("e"), source=src, target=tgt, source_point=list(sp) if sp else None,
                 target_point=list(tp) if tp else None, waypoints=[list(p) for p in pts], label=label,
                 style=EdgeStyle(**style))
        self.spec.edges.append(e)
        return e.id
