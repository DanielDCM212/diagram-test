"""Image 3 – Regional ITS architecture (Travelers / Centers / Vehicles / Roadside).

The source is only 500×330 px, so the replica is authored in source pixels and compiled
with scale=2.4 to get a legible, editable draw.io page. Clip-art is kept as raster crops.
"""
from ._dsl import Builder

REGION = "#66E3D3"
BAR = "#35D6C0"
BAR_STROKE = "#1F6F66"
BOX = "#FFFFCC"
BOX_STROKE = "#7F8C7F"
LINE = "#333333"


def build(src):
    b = Builder("3 - ITS Architecture", 500, 330, src, scale=2.4)
    reg = dict(fill=REGION, stroke="none")
    # regions (stroke-less so overlapping rectangles read as one shape)
    b.box(13, 11, 108, 81, "", id="r_trav", **reg)
    b.box(146, 8, 347, 168, "", id="r_cent", **reg)
    b.box(11, 100, 110, 95, "", id="r_veh_a", **reg)
    b.box(11, 176, 147, 137, "", id="r_veh_b", **reg)
    b.box(183, 199, 310, 114, "", id="r_road", **reg)
    title = dict(font_size=8.5, bold=True, font_color="#1A1A1A")
    b.text(56, 15, 55, 12, "Travelers", **title)
    b.text(290, 10, 60, 12, "Centers", **title)
    b.text(112, 299, 50, 12, "Vehicles", **title)
    b.text(188, 299, 55, 12, "Roadside", **title)

    box = dict(fill=BOX, stroke=BOX_STROKE, font_size=5.6, spacing=1, line_height=1.1, z=2)

    def yb(id, x, y, w, h, label):
        return b.box(x, y, w, h, label, id=id, **box)

    # Travelers
    yb("tid", 55, 34, 62, 20, "Traveler Information\nDevices")
    yb("rk", 55, 64, 62, 20, "Regional Kiosks")
    # Centers top row
    top = [("vis", 181, 54, "Visitor Info\nServices"), ("tis", 240, 51, "Traveler Info\nServices"),
           ("kds", 296, 52, "Kiosk\nData Server"), ("ctv", 353, 50, "Cable\nTelevision"),
           ("tsp", 407, 51, "Traveler Service\nProviders")]
    for i, x, w, l in top:
        yb(i, x, 34, w, 20, l)
    grid = [["Weather\nService", "Regional\nServer", "Mayday Message\nAnswering Points", "Rail Operations\nCenters"],
            ["Fleet Dispatch/\nOperations", "Incident Command/\nDispatch Systems", "Public Safety\nAnswering Point",
             "Park Entrance Fee\nAdministration"],
            ["Transit Operations\nCenters", "Maintenance Mgmt\nSystems", "State DOT\nOperations Centers",
             "State Commercial\nVehicle Admin"]]
    cx = [152, 244, 336, 428]
    ry = [84, 114, 143]
    for r, row in enumerate(grid):
        for c, lbl in enumerate(row):
            yb(f"c{r}{c}", cx[c], ry[r], 62, 21, lbl)
    # Vehicles
    yb("vis_sys", 55, 114, 62, 20, "Vehicle Information\nSystems")
    yb("vms", 55, 143, 62, 20, "Vehicle Mayday\nSystems")
    yb("tvs", 14, 210, 57, 21, "Transit\nVehicle Systems")
    yb("mvs", 81, 210, 57, 21, "Maintenance\nVehicle Systems")
    yb("evs", 30, 240, 58, 20, "Emergency\nVehicle Systems")
    yb("cvs", 97, 240, 58, 20, "Commercial\nVehicle Systems")
    yb("ynp", 97, 269, 58, 20, "Yellowstone NP\nElectronic Tags")
    # Roadside
    road = [("npp", 188, 210, "National Park\nParking Systems"), ("wss", 188, 239, "Weigh Station\nSystems"),
            ("egs", 188, 269, "Entrance Gate\nAVI Systems"), ("cctv", 276, 210, "CCTV\nRoadCams"),
            ("iws", 276, 239, "Intersection\nWarning Systems"), ("ess", 339, 210, "Environmental\nSensor Stations"),
            ("har", 339, 239, "Highway Advisory\nRadio Systems"), ("ag", 339, 269, "Automated\nGates"),
            ("avw", 432, 210, "Animal-Vehicle\nWarning Systems"), ("dwv", 432, 240, "Dynamic\nWarning VMS"),
            ("vms2", 432, 269, "Variable Message\nSigns")]
    for i, x, y, l in road:
        yb(i, x, y, 58, 20, l)

    # Communication backbones
    bar = dict(fill=BAR, stroke=BAR_STROKE, stroke_width=0.8, font_size=5.2, bold=True, font_color="#10302C", z=3)
    b.node("pill", 127, 34, 12, 133, "Commercial Wireline/Wide Area Wireless", id="b_comm", text_dir="vertical_up", **bar)
    b.node("pill", 151, 63, 340, 12, "html:Wireline Communications <i>(B)</i>", id="b_B", **bar)
    b.node("pill", 222, 81, 12, 91, "html:Wireline Communications <i>(D)</i>", id="b_D", text_dir="vertical_up", **bar)
    b.node("pill", 313, 81, 12, 91, "html:Wireline Communications <i>(A)</i>", id="b_A", text_dir="vertical_up", **bar)
    b.node("pill", 405, 81, 12, 91, "html:Wireline Communications <i>(C)</i>", id="b_Cv", text_dir="vertical_up", **bar)
    b.node("pill", 13, 181, 226, 12, "Wide Area Wireless - Trunked/Dedicated Radio Systems", id="b_waw", **bar)
    b.node("pill", 254, 181, 230, 12, "html:Wireline Communications <i>(C)</i>", id="b_C", **bar)
    b.node("pill", 164, 206, 13, 87, "DSRC", id="b_dsrc", text_dir="vertical_up", **bar)
    b.node("pill", 254, 200, 13, 92, "html:Wireline Communications <i>(C)</i>", id="b_Cr", text_dir="vertical_up", **bar)
    b.node("pill", 404, 200, 22, 93, "Wireline/\nWide Area Wireless", id="b_ww", text_dir="vertical_up", **bar)

    # Clip-art (raster crops of the source)
    for rid, box_ in [("img_pc", (22, 2, 53, 35)), ("img_kiosk", (4, 37, 31, 62)), ("img_pda", (18, 64, 50, 94)),
                      ("img_info", (143, 0, 180, 44)), ("img_ops", (459, 0, 500, 46)), ("img_car", (7, 118, 59, 151)),
                      ("img_police", (24, 264, 78, 291)), ("img_bus", (9, 289, 55, 319)),
                      ("img_truck", (62, 289, 112, 319)), ("img_hwy", (300, 267, 336, 314)),
                      ("img_cam", (414, 296, 448, 320)), ("img_sign", (446, 290, 494, 330))]:
        x0, y0, x1, y1 = box_
        b.node("raster", x0, y0, x1 - x0, y1 - y0, id=rid, crop=list(box_), z=4)

    ln = dict(color=LINE, width=0.6, end_arrow="none")
    dot = dict(color=LINE, width=0.6, end_arrow="none", dashed=True, dash_pattern="1 2")

    def h(a, bb, x1, x2, y, **st):
        b.edge(a, bb, (x1, y), (x2, y), **(st or ln))

    def v(a, bb, x, y1, y2, **st):
        b.edge(a, bb, (x, y1), (x, y2), **(st or ln))

    # travelers / vehicle info -> commercial backbone
    for nid, y in [("tid", 44), ("rk", 74), ("vis_sys", 124), ("vms", 153)]:
        h(nid, "b_comm", 117, 127, y)
    h("b_comm", "b_B", 139, 151, 69)
    for nid, x, w in [("vis", 181, 54), ("tis", 240, 51), ("kds", 296, 52), ("ctv", 353, 50), ("tsp", 407, 51)]:
        v(nid, "b_B", x + w / 2, 54, 63)
    for c, x in enumerate([183, 275, 367, 459]):
        v("b_B", f"c0{c}", x, 75, 84)
    # grid <-> vertical backbones
    for r, y in enumerate([94.5, 124, 153.5]):
        h(f"c{r}0", "b_D", 214, 222, y); h("b_D", f"c{r}1", 234, 244, y)
        h(f"c{r}1", "b_A", 306, 313, y); h("b_A", f"c{r}2", 325, 336, y)
        h(f"c{r}2", "b_Cv", 398, 405, y); h("b_Cv", f"c{r}3", 417, 428, y)
    v("b_D", "b_waw", 228, 172, 181)
    v("b_Cv", "b_C", 411, 172, 181)
    # wide-area wireless -> vehicles
    for nid, x, y2 in [("tvs", 46, 210), ("evs", 75, 240), ("mvs", 108, 210), ("cvs", 142, 240)]:
        v("b_waw", nid, x, 193, y2)
    h("cvs", "b_dsrc", 155, 164, 252)
    h("ynp", "b_dsrc", 155, 164, 279)
    for nid, y in [("npp", 220), ("wss", 249), ("egs", 279)]:
        h("b_dsrc", nid, 177, 188, y)
        h(nid, "b_Cr", 246, 254, y)
    h("b_Cr", "cctv", 267, 276, 220)
    h("b_Cr", "iws", 267, 276, 249, **dot)
    for nid, y in [("ess", 220), ("har", 249), ("ag", 279)]:
        h(nid, "b_ww", 397, 404, y)
    h("b_ww", "avw", 426, 432, 220, **dot)
    h("b_ww", "dwv", 426, 432, 250, **dot)
    h("b_ww", "vms2", 426, 432, 279)
    v("b_C", "b_Cr", 260, 193, 200)
    v("b_C", "b_ww", 415, 193, 200)
    return b.spec
