"""Image 2 – Dragon1 'Example Enterprise Architecture Framework Diagram'."""
from ._dsl import Builder

Y, G, R, K = "#FFC000", "#00B050", "#FF0000", "#000000"
SEC = "#C6D9F1"
SUBA = "#8EB4E3"
FRAME = "#558ED5"
OWNER = "#1F2F5F"
FC = {Y: "#000000", G: "#000000", R: "#000000", K: "#FFFFFF"}


def build(src):
    b = Builder("2 - Dragon1 EA Framework", 1202, 900, src)
    b.text(10, 5, 180, 34, "dragon1.com", font_size=22, font_color="#C00000", align="left")
    b.text(290, 5, 640, 34, "Example Enterprise Architecture Framework Diagram", font_size=21)
    b.box(1149, 3, 40, 36, "D", id="logo", fill="#CC0000", stroke="#CC0000", font_color="#FFFFFF", font_size=26,
          font_family="Times New Roman")
    b.text(300, 866, 600, 28, "(c) Copyright Dragon1 – open EA Method / Visualization Standard", font_size=15)

    b.node("container", 13, 44, 1176, 814, "", id="ea", fill=FRAME, stroke=K, stroke_width=4, rounded=False)
    b.text(430, 58, 340, 38, "Enterprise Architecture", parent="ea", font_size=24)
    b.box(816, 52, 173, 50, "glossary", parent="ea", fill=Y, stroke=K, stroke_width=4, font_size=17)
    owner = dict(font_size=12, font_color=OWNER, underline=True, align="left", valign="top", spacing=0, line_height=1.2)
    b.text(1084, 50, 90, 36, "DEFINITION\nOWNER", parent="ea", **owner)

    def cell(x, y, w, h, label, col, parent, fs, vertical=False, bw=4):
        b.box(x, y, w, h, label, parent=parent, fill=col, stroke=K, stroke_width=bw, font_size=fs,
              font_color=FC[col], text_dir="vertical_up" if vertical else "horizontal", line_height=1.1)

    def section(sid, x, y, w, h, title, tx, ty, tw, fs=24, ox=None, oy=None):
        b.node("container", x, y, w, h, "", id=sid, parent="ea", fill=SEC, stroke=K, stroke_width=5, rounded=False)
        b.text(tx, ty, tw, 36, title, parent=sid, font_size=fs)
        if ox is not None:
            b.text(ox, oy, 90, 36, "DEFINITION\nOWNER", parent=sid, **owner)

    names = ["concepts &\nprinciples", "elements", "components", "objects",
             "patterns", "rules & standards", "domains", "building blocks"]

    def big_grid(parent, y0, colors):
        for i, (nm, col) in enumerate(zip(names, colors)):
            r, c = divmod(i, 4)
            cell(231 + c * 189, y0 + r * 56, 172, 48, nm, col, parent, 17)

    # Governance
    section("gov", 210, 108, 776, 177, "Governance Architecture", 400, 116, 400, ox=880, oy=118)
    big_grid("gov", 167, [Y, G, Y, G, K, Y, G, Y])
    # Technical
    section("tech", 210, 643, 776, 170, "Technical Architecture", 400, 655, 400, ox=886, oy=656)
    big_grid("tech", 696, [G, R, K, G, G, R, G, K])

    # Business (Process / Service) and Information (Data / Application)
    section("bus", 210, 287, 776, 175, "Business Architecture", 361, 297, 400, ox=879, oy=297)
    section("info", 210, 467, 776, 175, "Information Architecture", 369, 477, 400, ox=880, oy=477)

    def sub(sid, parent, x, y, w, h, title, align, colors):
        b.node("container", x, y, w, h, "", id=sid, parent=parent, fill=SUBA, stroke=K, stroke_width=4, rounded=False)
        tx = x + 12 if align == "left" else x + w - 312
        b.text(tx, y + 8, 300, 36, title, parent=sid, font_size=24, align=align)
        small = ["concepts &\nprinciples", "elements", "components", "objects",
                 "patterns", "rules &\nstandards", "domains", "building\nblocks"]
        cx0 = x + 10
        for i, (nm, col) in enumerate(zip(small, colors)):
            r, c = divmod(i, 4)
            cell(cx0 + c * 86, y + 56 + r * 27, 79, 22, nm, col, sid, 8, bw=2.5)

    sub("proc", "bus", 220, 336, 364, 117, "Process Architecture", "left", [G, R, K, Y, G, K, K, Y])
    sub("svc", "bus", 598, 336, 374, 117, "Service Architecture", "right", [R, K, G, G, Y, Y, K, R])
    sub("data", "info", 220, 515, 364, 117, "Data Architecture", "left", [R, G, G, G, K, G, G, R])
    sub("app", "info", 598, 515, 374, 117, "Application Architecture", "right", [Y, R, G, Y, K, Y, K, R])

    # Side columns (vertical)
    def side(sid, x, title, owner_x, colors, title_x):
        b.node("container", x, 108, 188, 705, "", id=sid, parent="ea", fill=SEC, stroke=K, stroke_width=5, rounded=False)
        b.text(owner_x, 118, 90, 36, "DEFINITION\nOWNER", parent=sid, **owner)
        b.text(title_x, 120, 44, 690, title, parent=sid, font_size=24, text_dir="vertical_up")
        pairs = [("objects", "building blocks"), ("components", "domains"), ("elements", "rules &\nstandards"),
                 ("concepts &\nprinciples", "patterns")]
        return pairs

    pairs = side("hc", 21, "Human Capital Architecture", 101, None, 32)
    hc_cols = [(K, G), (G, G), (R, R), (K, R)]
    hc_x = (79, 136)
    hc_y = [162, 323, 484, 644]
    for (a, bb), (ca, cb), y in zip(pairs, hc_cols, hc_y):
        cell(hc_x[0], y, 50, 147, a, ca, "hc", 13, vertical=True)
        cell(hc_x[1], y, 50, 147, bb, cb, "hc", 13, vertical=True)

    side("sec", 992, "Security Architecture", 1074, None, 1130)
    sec_cols = [(R, K), (R, G), (R, K), (G, R)]
    sec_x = (1015, 1071)
    sec_y = [166, 326, 487, 648]
    for (a, bb), (ca, cb), y in zip(pairs, sec_cols, sec_y):
        cell(sec_x[0], y, 50, 147, a, ca, "sec", 13, vertical=True)
        cell(sec_x[1], y, 50, 147, bb, cb, "sec", 13, vertical=True)
    return b.spec
