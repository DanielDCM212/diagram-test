# Integrating `diagram_replicator` into an existing ADK project (`app/` layout)

## 1. Copy the package

```
your-project/
├── app/
│   ├── __init__.py            # from . import agent
│   ├── agent.py               # your root_agent
│   └── diagram_replicator/    # ← copy this whole folder (drawio_kit is inside it)
├── pyproject.toml / requirements.txt
└── .env
```

The package is self-contained: every import is relative, and `drawio_kit` lives inside it.
Nothing needs to be on `sys.path` except your project root, which is already there for `app`.
Leave `specs/`, `tests/`, `build_replicas.py` and `run.py` out of `app/`. They are dev tooling only.

## 2. Dependencies

Add these to your `pyproject.toml` / `requirements.txt`:

```
google-adk>=1.10
google-genai>=1.20
pydantic>=2.7
pillow>=10
numpy>=1.26
opencv-python-headless>=4.9
pytesseract>=0.3.10      # optional; harmless without the binary
```

System packages are both optional:

| package | if absent |
|---|---|
| `tesseract-ocr` | OCR falls back to Gemini automatically (`DR_OCR_BACKEND=auto`) |
| draw.io desktop + `xvfb` | the critic sees a Pillow preview instead of a true render (lower refinement quality) |

## 3. Configuration (env / `.env`)

```
GOOGLE_API_KEY=...                 # or Vertex: GOOGLE_GENAI_USE_VERTEXAI=TRUE + project/location
DR_WORKDIR=/tmp/diagram_replicator_runs    # must be writable (default already /tmp/...)
DR_OCR_BACKEND=auto                # auto | gemini | tesseract | none
DR_MODEL_PLANNER / _EXTRACTOR / _CONNECTORS / _CRITIC / _FIXER / _OCR   # optional overrides
DR_MAX_REFINE_ITERS=6              # lower it for latency/cost
```

## 4. Wire it into your agent: pick ONE mode

### Mode A — as a tool (recommended)

```python
# app/agent.py
from google.adk.agents import LlmAgent
from .diagram_replicator import replicate_diagram_tool

root_agent = LlmAgent(
    name="coordinator",
    model="gemini-2.5-flash",
    instruction="... When the user wants a diagram image converted to draw.io, call replicate_diagram.",
    tools=[replicate_diagram_tool, *your_other_tools],
)
```

- The tool takes the image from one of these sources, in order:
  1. the `image_artifact` argument;
  2. the `image_path` argument;
  3. the image attached to the user's current message;
  4. the latest image artifact in the session.
- It runs the whole pipeline in an **isolated nested session**, so none of its state keys touch yours.
- It saves `<name>.drawio`, `.spec.json`, `.render.png` and `.report.json` as **artifacts in your session**.
- It returns the artifact names, the metrics and the stop reason to your coordinator.

### Mode B — as a sub-agent (the user is handed to the pipeline)

```python
from .diagram_replicator import build_root_agent

root_agent = LlmAgent(
    name="coordinator", model="gemini-2.5-flash",
    instruction="... transfer to diagram_replicator for diagram-to-draw.io requests.",
    sub_agents=[build_root_agent(), *your_other_agents],
)
```

- Always call `build_root_agent()`. Never reuse the module-level `root_agent`, because an ADK agent can only have one parent.
- It shares your session state and writes these keys:

  ```
  ws_dir image_meta tiles overview_step ocr_backend refine_iteration quality_history fatal
  current_tile current_tile_missing_text current_tile_prior tile_extraction extracted_elements
  current_ocr_tile ocr_result layout_plan node_count connector_extraction metrics critique
  fixer_log patches_applied stop_reason outputs final_metrics input_image_path
  ```

  Rename yours if any collide, or use Mode A.

## 5. Run / verify

```bash
adk web                      # from your project root; choose "app"
adk run app
```

To smoke-test without API keys, copy `tests/golden_llm.py` (and `specs/`) next to your tests and call
`configure_tool(GoldenLlm(...))` (Mode A) or `build_root_agent(GoldenLlm(...))` (Mode B).
`examples/host_app/` in this zip is a working host project with that test.

## 6. Deployment notes

- **Cloud Run / GKE (Docker):** everything works. For best quality add to the Dockerfile:

  ```dockerfile
  RUN apt-get update && apt-get install -y --no-install-recommends \
        tesseract-ocr xvfb libgtk-3-0 libnss3 libxss1 libasound2 libgbm1 wget && \
      wget -q https://github.com/jgraph/drawio-desktop/releases/download/v28.2.5/drawio-amd64-28.2.5.deb && \
      apt-get install -y ./drawio-amd64-28.2.5.deb && rm drawio-amd64-28.2.5.deb
  ENV DR_WORKDIR=/tmp/diagram_replicator_runs
  ```

- **Vertex AI Agent Engine** (no system packages): it runs with Gemini OCR and Pillow previews. Set
  `DR_OCR_BACKEND=gemini`.
- **Artifacts:** use a persistent artifact service (e.g. `GcsArtifactService`) in production so the
  `.drawio` outputs survive the session.
- **Latency/cost:** a dense diagram takes roughly 10–30 model calls:
  - OCR tiles (Flash);
  - planner (1);
  - extractor tiles (×2 passes max);
  - connectors (1);
  - critic + fixer per refinement iteration.

  Tune `DR_MAX_REFINE_ITERS`, `DR_EXTRACTION_PASSES` and the per-role models to cut it.
- **Long runs in chat UIs:** Mode A blocks until done (minutes). If your front-end needs progress,
  use Mode B (events stream) or wrap `replicate_diagram` in a `LongRunningFunctionTool`.
