from google.adk.agents import LlmAgent
from .diagram_replicator import replicate_diagram_tool

root_agent = LlmAgent(
    name="coordinator",
    model="gemini-2.5-flash",
    instruction="Help the user. When they want a diagram image turned into draw.io, call replicate_diagram.",
    tools=[replicate_diagram_tool],
)
