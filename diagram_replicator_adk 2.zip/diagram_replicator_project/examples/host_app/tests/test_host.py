import asyncio, json, sys
sys.path.insert(0, "../..")   # repo root: specs/ + tests/golden_llm.py (test double only)
from google.adk.agents import LlmAgent
from google.adk.models import BaseLlm, LlmResponse
from google.adk.runners import InMemoryRunner
from google.genai import types
from specs import d1_customer_service
from tests.golden_llm import GoldenLlm

IMG = sys.argv[1] if len(sys.argv) > 1 and "." in sys.argv[1] else "IMG_0266.JPG"


class Coordinator(BaseLlm):
    model: str = "fake-coordinator"
    mode: str = "tool"
    async def generate_content_async(self, req, stream=False):
        done = any(p.function_response for c in req.contents for p in (c.parts or []))
        if not done:
            call = (types.FunctionCall(name="replicate_diagram", args={}) if self.mode == "tool" else
                    types.FunctionCall(name="transfer_to_agent", args={"agent_name": "diagram_replicator"}))
            yield LlmResponse(content=types.Content(role="model", parts=[types.Part(function_call=call)]))
        else:
            yield LlmResponse(content=types.Content(role="model", parts=[types.Part.from_text(text="Done.")]))


async def run(mode):
    import app.agent as host
    from app.diagram_replicator import build_root_agent, configure_tool, replicate_diagram_tool
    golden = GoldenLlm(golden=d1_customer_service.build(IMG).model_dump(), calls={})
    if mode == "tool":
        configure_tool(golden)
        agent = host.root_agent.model_copy(update={"model": Coordinator(mode="tool")})
    else:
        agent = LlmAgent(name="coordinator", model=Coordinator(mode="sub"), instruction="route",
                         sub_agents=[build_root_agent(golden)])
    runner = InMemoryRunner(agent=agent, app_name="host")
    s = await runner.session_service.create_session(app_name="host", user_id="u")
    msg = types.Content(role="user", parts=[types.Part.from_text(text="convert this"),
                                            types.Part.from_bytes(data=open(IMG, "rb").read(), mime_type="image/jpeg")])
    async for ev in runner.run_async(user_id="u", session_id=s.id, new_message=msg):
        for p in (ev.content.parts if ev.content else []) or []:
            if p.function_response:
                print(f"  tool result: {json.dumps(p.function_response.response)[:260]}")
            elif p.text and ev.author in ("coordinator", "export"):
                print(f"  [{ev.author}] {p.text[:140]}")
    keys = await runner.artifact_service.list_artifact_keys(app_name="host", user_id="u", session_id=s.id)
    print(f"{mode}: host-session artifacts = {keys}")
    assert any(k.endswith(".drawio") for k in keys)

for m in sys.argv[1:] or ["tool", "sub"]:
    asyncio.run(run(m))
