Minimal host project. Copy `../../diagram_replicator` into `app/`, then:

    PYTHONPATH=. python tests/test_host.py         # offline (golden test double), both modes
    adk web                                         # real models
