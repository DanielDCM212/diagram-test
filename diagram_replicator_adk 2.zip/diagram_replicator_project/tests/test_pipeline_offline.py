"""End-to-end offline test: run the real ADK pipeline with the GoldenLlm stand-in.

    python -m tests.test_pipeline_offline [image_index 1-4]
"""
from __future__ import annotations

import asyncio
import json
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from google.adk.runners import InMemoryRunner  # noqa: E402
from google.genai import types  # noqa: E402

from specs import (d1_customer_service, d2_dragon1_ea_framework, d3_its_architecture,  # noqa: E402
                   d4_technology_component_view)
from tests.golden_llm import GoldenLlm  # noqa: E402

UP = os.environ.get("DR_TEST_IMAGES", "/mnt/user-data/uploads")
CASES = {1: (d1_customer_service, "IMG_0266.JPG"), 2: (d2_dragon1_ea_framework, "IMG_0265.PNG"),
         3: (d3_its_architecture, "IMG_0264.JPG"), 4: (d4_technology_component_view, "FullSizeRender.jpeg")}


async def run_case(idx: int) -> dict:
    from diagram_replicator.agent import build_root_agent
    mod, fname = CASES[idx]
    img = os.path.join(UP, fname)
    golden = mod.build(img).model_dump()
    llm = GoldenLlm(golden=golden, calls={})
    runner = InMemoryRunner(agent=build_root_agent(model_override=llm), app_name="diagram_replicator")
    session = await runner.session_service.create_session(app_name="diagram_replicator", user_id="test")
    msg = types.Content(role="user", parts=[
        types.Part.from_text(text="Replicate this diagram in draw.io."),
        types.Part.from_bytes(data=open(img, "rb").read(),
                              mime_type="image/png" if fname.lower().endswith("png") else "image/jpeg")])
    async for ev in runner.run_async(user_id="test", session_id=session.id, new_message=msg):
        if ev.content and ev.content.parts and ev.content.parts[0].text and ev.author not in (
                "layout_planner", "tile_extractor", "connector_extractor", "critic"):
            print(f"[{ev.author}] {ev.content.parts[0].text[:200]}")
    s = await runner.session_service.get_session(app_name="diagram_replicator", user_id="test", session_id=session.id)
    keys = await runner.artifact_service.list_artifact_keys(app_name="diagram_replicator", user_id="test",
                                                            session_id=session.id)
    fm = s.state.get("final_metrics", {})
    assert s.state.get("outputs"), "no outputs"
    assert any(k.endswith(".drawio") for k in keys), keys
    assert fm.get("nodes", 0) >= 0.9 * len(golden["nodes"])
    assert fm.get("edges", 0) >= 0.9 * len(golden["edges"])
    print("LLM calls:", llm.calls, "\nartifacts:", keys, "\nfinal:", json.dumps(fm))
    return {"metrics": fm, "outputs": s.state["outputs"], "calls": llm.calls}


if __name__ == "__main__":
    idx = [int(a) for a in sys.argv[1:]] or [1]
    for i in idx:
        asyncio.run(run_case(i))
