"""A deterministic stand-in LLM that answers every pipeline role from a golden spec.

It lets the whole ADK pipeline (callbacks, state flow, tiling, merge, snapping, tool
calling, loop exit, artifact export, real draw.io rendering) run end-to-end with no API
key, and gives a regression baseline: with perfect extractions the pipeline must
reproduce the golden replica's quality."""
from __future__ import annotations

import json
import re
from typing import AsyncGenerator

from google.adk.models import BaseLlm, LlmRequest, LlmResponse
from google.genai import types


def _iou(a, b):
    ix = max(0, min(a[2], b[2]) - max(a[0], b[0])); iy = max(0, min(a[3], b[3]) - max(a[1], b[1]))
    i = ix * iy
    return i / max(1e-6, (a[2]-a[0])*(a[3]-a[1]) + (b[2]-b[0])*(b[3]-b[1]) - i)


class GoldenLlm(BaseLlm):
    model: str = "golden-replay"
    golden: dict
    calls: dict = {}

    @classmethod
    def supported_models(cls):
        return [r"golden-.*"]

    def _reply(self, obj=None, text=None, call=None):
        if call:
            part = types.Part(function_call=types.FunctionCall(name=call[0], args=call[1], id=f"c{len(self.calls)}"))
        else:
            part = types.Part.from_text(text=text if text is not None else json.dumps(obj))
        return LlmResponse(content=types.Content(role="model", parts=[part]))

    async def generate_content_async(self, llm_request: LlmRequest, stream: bool = False) -> AsyncGenerator[LlmResponse, None]:
        si = llm_request.config.system_instruction if llm_request.config else ""
        if not isinstance(si, str):
            si = " ".join(p.text or "" for p in getattr(si, "parts", []) or [])
        role = re.search(r"ROLE: (\w+)", si).group(1)
        self.calls[role] = self.calls.get(role, 0) + 1
        n_img = sum(1 for c in llm_request.contents for p in (c.parts or []) if p.inline_data)
        assert n_img >= 1 or role == "FIXER", f"{role} got no images"
        g = self.golden
        nodes = list(g["nodes"])

        if role == "OCR_READER":
            m = re.search(r"source region \[([\d.]+), ([\d.]+), ([\d.]+), ([\d.]+)\]", si)
            x0, y0, x1, y1 = map(float, m.groups())
            tw, th = x1 - x0, y1 - y0
            out = []
            for n in nodes:
                lbl = re.sub(r"<br\s*/?>", "\n", n["label"].replace("html:", ""))
                lbl = re.sub(r"<[^>]+>|&nbsp;", " ", lbl)
                rows = [r.strip() for r in lbl.split("\n") if r.strip()]
                if not rows:
                    continue
                cx, cy = n["x"] + n["w"] / 2, n["y"] + n["h"] / 2
                if not (x0 <= cx <= x1 and y0 <= cy <= y1):
                    continue
                lh = min(n["h"] / len(rows), n["style"]["font_size"] * 1.3)
                top = cy - lh * len(rows) / 2
                for i, r in enumerate(rows):
                    bx0, bx1 = n["x"] + 2, n["x"] + n["w"] - 2
                    by0, by1 = top + i * lh, top + (i + 1) * lh
                    out.append({"text": r, "box_2d": [int((by0 - y0) / th * 1000), int((bx0 - x0) / tw * 1000),
                                                      int((by1 - y0) / th * 1000), int((bx1 - x0) / tw * 1000)]})
            yield self._reply({"lines": out})
        elif role == "LAYOUT_PLANNER":
            yield self._reply({"diagram_type": "golden", "title": g["name"], "canvas_background": g["background"],
                               "recommended_scale": g["scale"],
                               "raster_regions": [{"x0": n["x"], "y0": n["y"], "x1": n["x"] + n["w"], "y1": n["y"] + n["h"],
                                                   "label": n["id"]} for n in nodes if n["kind"] == "raster"],
                               "expected_element_count": len(nodes), "expected_connector_count": len(g["edges"])})
        elif role == "TILE_EXTRACTOR":
            if "GAP-FILL PASS" in si:
                tid = re.search(r'tile_id="([^"]+)"', si).group(1)
                yield self._reply({"tile_id": tid, "elements": []})
                return
            m = re.search(r"x0=([\d.]+), y0=([\d.]+),\s*x1=([\d.]+), y1=([\d.]+)", si)
            x0, y0, x1, y1 = map(float, m.groups())
            tid = re.search(r'tile_id="([^"]+)"', si).group(1)
            els = []
            for n in nodes:
                b = [n["x"], n["y"], n["x"] + n["w"], n["y"] + n["h"]]
                cx, cy = (b[0] + b[2]) / 2, (b[1] + b[3]) / 2
                if not (x0 <= cx <= x1 and y0 <= cy <= y1):        # centre-in-tile ownership
                    continue
                s = n["style"]
                els.append({"local_id": n["id"], "kind": n["kind"], "label": n["label"], "x": n["x"], "y": n["y"],
                            "w": n["w"], "h": n["h"], "parent_local_id": n.get("parent") or "",
                            "fill": s["fill"], "stroke": s["stroke"], "stroke_width": s["stroke_width"],
                            "dashed": s["dashed"], "rounded": bool(s.get("rounded")) or n["kind"] == "rounded",
                            "font_size": s["font_size"], "font_color": s["font_color"], "bold": s["bold"],
                            "underline": s["underline"], "align": s["align"], "valign": s["valign"],
                            "text_dir": s["text_dir"], "status_color": n.get("status_color") or "", "confidence": 0.9})
            yield self._reply({"tile_id": tid, "elements": els})
        elif role == "CONNECTOR_EXTRACTOR":
            listing = re.findall(r"^\s+(\S+) \[(\w+)\] \(([\d.-]+),([\d.-]+),([\d.-]+),([\d.-]+)\)", si, flags=re.M)
            cand = [(i, [float(a), float(b), float(a) + float(c), float(b) + float(d)]) for i, _, a, b, c, d in listing]
            gb = {n["id"]: [n["x"], n["y"], n["x"] + n["w"], n["y"] + n["h"]] for n in nodes}

            def map_id(gid):
                if not gid or gid not in gb:
                    return ""
                best = max(cand, key=lambda c: _iou(c[1], gb[gid]), default=None)
                return best[0] if best and _iou(best[1], gb[gid]) > 0.5 else ""
            edges = []
            for e in g["edges"]:
                st = e["style"]
                sp = e["source_point"] or [0, 0]; tp = e["target_point"] or [0, 0]
                edges.append({"id": e["id"], "source_id": map_id(e["source"]), "target_id": map_id(e["target"]),
                              "source_point": {"x": sp[0], "y": sp[1]}, "target_point": {"x": tp[0], "y": tp[1]},
                              "waypoints": [{"x": p[0], "y": p[1]} for p in e["waypoints"]],
                              "color": st["color"], "width": st["width"], "dashed": st["dashed"],
                              "start_arrow": st["start_arrow"], "end_arrow": st["end_arrow"], "label": e["label"]})
            yield self._reply({"edges": edges})
        elif role == "CRITIC":
            if self.calls[role] == 1:
                yield self._reply({"verdict": "REVISE", "fidelity_0_to_10": 8.5, "summary": "one test issue",
                                   "issues": [{"severity": "low", "category": "wrong_style", "x0": 0, "y0": 0,
                                               "x1": 60, "y1": 40, "element_ids": [], "description": "test",
                                               "fix": "touch canvas background"}]})
            else:
                yield self._reply({"verdict": "PASS", "fidelity_0_to_10": 9.5, "issues": [], "summary": "ok"})
        elif role == "FIXER":
            responses = [p.function_response.name for c in llm_request.contents for p in (c.parts or [])
                         if p.function_response]
            if "apply_spec_patch" not in responses:
                yield self._reply(call=("apply_spec_patch", {"operations_json": json.dumps(
                    [{"op": "set_canvas", "set": {"background": g["background"]}}])}))
            elif "measure_region" not in responses:
                yield self._reply(call=("measure_region", {"x0": 0, "y0": 0, "x1": 200, "y1": 120}))
            elif "rebuild_and_score" not in responses:
                yield self._reply(call=("rebuild_and_score", {}))
            else:
                yield self._reply(text="Applied 1 patch; rescored.")
        else:
            raise AssertionError(role)
